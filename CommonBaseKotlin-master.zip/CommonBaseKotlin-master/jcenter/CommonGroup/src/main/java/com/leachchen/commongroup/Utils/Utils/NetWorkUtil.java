package com.leachchen.commongroup.Utils.Utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;


public class NetWorkUtil {

    private NetWorkUtil() {}

    /**
     * 判断网络是否可用
     *
     * @param context
     * @return
     */
    public static boolean isNetWorkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }

    /**
     * 检测wifi是否连接
     *
     * @return
     */
    public static boolean isWifiConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.getType() == ConnectivityManager.TYPE_WIFI;
    }

    /**
     * 检测3G是否连接
     *
     * @return
     */
    public static boolean is3gConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.getType() == ConnectivityManager.TYPE_MOBILE;
    }

//    public static void isNetWorkPing(final INetWorkUtil iNetWorkUtil, final int timeout){
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    String cmd = "ping -c 1 app.vavasmart.com";
////                    Log.d("cmd",cmd);
//                    int ret = NetWorkProcessUtils.executeCommand(cmd, timeout);
//                    if (ret == 0){
//                        iNetWorkUtil.onSuccess();
//                    }else {
//                        iNetWorkUtil.onFail();
//                    }
//                } catch (IOException e) {
//                    iNetWorkUtil.onFail();
//                    e.printStackTrace();
//                } catch (InterruptedException e) {
//                    iNetWorkUtil.onFail();
//                    e.printStackTrace();
//                } catch (TimeoutException e) {
//                    iNetWorkUtil.onFail();
//                    e.printStackTrace();
//                }
//            }
//        }).start();
//    }

}
