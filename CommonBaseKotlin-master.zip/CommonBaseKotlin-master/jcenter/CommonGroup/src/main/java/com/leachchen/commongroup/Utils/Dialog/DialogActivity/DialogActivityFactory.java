package com.leachchen.commongroup.Utils.Dialog.DialogActivity;

/**
 * ClassName:   DialogFactory.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/24 17:55
 **/

public class DialogActivityFactory {

    public static CommonDialogActivity showOneBtnDialog(String message, String oneBtnText)
    {
        CommonDialogActivity commonDialog = new CommonDialogActivity();
        return commonDialog.newOneBtnInstance(message,oneBtnText,commonDialog);
    }

}
