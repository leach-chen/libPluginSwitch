package com.leachchen.commongroup.Utils.Refreshlistview;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

import com.leachchen.commongroup.R;


/**
 * ClassName:   MyFrameLayout.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/12/6 16:35
 **/

public class RefreshFrameLayout extends FrameLayout implements Pullable {

    private static final int RECYCLEVIEW_REFRESH = 1001;
    private RecyclerView mRecycleView;
    private int mRefreshType;
    private boolean mIsRefresh;
    private boolean mIsLoadMore;

    public RefreshFrameLayout(Context context) {
        super(context);
    }
    public RefreshFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context,attrs);
    }
    public RefreshFrameLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context,attrs);
    }

    private void init(Context context, AttributeSet attrs)
    {
        TypedArray mTypedArray = context.obtainStyledAttributes(attrs, R.styleable.RefreshFrameLayout);
        mRefreshType =  mTypedArray.getInteger(R.styleable.RefreshFrameLayout_refreshType,0);
    }


    public void setRecycleView(RecyclerView recycleView)
    {
        this.mRecycleView = recycleView;
    }
    public void setLoadMore(boolean isLoadMore)
    {
        this.mIsLoadMore = isLoadMore;
    }


    private boolean recycleViewTopRefresh()
    {
        if(mRecycleView == null)return false;
        if(mRecycleView.getLayoutManager().getChildCount() == 0)
        {
            return true;
        }
        View view = mRecycleView.getLayoutManager().findViewByPosition(0);
        if (view != null && mRecycleView.getChildAt(0).getX() == 0 && mRecycleView.getChildAt(0).getY() == 0 ) {
            return true;

        } else {
            return false;
        }
    }

    private boolean recycleViewBottomRefresh()
    {
        LinearLayoutManager layoutManager = (LinearLayoutManager) mRecycleView.getLayoutManager();
        //屏幕中最后一个可见子项的position
        int lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition();
        //当前屏幕所看到的子项个数
        int visibleItemCount = layoutManager.getChildCount();
        //当前RecyclerView的所有子项个数
        int totalItemCount = layoutManager.getItemCount();
        //RecyclerView的滑动状态
        int state = mRecycleView.getScrollState();
        if(visibleItemCount > 0 && lastVisibleItemPosition == totalItemCount - 1 && state == mRecycleView.SCROLL_STATE_IDLE){
            return true;
        }else {
            return false;
        }
    }

    public void setRefreshEndble(boolean isRefresh)
    {
        this.mIsRefresh = isRefresh;
    }

    @Override
    public boolean canPullDown() {
        if(mRefreshType == RECYCLEVIEW_REFRESH)
        {
            //AppApplication.showLog("recycleViewTopRefresh:"+recycleViewTopRefresh());
            if(mIsRefresh) {
                return recycleViewTopRefresh();
            }
        }
        return  false;
    }

    @Override
    public boolean canPullUp() {
        if(mRefreshType == RECYCLEVIEW_REFRESH)
        {
            if(mIsLoadMore) {
                return recycleViewBottomRefresh();
            }
        }
        return  false;
    }
}
