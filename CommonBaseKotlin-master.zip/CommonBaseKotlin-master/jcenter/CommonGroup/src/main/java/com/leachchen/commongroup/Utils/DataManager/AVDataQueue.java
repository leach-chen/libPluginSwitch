package com.leachchen.commongroup.Utils.DataManager;

import java.util.LinkedList;

/**
 * ClassName:   AVDataQueue.java
 * Description:
 * Author :     vincent.chen
 * Date:        2017/9/6 13:45
 **/
public class AVDataQueue {

    private volatile LinkedList<AVData> avDataList = new LinkedList<AVData>();
    private volatile int DataCount = 0;

    public synchronized int getDataCount() {
        return DataCount;
    }

    public synchronized void addLast(AVData node){
        avDataList.addLast(node);
        DataCount++;
    }

    public synchronized AVData removeHead(){
        if (DataCount == 0){
            return null;
        }else {
            AVData avData = avDataList.removeFirst();
            DataCount--;
            return avData;
        }
    }

    public synchronized void removeAll() {
        if (!avDataList.isEmpty()){
            avDataList.clear();
            DataCount = 0;
        }
    }

}
