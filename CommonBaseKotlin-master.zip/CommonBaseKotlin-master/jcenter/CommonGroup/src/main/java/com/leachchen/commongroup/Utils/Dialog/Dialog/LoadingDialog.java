package com.leachchen.commongroup.Utils.Dialog.Dialog;

import android.app.ProgressDialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.leachchen.commongroup.R;


/**
 * ClassName:   LoadingDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/12/7 17:11
 **/

public class LoadingDialog extends BaseLoadingDialog {

    private LinearLayout ll_loadingdialog_content;
    private TextView loading_tv;

    public LoadingDialog(Context context) {
        super(context,R.style.MyFullDialog);
        setContentView(R.layout.dialog_loading);
        initView();
        setListener();
    }


    @Override
    protected void initView() {
        ll_loadingdialog_content =  (LinearLayout) this.findViewById(R.id.ll_loadingdialog_content);
        loading_tv =  (TextView) this.findViewById(R.id.loading_tv);
    }

    @Override
    protected void setListener() {

    }

    @Override
    protected void initData() {
        if(!TextUtils.isEmpty(mMessage))
        {
            loading_tv.setVisibility(View.VISIBLE);
            loading_tv.setText(mMessage);
        }else
        {
            loading_tv.setVisibility(View.GONE);
        }
    }

    public LoadingDialog cancleBackroundColor()
    {
        ll_loadingdialog_content.setBackground(null);
        return this;
    }

    @Override
    public void onCreateDialog() {
        if (!mIsSelfDialog) {
            ll_loadingdialog_content.setVisibility(View.GONE);
            mProgressDialog = new ProgressDialog(mContext);
            if(!mTitle.equals(""))
            {
                mProgressDialog.setTitle(mTitle);
            }
            if(!mMessage.equals(""))
            {
                mProgressDialog.setMessage(mMessage);
            }
        }
    }

    @Override
    public void onCreateView() {
        if (mIsSelfDialog) {
            ll_loadingdialog_content.setVisibility(View.VISIBLE);
        }
    }

}
