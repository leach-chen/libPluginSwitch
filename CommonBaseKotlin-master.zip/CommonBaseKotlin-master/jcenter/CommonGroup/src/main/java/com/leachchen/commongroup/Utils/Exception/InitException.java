package com.leachchen.commongroup.Utils.Exception;

import android.content.Context;

import java.lang.Thread.UncaughtExceptionHandler;

public class InitException {
	
	private Context mContext;
	private UncaughtExceptionHandler uncaughtExceptionHandler;
	
	
	public InitException(Context context)
	{
		this.mContext = context;
	}
	

	/**
	 * 初始化未知的异常错误
	 */
	@SuppressWarnings("unused")
	public void initUncaughtException() {
        //LogSP.writeMsg(this, LogManagerSP.MODE_LOGIN, "注册App异常崩溃处理器");
		//if (this.mContext.getResources().getBoolean(R.bool.uncaught_log_switch)) {
			Thread.setDefaultUncaughtExceptionHandler(getUncaughtExceptionHandler());
		//}
	}
	
	private UncaughtExceptionHandler getUncaughtExceptionHandler() {
		if (uncaughtExceptionHandler == null) {
			uncaughtExceptionHandler = AppException.getInstance(mContext);
		}
		return uncaughtExceptionHandler;
	} 

}
