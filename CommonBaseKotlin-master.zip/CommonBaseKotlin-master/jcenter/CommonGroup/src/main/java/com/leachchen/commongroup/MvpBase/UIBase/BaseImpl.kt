package com.leachchen.commongroup.MvpBase.UIBase

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.leachchen.commongroup.MvpBase.PresenterBase.BasePresenter
import com.leachchen.commongroup.Utils.Dialog.Dialog.CommonDialog
import com.leachchen.commongroup.Utils.Dialog.Dialog.DialogFactory
import com.leachchen.commongroup.Utils.Dialog.Dialog.LoadingDialog
import com.leachchen.commongroup.Utils.Dialog.Dialog.ToastDialog
import com.leachchen.commongroup.Utils.LogWrite.LogWrite
import com.leachchen.commongroup.Utils.TitleManager.TitleType1
import com.leachchen.commongroup.Utils.task.ILoadCallback
import com.leachchen.commongroup.Utils.task.MyTask
import rx.Subscription
import rx.subscriptions.CompositeSubscription
import java.lang.ref.WeakReference

/**
 * ClassName:   BaseImpl.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/30 16:02
 **/
abstract class BaseImpl(activity: Activity, context: Context, isInit: Boolean) : IBaseImpl, View.OnClickListener {

    val mActivityWeakReference: WeakReference<Activity>
    val mContextWeakReference: WeakReference<Context>
    var mCompositeSubscription: CompositeSubscription? = null
    var mPresenter: BasePresenter? = null
    protected var mView: View? = null
        get() {
            return field
        }
    val mDialogFactory: DialogFactory
    protected var mTitleType1: TitleType1  //左右两边为图片，中间为文字的标题栏


    init {
        mActivityWeakReference = WeakReference(activity)
        mContextWeakReference = WeakReference(context)
        mCompositeSubscription = CompositeSubscription()
        mDialogFactory = DialogFactory(context)
        mTitleType1 = TitleType1(activity, context)
    }

    fun init() {
        initView()
        setListener()
        initData()
    }

    abstract fun initView()

    abstract fun setListener()

    abstract fun initData()


    override fun getActivity(): Activity {
        return mActivityWeakReference.get()!!
    }

    override fun getContext(): Context {
        return mContextWeakReference.get()!!
    }

    @Override
    override fun addSubscription(s: Subscription) {
        if (this.mCompositeSubscription == null) {
            this.mCompositeSubscription = CompositeSubscription()
        }
        this.mCompositeSubscription!!.add(s)
    }

    @Override
    override fun unsubcrible() {
        if (this.mCompositeSubscription != null) {
            this.mCompositeSubscription!!.unsubscribe()
        }
    }

    /**
     * 退出Activity
     */
    @Override
    override fun finish() {
        val activity = getActivity()
        activity?.finish()
    }

    /**
     * 注销登录
     */
    @Override
    override fun logout() {

    }

    @Override
    override fun onPause() {
        if (mPresenter != null) {
            mPresenter!!.onPause()
        }
    }

    @Override
    override fun onResume() {
        if (mPresenter != null) {
            mPresenter!!.onResume()
        }
    }

    @Override
    override fun onDestroy() {
        unsubcrible()
        if (mPresenter != null) {
            mPresenter!!.onDestroy()
        }
    }

    fun setPresenter(presenter: BasePresenter) {
        mPresenter = presenter
    }

    fun startActivity(cls: Class<*>) {
        startActivity(cls, null)
        //        getActivity().overridePendingTransition(R.anim.left_out,R.anim.right_in);//从右往左
    }

    fun startActivity(cls: Class<*>, bundle: Bundle?) {
        val intent = Intent()
        intent.setClass(getContext(), cls)
        if (bundle != null) {
            intent.putExtras(bundle)
        }
        getContext().startActivity(intent)
    }

    fun startActivityForResult(cls: Class<*>) {
        startActivityForResult(cls, null)
    }

    fun startActivityForResult(cls: Class<*>, bundle: Bundle?) {
        val intent = Intent()
        intent.setClass(getContext(), cls)
        if (bundle != null) {
            intent.putExtras(bundle)
        }
        getActivity().startActivityForResult(intent, 1)
    }


    /**
     * 启动一个线程
     *
     * @param callback
     */
    fun runThread(callback: ILoadCallback) {
        runThread(callback, true)
    }

    /**
     * 启动一个线程
     *
     * @param callback
     */
    fun runThread(callback: ILoadCallback?, showLoading: Boolean) {
        try {
            if (showLoading) {
                showLoading().showDialog()
            }
            MyTask(getContext(), object : ILoadCallback {
                override fun run(): Any {
                    if (null != callback) {
                        return callback.run();
                    }
                    return false;
                }

                override fun loadedCallback(data: Any?) {
                    if (showLoading) {
                        hideLoadingDialog();
                    }
                    if (null != callback) {
                        callback.loadedCallback(data);
                    }
                }
            }).execute(0)
        } catch (e: Exception) {
          LogWrite.writeMsg(e)
        }
    }


    /*************************************弹窗类型 */

    @Override
    override fun showLoading(): LoadingDialog {
        return mDialogFactory.showLoading()
    }

    @Override
    override fun showLoading(message: String): LoadingDialog {
        return mDialogFactory.showLoading(message)
    }

    @Override
    override fun showLoadingDisable(): LoadingDialog {
        return mDialogFactory.showLoadingDisable()
    }

    @Override
    override fun showLoadingDisable(message: String): LoadingDialog {
        return mDialogFactory.showLoadingDisable(message)
    }

    @Override
    override fun hideLoadingDialog() {
        mDialogFactory.hideLoadingDialog()
    }

    @Override
    override fun showToastSuccess(message: String): ToastDialog {
        return mDialogFactory.showToastSuccess(message)
    }


    @Override
    override fun showToastWarn(message: String): ToastDialog {
        return mDialogFactory.showToastWarn(message)
    }

    @Override
    override fun showToastFail(message: String): ToastDialog {
        return mDialogFactory.showToastFail(message)
    }

    fun showToastTips(message: String): ToastDialog {
        return mDialogFactory.showToastTips(message)
    }

    @Override
    override fun showOneBtnDialog(title: String, message: String, oneBtnText: String): CommonDialog {
        return mDialogFactory.showOneBtnDialog(title, message, oneBtnText)
    }

    @Override
    override fun showOneBtnDialogDisable(title: String, message: String, oneBtnText: String): CommonDialog {
        return mDialogFactory.showOneBtnDialogDisable(title, message, oneBtnText)
    }

    @Override
    override fun showTwoBtnDialog(title: String, message: String, twoBtnLeftText: String, twoBtnRightText: String): CommonDialog {
        return mDialogFactory.showTwoBtnDialog(title, message, twoBtnLeftText, twoBtnRightText)
    }

    @Override
    override fun showTwoBtnDialogDisable(title: String, message: String, twoBtnLeftText: String, twoBtnRightText: String): CommonDialog {
        return mDialogFactory.showTwoBtnDialogDisable(title, message, twoBtnLeftText, twoBtnRightText)
    }

    @Override
    override fun hideCommonDialog() {
        mDialogFactory.hideCommonDialog()
    }
    /*************************************弹窗类型*************************************************/


}