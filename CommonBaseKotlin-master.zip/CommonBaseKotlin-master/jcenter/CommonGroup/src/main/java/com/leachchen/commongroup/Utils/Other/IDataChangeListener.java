package com.leachchen.commongroup.Utils.Other;

/**
 * ClassName:   IDataChangeListener.java
 * Description:
 * Author :     jame.liu
 * Date:        2017/11/30 17:58
 **/
public interface IDataChangeListener {
    public void onDataSetChanged(int dataCount);
}
