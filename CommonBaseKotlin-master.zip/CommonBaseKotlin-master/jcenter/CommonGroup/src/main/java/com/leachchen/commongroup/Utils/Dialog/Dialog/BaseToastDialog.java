package com.leachchen.commongroup.Utils.Dialog.Dialog;

import android.content.Context;
import android.support.annotation.NonNull;

/**
 * ClassName:   BaseToastDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/27 10:01
 **/

public abstract class BaseToastDialog extends BaseDialog {

    protected  static int mToastDialogType = 1001; //toast弹窗类型
    protected BaseToastDialogListener mToastListener;
    protected BaseToastDialog mInstance;

    public BaseToastDialog(@NonNull Context context, int theme) {
        super(context, theme);
        mInstance = this;
    }

    public BaseToastDialog setListenerToast(BaseToastDialogListener listener) {
        mToastListener = listener;
        return mInstance;
    }

    public BaseToastDialog setToastType(int type) {
        mToastDialogType = type;
        return mInstance;
    }

    /**********************************************************************************************/
    public BaseToastDialog setTitleColor(int titleColor) {
        mTitleColor = titleColor;
        return mInstance;
    }

    public BaseToastDialog setMessageColor(int messageColor) {
        mMessageColor = messageColor;
        return mInstance;
    }


    public BaseToastDialog setTitleSize(float titleSize) {
        mTitleSize = titleSize;
        return mInstance;
    }

    public BaseToastDialog setMessageSize(float messageSize) {
        mMessageSize = messageSize;
        return mInstance;
    }


    public BaseToastDialog setTitle(String title) {
        if (title == null) title = "";
        mTitle = title;
        return mInstance;
    }

    public BaseToastDialog setMessage(String message) {
        if (message == null) message = "";
        mMessage = message;
        return mInstance;
    }


    public BaseToastDialog setCancelAble(boolean isCancelAble) {
        mIsCancelAble = isCancelAble;
        return mInstance;
    }

    public BaseToastDialog setSelfDialog(boolean isSelfDialog) {
        mIsSelfDialog = isSelfDialog;
        return mInstance;
    }
    /**********************************************************************************************/
}
