package com.leachchen.commongroup.Utils.Utils;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;

import java.util.UUID;

/**
 * ClassName:   DeviceUtils.java
 * Description:
 * Author :     jame.liu
 * Date:        2017/9/1 10:32
 **/

public class DeviceUtils {

    public static void printDeviceInfo(Activity activity) {
        DisplayMetrics dm = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        int wMaxDP = 160 * dm.widthPixels / dm.densityDpi;
        StringBuffer sb = new StringBuffer();
        sb.append("系统版本:" + Build.VERSION.RELEASE).append("\n");
        sb.append("系统版本:" + Build.VERSION.SDK_INT).append("\n");
        sb.append("手机型号:" + Build.MODEL).append("\n");
        sb.append("手机品牌:" + Build.BRAND).append("\n");
        sb.append("制造厂商:" + Build.MANUFACTURER).append("\n");
        sb.append("屏幕宽度dp:" + wMaxDP).append("\n");
        Log.i("Device", sb.toString());
    }

    public static String getDeviceId(Context context) {
        String deviceId = null;
        String tmDeviceId = null;
        Object tmSerialNumber = null;
        String androidId = null;
        TelephonyManager telephoneManager = (TelephonyManager)context.getSystemService("phone");
        tmDeviceId = telephoneManager.getDeviceId();
        androidId = Settings.Secure.getString(context.getContentResolver(), "android_id");
        if(tmDeviceId == null) {
            tmDeviceId = "empty";
        }

        UUID uuid = new UUID((long)androidId.hashCode(), (long)tmDeviceId.hashCode() >> 32);
        deviceId = uuid.toString();
        return deviceId;
    }

    private static String getLocalMacAddress(Context context) {
        WifiManager wifi = (WifiManager)context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifi.getConnectionInfo();
        return info.getMacAddress();
    }

    public static String getOsVersion() {
        return Build.VERSION.RELEASE;
    }

    public static String getOsModel() {
        return Build.BRAND + " " + Build.MODEL;
    }

    public static int getOsVersionCode() {
        return Build.VERSION.SDK_INT;
    }

    public static int getVersion(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        PackageInfo pinfo = null;

        try {
            pinfo = pm.getPackageInfo(ctx.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException var4) {
            var4.printStackTrace();
        }

        return pinfo.versionCode;
    }

    public static String getVersionName(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        PackageInfo pinfo = null;

        try {
            pinfo = pm.getPackageInfo(ctx.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException var4) {
            var4.printStackTrace();
        }

        if(TextUtils.isEmpty(pinfo.versionName))
        {
            return "";
        }
        return pinfo.versionName;
    }

    public static String getVersionCode(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        PackageInfo pinfo = null;

        try {
            pinfo = pm.getPackageInfo(ctx.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException var4) {
            var4.printStackTrace();
        }

        return pinfo.versionCode + "";
    }

    public static int getWidthMaxDp(Activity activity) {
        DisplayMetrics dm = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        int wMaxDP = 160 * dm.widthPixels / dm.densityDpi;
        return wMaxDP;
    }

    public static int getWidthMaxPx(Activity activity) {
        DisplayMetrics dm = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        return dm.widthPixels;
    }

    public static int getWidthMaxPx(Context context) {
        return getWidthMaxPx((Activity)context);
    }

    public static int getHeightMaxPx(Activity activity) {
        DisplayMetrics dm = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        return dm.heightPixels;
    }

    public static int getHeightMaxPx(Context context) {
        return getHeightMaxPx((Activity)context);
    }

    public static String getVersionName(Activity activity) {
        PackageManager packageManager = activity.getPackageManager();

        try {
            PackageInfo packInfo = packageManager.getPackageInfo(activity.getPackageName(), 0);
            String version = packInfo.versionName;
            return version;
        } catch (PackageManager.NameNotFoundException var5) {
            return "";
        }
    }

    public static String getChannelValue(Activity activity, String name) {
        PackageManager packageManager = activity.getPackageManager();
        Object version = null;

        try {
            ApplicationInfo e = packageManager.getApplicationInfo(activity.getPackageName(), 0);
            return (String)(null != e && null != e.metaData?e.metaData.getString("UMENG_CHANNEL"):version);
        } catch (Exception var5) {
            return "";
        }
    }
}
