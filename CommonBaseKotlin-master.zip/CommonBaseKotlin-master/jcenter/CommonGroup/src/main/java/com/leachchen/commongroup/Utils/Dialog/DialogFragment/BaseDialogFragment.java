package com.leachchen.commongroup.Utils.Dialog.DialogFragment;


import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.view.View;

import com.leachchen.commongroup.MvpBase.UIBase.BaseActivity;
import com.leachchen.commongroup.MvpBase.UIBase.BaseFragment;

/**
 * ClassName:   BaseDialogFragment.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/16 14:11
 **/

public abstract class BaseDialogFragment extends DialogFragment {
    protected static final String EXTRA_TITLE_KEY = "extra_title_key";
    protected static final String EXTRA_MESSAGE_KEY = "extra_message_key";
    protected static final String EXTRA_TXT_ONEBTN_KEY = "extra_txt_onebtn_key";
    protected static final String EXTRA_TXT_LEFTBTN_KEY = "extra_txt_leftbtn_key";
    protected static final String EXTRA_TXT_RIGHTBTN_KEY = "extra_txt_rightbtn_key";

    protected static final String EXTRA_COLOR_TITLE_KEY = "extra_color_title_key";
    protected static final String EXTRA_COLOR_MESSAGE_KEY = "extra_color_message_key";
    protected static final String EXTRA_COLOR_ONEBTN_KEY = "extra_color_one_key";
    protected static final String EXTRA_COLOR_LEFTBTN_KEY = "extra_color_leftbtn_key";
    protected static final String EXTRA_COLOR_RIGHTBTN_KEY = "extra_color_rightbtn_key";

    protected static final String EXTRA_CANCELABLE_KEY = "extra_cancelable_key";
    protected static final String EXTRA_SELFDIALOG_KEY = "extra_selfdialog_key";
    protected static final String EXTRA_WRAPMESSAGE_KEY = "extra_wrapmessage_key";
    protected static final String EXTRA_TOASTTYPE_KEY = "extra_toasttype_key";

    protected boolean isGetDialogListener;
    private BaseActivity mBaseActivity;

    protected String mTitle = "";   //标题
    protected String mMessage = ""; //内容
    protected String mOneBtnText = "";//单个按钮文案
    protected String mTwoBtnLeftText = "";//左按钮文案
    protected String mTwoBtnRightText = "";//右按钮文案
    protected boolean mIsCancelAble = false; //是否点击空白区域可以取消 true可以取消，false不可以
    protected boolean mIsSelfDialog = true; //是否是自定义的窗口   true是自定义窗口，false为系统窗口
    protected boolean mIsWrapMessage = false; //是否窗口高度适应内容  true为适应高度，false为固定高度
    protected int mToastDialogType = 1001; //toast弹窗类型


    protected static FragmentManager mFragmentManager;
    protected static String mDialogId;
    protected static BaseDialogFragment mInstance;
    protected static Bundle mBundle;
    protected View mView;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
    }

    protected abstract void initView();

    protected abstract void setListener();

    protected abstract void initData();

    protected void initDialog() {
        initView();
        setListener();
        initData();
    }

    protected void init() {
        if (getArguments() != null) {
            mTitle = getArguments().getString(EXTRA_TITLE_KEY, "");
            mMessage = getArguments().getString(EXTRA_MESSAGE_KEY, "");
            mOneBtnText = getArguments().getString(EXTRA_TXT_ONEBTN_KEY, "")/* == null ? "" : getArguments().getString(EXTRA_TXT_ONEBTN_KEY)*/;
            mTwoBtnLeftText = getArguments().getString(EXTRA_TXT_LEFTBTN_KEY, "");
            mTwoBtnRightText = getArguments().getString(EXTRA_TXT_RIGHTBTN_KEY, "");
            mIsCancelAble = getArguments().getBoolean(EXTRA_CANCELABLE_KEY, true);
            mIsSelfDialog = getArguments().getBoolean(EXTRA_SELFDIALOG_KEY, true);
            mIsWrapMessage = getArguments().getBoolean(EXTRA_WRAPMESSAGE_KEY, false);
            mToastDialogType = getArguments().getInt(EXTRA_TOASTTYPE_KEY, ToastDialogFragment.SHOW_SUCCESS);
            setCancelable(mIsCancelAble);
        }
    }

    public BaseDialogFragment setTitle(String title) {
        if (title == null) title = "";
        mBundle.putString(EXTRA_TITLE_KEY, title);
        return mInstance;
    }

    public BaseDialogFragment setMessage(String message) {
        if (message == null) message = "";
        mBundle.putString(EXTRA_MESSAGE_KEY, message);
        return mInstance;
    }


    public BaseDialogFragment setCancelAble(boolean isCancelAble) {
        mBundle.putBoolean(EXTRA_CANCELABLE_KEY, isCancelAble);
        return mInstance;
    }

    public BaseDialogFragment setSelfDialog(boolean isSelfDialog) {
        mBundle.putBoolean(EXTRA_SELFDIALOG_KEY, isSelfDialog);
        return mInstance;
    }

    public BaseDialogFragment setWrapContent(boolean isWrapContent) {
        mBundle.putBoolean(EXTRA_WRAPMESSAGE_KEY, isWrapContent);
        return mInstance;
    }


    public BaseDialogFragment setToastType(int type) {
        mBundle.putInt(EXTRA_TOASTTYPE_KEY, type);
        return mInstance;
    }


    public void showDialog() {
        mInstance.setArguments(mBundle);
        mInstance.show(mFragmentManager, mDialogId);
        mFragmentManager.executePendingTransactions();
    }

    @Override
    public void onResume() {
        super.onResume();
        BaseDialogFragmentListener listener = null;
        if (!isGetDialogListener) {
            isGetDialogListener = true;
        }

        if (getParentFragment() instanceof BaseFragment) {
            //listener = ((BaseFragment) getParentFragment()).getDialogListener();
        }
        if (mBaseActivity != null) {
            //listener = mBaseActivity.getDialogListener();
        }

        if (listener != null) {
            setDialogListener(listener);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (getParentFragment() instanceof BaseFragment) {
            //((BaseFragment) getParentFragment()).clearDialogListener();
        } else if (mBaseActivity != null) {
            //mBaseActivity.clearDialogListener();
        }

    }

    public abstract void setDialogListener(BaseDialogFragmentListener listener);

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (getActivity() instanceof BaseActivity) {
            mBaseActivity = (BaseActivity) getActivity();
        }
    }

}
