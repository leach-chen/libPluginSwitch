package com.leachchen.commongroup.Utils.Dialog.Dialog;

import android.content.Context;
import android.support.annotation.NonNull;

import com.leachchen.commongroup.R;

/**
 * ClassName:   BaseDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/25 19:24
 **/

public abstract class BaseCommonDialog extends BaseDialog {

    public static final int DIALOG_ONE_POSITION = 1;
    public static final int DIALOG_TWO_POSITION = 2;


    protected boolean mIsWrapMessage = false; //是否窗口高度适应内容  true为适应高度，false为固定高度
    protected int mOneBtnColor = this.getContext().getResources().getColor(R.color.color_03BFFE);
    protected int mTwoBtnLeftColor = this.getContext().getResources().getColor(R.color.color_03BFFE);
    protected int mTwoBtnRightColor = this.getContext().getResources().getColor(R.color.color_03BFFE);
    protected float mOneBtnSize = this.getContext().getResources().getDimension(R.dimen.sp_18);
    protected float mTwoBtnLeftSize = this.getContext().getResources().getDimension(R.dimen.sp_18);
    protected float mTwoBtnRightSize = this.getContext().getResources().getDimension(R.dimen.sp_18);


    protected BaseCommonDialogListener mBtnOneListener;
    protected BaseCommonDialogListener mBtnTwoListener;
    protected static BaseCommonDialog mInstance;
    protected static boolean mShowTwoBtn;



    public BaseCommonDialog(@NonNull Context context, int theme) {
        super(context, theme);
        mInstance = this;
    }

    /**********************************************************************************************/
    public BaseCommonDialog setTitleColor(int titleColor) {
        mTitleColor = titleColor;
        return mInstance;
    }

    public BaseCommonDialog setMessageColor(int messageColor) {
        mMessageColor = messageColor;
        return mInstance;
    }


    public BaseCommonDialog setTitleSize(float titleSize) {
        mTitleSize = titleSize;
        return mInstance;
    }

    public BaseCommonDialog setMessageSize(float messageSize) {
        mMessageSize = messageSize;
        return mInstance;
    }


    public BaseCommonDialog setTitle(String title) {
        if (title == null) title = "";
        mTitle = title;
        return mInstance;
    }

    public BaseCommonDialog setMessage(String message) {
        if (message == null) message = "";
        mMessage = message;
        return mInstance;
    }


    public BaseCommonDialog setCancelAble(boolean isCancelAble) {
        mIsCancelAble = isCancelAble;
        return mInstance;
    }

    public BaseCommonDialog setSelfDialog(boolean isSelfDialog) {
        mIsSelfDialog = isSelfDialog;
        return mInstance;
    }
    /**********************************************************************************************/

    public BaseCommonDialog setOneBtnColor(int oneBtnColor) {
        mOneBtnColor = oneBtnColor;
        return this;
    }

    public BaseCommonDialog setTwoLeftBtnColor(int twoBtnLeftColor) {
        mTwoBtnLeftColor = twoBtnLeftColor;
        return mInstance;
    }

    public BaseCommonDialog setTwoRightBtnColor(int twoBtnRightColor) {
        mTwoBtnRightColor = twoBtnRightColor;
        return mInstance;
    }

    public BaseCommonDialog setOneBtnSize(float oneBtnSize) {
        mOneBtnSize = oneBtnSize;
        return mInstance;
    }

    public BaseCommonDialog setTwoLeftBtnSize(float twoBtnLeftSize) {
        mTwoBtnLeftSize = twoBtnLeftSize;
        return mInstance;
    }

    public BaseCommonDialog setTwoRightBtnSize(float twoBtnRightSize) {
        mTwoBtnRightSize = twoBtnRightSize;
        return mInstance;
    }

    public BaseCommonDialog setOneBtnText(String oneBtnText) {
        if (oneBtnText == null) oneBtnText = "";
        mOneBtnText = oneBtnText;
        mShowTwoBtn = false;
        return mInstance;
    }


    public BaseCommonDialog setTwoBtnLeftText(String twoBtnLeftText) {
        if (twoBtnLeftText == null) twoBtnLeftText = "";
        mTwoBtnLeftText = twoBtnLeftText;
        mShowTwoBtn = true;
        return mInstance;
    }

    public BaseCommonDialog setTwoBtnRightText(String twoBtnRightText) {
        if (twoBtnRightText == null) twoBtnRightText = "";
        mTwoBtnRightText = twoBtnRightText;
        mShowTwoBtn = true;
        return this;
    }

    public BaseCommonDialog setListenerBtnOne(BaseCommonDialogListener listener) {
        mBtnOneListener = listener;
        return mInstance;
    }

    public BaseCommonDialog setListenerBtnTwo(BaseCommonDialogListener listener) {
        mBtnTwoListener = listener;
        return mInstance;
    }

    public BaseCommonDialog setWrapContent(boolean isWrapContent) {
        mIsWrapMessage = isWrapContent;
        return mInstance;
    }

}
