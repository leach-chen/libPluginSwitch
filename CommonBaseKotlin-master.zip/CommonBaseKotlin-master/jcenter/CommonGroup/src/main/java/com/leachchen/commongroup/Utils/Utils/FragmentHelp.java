package com.leachchen.commongroup.Utils.Utils;

import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import java.util.List;

/**
 * ClassName:   FragmentAdd.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/7/29 16:34
 **/
public class FragmentHelp {

    public static void addFragmentToActivity(@NonNull FragmentManager fragmentManager,
                                             @NonNull Fragment fragment, int frameId) {
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.add(frameId, fragment);
        transaction.commit();
    }

    public static void changeFragmentFromActivity(@NonNull FragmentManager fragmentManager, List<Fragment> fragmentList, int frameId, Fragment fragment) {
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        for (int i = 0; i < fragmentList.size(); i++) {
            if (fragmentList.get(i) != fragment) {
                transaction.hide(fragmentList.get(i));
            }else {
                if (!fragmentList.get(i).isAdded()) {
                    transaction.add(frameId, fragmentList.get(i));
                }
                transaction.show(fragmentList.get(i)).commit();
            }
        }
    }

}
