package com.leachchen.commongroup.Utils.Utils;

import android.widget.TextView;

import java.util.regex.Pattern;

/**
 * ClassName:   StringUtils.java
 * Description: 字符串工具类
 * Author :     jame.liu
 * Date:        2017/8/3 15:24
 **/
public class StringUtils {

    public static String getString(String str){
        if(isNull(str)){
            return "";
        }
        return str;
    }

    /**
     * 判断空
     * @param str
     * @return
     */
    public static boolean isNull(String str){

        if(null == str || "".equals(str) || "NULL".equals(str.toUpperCase())){
            return true;
        }
        return false;
    }

    /**
     * 判断空
     * @param textView
     * @return
     */
    public static boolean isNull(TextView textView){
        if(null == textView){
            return true;
        }
        String text = textView.getText().toString().trim();
        return isNull(text);
    }

    /**
     * 判断是否为邮箱
     * @param email
     * @return
     */
    public static boolean isEmail(String email){

        if (isNull(email)) {
            return false;
        }

        Pattern emailer = Pattern.compile("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");
        return emailer.matcher(email).matches();
    }

    /**
     * 判断是否为手机号码
     * @param phone
     * @return
     */
    public static boolean isPhone(String phone){

        if (isNull(phone)) {
            return false;
        }

        String PHONE = "^1[3,4,5,7,8]\\d{9}$";
        return phone.matches(PHONE);
    }

}
