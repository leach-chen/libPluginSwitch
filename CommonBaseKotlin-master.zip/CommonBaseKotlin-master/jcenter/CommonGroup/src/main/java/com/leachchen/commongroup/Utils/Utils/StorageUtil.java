package com.leachchen.commongroup.Utils.Utils;

import android.os.Environment;
import android.os.StatFs;

import java.io.File;
import java.text.DecimalFormat;

/**
 * ClassName:   StorageUtil.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/12/6 14:00
 **/

public class StorageUtil {

    public static long getMobileLeaveSize() {
        long leaveSize = -1;
        try {
            boolean sdCardExist = Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED); //判断sd卡是否存在
            if (sdCardExist) {
                File path = Environment.getExternalStorageDirectory();
                StatFs stat = new StatFs(path.getPath());
                long blockSize = stat.getBlockSize();
                long availableBlocks = stat.getAvailableBlocks();
                leaveSize = blockSize * availableBlocks;
            }
        } catch (Exception e) {
            return -1;
        }
        leaveSize = leaveSize / (1024 * 1024);
        return leaveSize;
    }


    public static String getNetFileSizeDescription(long size) {
        StringBuffer bytes = new StringBuffer();
        DecimalFormat format = new DecimalFormat("##0.00");
        if (size >= 1024 * 1024 * 1024) {
            double i = (size / (1024.00 * 1024.00 * 1024.00));
            bytes.append(format.format(i)).append("G");
        }
        else if (size >= 1024 * 1024) {
            double i = (size / (1024.00 * 1024.00));
            bytes.append(format.format(i)).append("M");
        }
        else if (size >= 1024) {
            double i = (size / (1024.00));
            bytes.append(format.format(i)).append("K");
        }
        else if (size < 1024) {
            if (size <= 0) {
                bytes.append("0B");
            }
            else {
                bytes.append((int) size).append("B");
            }
        }
        return bytes.toString();
    }

}
