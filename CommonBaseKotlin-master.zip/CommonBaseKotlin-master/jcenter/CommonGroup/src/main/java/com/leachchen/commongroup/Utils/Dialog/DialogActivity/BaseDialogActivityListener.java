package com.leachchen.commongroup.Utils.Dialog.DialogActivity;

/**
 * ClassName:   BaseDialogListerer.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/17 11:28
 **/

public interface BaseDialogActivityListener {
    void onClickListener(int position, BaseDialogActivity dialog);
}
