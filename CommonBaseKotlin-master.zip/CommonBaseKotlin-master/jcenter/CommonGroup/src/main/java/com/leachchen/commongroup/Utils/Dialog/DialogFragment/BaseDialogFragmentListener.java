package com.leachchen.commongroup.Utils.Dialog.DialogFragment;

/**
 * ClassName:   BaseDialogListerer.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/17 11:28
 **/

public interface BaseDialogFragmentListener {
}
