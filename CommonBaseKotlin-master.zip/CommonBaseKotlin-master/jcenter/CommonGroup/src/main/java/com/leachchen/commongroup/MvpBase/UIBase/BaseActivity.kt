package com.leachchen.commongroup.MvpBase.UIBase

import android.content.Intent
import android.os.Bundle
import android.os.StrictMode
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.KeyEvent
import com.leachchen.commongroup.R

/**
 * ClassName:   BaseActivity.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/29 17:21
 **/
abstract class BaseActivity : AppCompatActivity() {

    @Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Activity入栈
        ActivityList.getInstance().push(this)
        //打印生命周期
        //LogWrite.d("--------------------------onCreate  " + getClass().getSimpleName() + "--------------------", LogModel.MODEL_COMMON);
        setContentView()
    }

    private fun runStrictMode() {
        //开启严格模式，检查卡顿内存泄漏
        StrictMode.setThreadPolicy(StrictMode.ThreadPolicy.Builder()

                .detectDiskReads()

                .detectDiskWrites()

                .detectNetwork()   // or .detectAll() for all detectable problems

                .penaltyLog()

                .build())

        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder()

                .detectLeakedSqlLiteObjects()

                .detectLeakedClosableObjects()

                .penaltyLog()

                .penaltyDeath()

                .build())
    }

    @Override
    override fun onPause() {
        //LogWrite.d("--------------------------onPause  " + getClass().getSimpleName() + "--------------------", LogModel.MODEL_COMMON);
        super.onPause()
    }

    @Override
    override fun onRestart() {
        //LogWrite.d("--------------------------onRestart  " + getClass().getSimpleName() + "--------------------", LogModel.MODEL_COMMON);
        super.onRestart()
    }

    @Override
    override fun onStop() {
        //LogWrite.d("--------------------------onStop  " + getClass().getSimpleName() + "--------------------", LogModel.MODEL_COMMON);
        super.onStop()
    }

    @Override
    override fun onStart() {
        //LogWrite.d("--------------------------onStart  " + getClass().getSimpleName() + "--------------------", LogModel.MODEL_COMMON);
        super.onStart()
    }

    @Override
    override fun onResume() {
        //LogWrite.d("--------------------------onResume  " + getClass().getSimpleName() + "--------------------", LogModel.MODEL_COMMON);
        super.onResume()
    }

    @Override
    override fun onDestroy() {
        super.onDestroy()

        //LogWrite.d("--------------------------onDestroy  " + getClass().getSimpleName() + "--------------------", LogModel.MODEL_COMMON);
        //Activity出栈
        ActivityList.getInstance().pop(this)
    }

    @Override
    override fun onSaveInstanceState(outState: Bundle)
    {
        super.onSaveInstanceState(outState)
    }

    abstract fun setContentView()

    abstract fun init()

    fun startActivity(cls: Class<*>) {
        startActivity(cls, null)
    }

    fun startActivity(cls:Class<*>,bundle: Bundle?)
    {
        var intent = Intent()
        intent.setClass(this,cls)
        if(bundle != null)
        {
            intent.putExtras(bundle)
        }
        startActivity(intent)
    }

    fun getString(key : String) : String
    {
        var intent = getIntent()
        if(intent != null && intent.hasExtra(key))
        {
            return intent.getStringExtra(key)
        }
        return ""
    }

    @Override
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

    }

    @Override
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
        }
        return super.onKeyDown(keyCode, event)
    }

    /**
     * 跳转桌面
     */
    fun goDesktop() {
        val home = Intent(Intent.ACTION_MAIN)
        home.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        home.addCategory(Intent.CATEGORY_HOME)
        startActivity(home)
    }

    // action for fragment  start

    /**
     * 当前显示的fragment
     */
    private var currentFragment: Fragment? = null
        get() {
                return field
        }


    /**
     * 显示framgnet
     *
     * @param fragment
     */
    fun showFragment(frameLayoutId : Int, fragment : Fragment) {
        //非空
        if (null == fragment) {
            return
        }

        //已经显示
        if (fragment.isAdded && !fragment.isHidden) {
            return
        }

        val fragmentManager = supportFragmentManager
        val transation = fragmentManager.beginTransaction()

        //隐藏当前显示的fragment
        if (null != currentFragment && currentFragment!!.isAdded()) {
            transation.hide(currentFragment!!)
        }

        //显示传入的fragment
        if (!fragment.isAdded) {
            transation.add(frameLayoutId, fragment)
            transation.commit()
        } else {

            transation.show(fragment)
            transation.commit()
        }

        //记住当前的fragment
        currentFragment = fragment
    }

    fun hideFragment(fragment: Fragment?) {
        if (null != fragment && fragment.isAdded && !fragment.isHidden) {
            val fragmentManager = supportFragmentManager
            val transation = fragmentManager.beginTransaction()
            transation.hide(fragment)
            transation.commit()
        }
    }

    fun getLeftInAnim(): Int = R.anim.left_in

    fun getLeftOutAnim(): Int  = R.anim.left_out

    fun getRightInAnim(): Int  = R.anim.right_in

    fun getRightOutAnim(): Int = R.anim.left_out

    override fun startActivityForResult(intent: Intent?, requestCode: Int) {
        var intent = intent

        //解决
        //java.lang.NullPointerException: Attempt to invoke virtual method 'boolean android.content.Intent.migrateExtraStreamToClipData()' on a null object reference
        try {
            if (null == intent) {
                intent = Intent()
            }
            super.startActivityForResult(intent, requestCode)
            overridePendingTransition(getLeftInAnim(), getLeftOutAnim())//从右往左
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    override fun finish() {
        super.finish()
        //LogWrite.d("--------------------------finish  " + getClass().getSimpleName() + "--------------------", LogModel.MODEL_COMMON);
        //overridePendingTransition(getRightInAnim(), getRightOutAnim())//从右往左
    }
    // action for fragment  end

}