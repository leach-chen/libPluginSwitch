package com.leachchen.commongroup.Utils.Dialog.Dialog;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.text.Layout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.leachchen.commongroup.R;


/**
 * ClassName:   SuccessDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/10/25 11:27
 **/

public class ToastDialog extends BaseToastDialog{

    public static final int SHOW_SUCCESS = 1001;
    public static final int SHOW_WARNING = 1002;
    public static final int SHOW_FAIL = 1003;
    public static final int SHOW_TIPS = 1004;
    private Handler mHandle = new Handler();
    private ImageView toast_iv;
    private TextView toast_tv;
    private LinearLayout toast_ll;
    private RelativeLayout rl_toastdialog_content;
    private int mOtherWidth = 0;
    private int mMaxWidth = 0;
    private int mMinWidth = 0;

    public ToastDialog(Context context) {
        super(context,R.style.MyFullDialog);
        setContentView(R.layout.dialog_toast);
        initView();
        setListener();
    }

    @Override
    public void onStart() {
        super.onStart();
        Window window = getWindow();
        WindowManager.LayoutParams windowParams = window.getAttributes();
        windowParams.dimAmount = 0.0f;
        window.setAttributes(windowParams);
    }

    @Override
    protected void initView() {
        toast_ll = (LinearLayout)this.findViewById(R.id.toast_ll);
        toast_iv = (ImageView) this.findViewById(R.id.toast_iv);
        toast_tv = (TextView) this.findViewById(R.id.toast_tv);
        rl_toastdialog_content = (RelativeLayout) this.findViewById(R.id.rl_toastdialog_content);

        mOtherWidth = (int) getContext().getResources().getDimension(R.dimen.dp_10) * 2;
        mMaxWidth = (int) getContext().getResources().getDimension(R.dimen.dp_200);
        mMinWidth = (int) getContext().getResources().getDimension(R.dimen.dp_120);
    }

    @Override
    protected void setListener() {
        this.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                mHandle.removeCallbacks(mRunnable);
                if(mToastListener != null)
                    ((ToastDimissListener)mToastListener).onDimissListener();
            }
        });
    }


    Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            dimissDialog();
        }
    };

    @Override
    protected void initData() {
        if (mToastDialogType == SHOW_SUCCESS) {
            toast_iv.setImageResource(R.drawable.tips_icon_done);
        } else if (mToastDialogType == SHOW_WARNING) {
            toast_iv.setImageResource(R.drawable.taost_ico_warning);
        } else if (mToastDialogType == SHOW_FAIL) {
            toast_iv.setImageResource(R.drawable.tips_icon_failed);
        } else if (mToastDialogType == SHOW_TIPS){
            toast_iv.setVisibility(View.GONE);
        }
        if(TextUtils.isEmpty(mMessage))
        {
            toast_tv.setVisibility(View.GONE);
            toast_tv.setText("");
        }else {
            toast_tv.setVisibility(View.VISIBLE);
            toast_tv.setText(mMessage);
        }
        TextPaint paint = toast_tv.getPaint();
        int width = (int) Layout.getDesiredWidth(toast_tv.getText().toString(), 0, toast_tv.getText().length(), paint);
        int totalWidth = width + mOtherWidth;

        if (totalWidth < mMinWidth) {
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(mMinWidth, RelativeLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
            toast_ll.setLayoutParams(layoutParams);
        } else if (totalWidth > mMinWidth && totalWidth < mMaxWidth) {
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
            toast_ll.setLayoutParams(layoutParams);
        } else if (totalWidth > mMaxWidth) {
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(mMaxWidth, RelativeLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
            toast_ll.setLayoutParams(layoutParams);
        }
        mHandle.postDelayed(mRunnable, 1500);
        mIsCancelAble = true;
    }

    @Override
    public void onCreateDialog() {
        if (!mIsSelfDialog) {
            rl_toastdialog_content.setVisibility(View.GONE);
            Toast.makeText(getContext(), mMessage, Toast.LENGTH_SHORT).show();
            dimissDialog();
        }
    }

    @Override
    public void onCreateView() {
        if (mIsSelfDialog) {
            rl_toastdialog_content.setVisibility(View.VISIBLE);
        }
    }

    public void setToastDimissListener(ToastDimissListener listener){
        this.mToastListener = listener;
    }

    public interface ToastDimissListener extends BaseToastDialogListener
    {
        void onDimissListener();
    }

}
