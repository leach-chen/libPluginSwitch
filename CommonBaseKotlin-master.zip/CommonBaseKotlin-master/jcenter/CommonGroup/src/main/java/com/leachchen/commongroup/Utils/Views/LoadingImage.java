package com.leachchen.commongroup.Utils.Views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

import com.leachchen.commongroup.R;


/**
 * ClassName:   LoadingImage.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/12/7 16:27
 **/

public class LoadingImage extends ImageView {

    private Context mContext;

    public LoadingImage(Context context) {
        super(context);
        init(context);
    }
    public LoadingImage(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }
    public LoadingImage(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }


    private void init(Context context)
    {
        this.mContext = context;
        startAnimation();
    }


    public void startAnimation()
    {
        this.clearAnimation();
        RotateAnimation refreshingAnimation = (RotateAnimation) AnimationUtils.loadAnimation(mContext, R.anim.rotating);
        LinearInterpolator lir = new LinearInterpolator();
        refreshingAnimation.setInterpolator(lir);
        this.setImageResource(R.drawable.ico_loading);
        this.startAnimation(refreshingAnimation);
    }

    public void startAnimation(int id,boolean isStart)
    {
        RotateAnimation refreshingAnimation = (RotateAnimation) AnimationUtils.loadAnimation(mContext, R.anim.rotating);
        LinearInterpolator lir = new LinearInterpolator();
        refreshingAnimation.setInterpolator(lir);
        this.setImageResource(id);
        if(isStart) {
            this.startAnimation(refreshingAnimation);
        }else
        {
            this.clearAnimation();
        }
    }

    public void stopAnimation()
    {
        this.clearAnimation();
    }

}
