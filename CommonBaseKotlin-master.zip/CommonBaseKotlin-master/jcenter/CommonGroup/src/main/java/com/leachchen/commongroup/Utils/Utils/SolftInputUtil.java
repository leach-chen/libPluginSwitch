package com.leachchen.commongroup.Utils.Utils;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

/**
 * ClassName:   SolftInputUtil.java
 * Description:
 * Author :     jame.liu
 * Date:        2017/12/30 11:32
 **/
public class SolftInputUtil {
    /**
     * 隐藏软键盘
     *
     * @param context
     */
    public static void hiddenKeyboard(Context context) {
        InputMethodManager im = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im.isActive()) {
            im.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    /**
     * 隐藏Activity里面获得焦点的View的软键盘
     *
     * @param activity
     */
    public static void hideSoftInputFromWindow(Activity activity) {
        InputMethodManager parentImm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (parentImm.isActive()) {
            View view = activity.getCurrentFocus();
            if (null != view) {
                parentImm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }

    /**
     * 隐藏Activity里面获得焦点的View的软键盘
     *
     * @param activity
     * @param view
     */
    public static void hideSoftInputFromWindow(Activity activity, View view) {
        InputMethodManager parentImm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (parentImm.isActive()) {
            if (null != view) {
                parentImm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }

    /**
     * 显示软键盘
     *
     * @param context
     */
    public static void showKeyboard(Context context) {
        InputMethodManager im = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        im.showInputMethodPicker();
    }

    /**
     * 显示该view的软键盘
     *
     * @param context
     */
    public static void showKeyboardAtView(View view, Context context) {

        view.setFocusable(true);
        view.requestFocus();
        InputMethodManager im = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        im.showSoftInputFromInputMethod(view.getApplicationWindowToken(), 0);
    }

}
