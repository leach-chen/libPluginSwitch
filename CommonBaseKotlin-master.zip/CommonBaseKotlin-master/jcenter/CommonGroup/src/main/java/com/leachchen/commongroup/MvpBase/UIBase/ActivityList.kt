package com.leachchen.commongroup.MvpBase.UIBase

import android.app.Activity

/**
 * ClassName:   ActivityList.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/29 17:25
 **/
class ActivityList private constructor(){
        companion object {
            private var mInstance : ActivityList ? = null
            get() {
                if(field == null)
                {
                    field = ActivityList()
                }
                return field
            }

            fun getInstance() = mInstance!!
        }

    /**
     * Activity栈
     */
    private val mActivityStack: MutableList<Activity>  = ArrayList()


    /**
     * 入栈
     * @param activity
     */
    fun push(activity: Activity)
    {
        mActivityStack.add(activity)
    }

    /**
     * 移除Activity
     * @param activity
     */
    fun pop(activity: Activity)
    {
        try {
            mActivityStack.remove(activity)
            activity.finish()
        }catch (e : Exception)
        {
            e.printStackTrace()
        }
    }

    /**
     * 移除Activity
     */
    fun pop()
    {
        try {
            var size = mActivityStack.size
            var activity = mActivityStack.get(size - 1)
            activity.finish()
            mActivityStack.remove(activity)
        }catch (e : Exception)
        {
            e.printStackTrace()
        }
    }

    /**
     * 退出所有Activity
     */
    fun popFinishAll()
    {
        for(activity in mActivityStack)
        {
            if(!activity.isFinishing)
            {
                activity.finish()
            }
        }
        mActivityStack.clear()
    }

    /**
     *  除了TargetActivity不Finish，其他栈内Activity都finish
     * @param targetActivityName
     */
    fun popFinishAllUntil(targetActivityName:String)
    {
        var targetActivity : Activity? = null
        for(activity in mActivityStack)
        {
            if(!activity.isFinishing)
            {
                if(activity.javaClass.simpleName == targetActivityName)
                {
                    targetActivity = activity
                }else {
                    activity.finish()
                }
            }
        }
        mActivityStack.clear()

        if(targetActivity != null)
        {
            mActivityStack.add(targetActivity)
        }

    }





}