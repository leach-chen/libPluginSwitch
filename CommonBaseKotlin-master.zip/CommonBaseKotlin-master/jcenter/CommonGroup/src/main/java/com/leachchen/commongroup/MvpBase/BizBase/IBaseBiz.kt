package com.leachchen.commongroup.MvpBase.BizBase

import com.leachchen.commongroup.Utils.Other.BInterface

/**
 * ClassName:   IBaseBiz.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/29 17:11
 **/
interface IBaseBiz {
    fun setPresenterCallBack(presenterCallBack : BInterface.PresenterCallBack)
}