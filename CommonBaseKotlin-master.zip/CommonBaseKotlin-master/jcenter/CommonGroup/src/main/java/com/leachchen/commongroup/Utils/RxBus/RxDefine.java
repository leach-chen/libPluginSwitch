package com.leachchen.commongroup.Utils.RxBus;

/**
 * ClassName:   RxDefine.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/27 14:46
 **/

public class RxDefine {
    public static final String RXBUS_SERVER_CODE = "rxbus_server_code";   //服务端返回的错误码
}
