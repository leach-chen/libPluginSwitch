package com.leachchen.commongroup.Utils.Dialog.DialogFragment;

import android.os.Bundle;

import java.lang.reflect.Field;

/**
 * ClassName:   DialogListenerManager.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/16 14:41
 **/

public class DialogFragmentListenerHolder {

    private final static String EXTRA_KEY = "key";
    private BaseDialogFragmentListener mListerer;
    private String mDialogListenerKey;


    public void setDialogListener(BaseDialogFragmentListener listener) {
        this.mListerer = listener;
        mDialogListenerKey = listener == null ? null : listener.getClass().getName();
    }

    public BaseDialogFragmentListener getDialogListener() {
        return mListerer;
    }

    public void saveDialogListenerKey(Bundle outState) {
        if (outState != null) {
            outState.putString(EXTRA_KEY, mDialogListenerKey);
        }
    }

    public void getDialogListenerKey(Bundle savedInstanceState) {
        if (null != savedInstanceState) {
            mDialogListenerKey = savedInstanceState.getString(EXTRA_KEY);
        }
    }

    public void restoreDialogListener(Object o) {
        if (o == null) {
            return;
        }
        if (!isNeedRestoreDialogListener()) {
            return;
        }
        if (o instanceof BaseDialogFragmentListener && o.getClass().getName().equals(mDialogListenerKey)) {
            setDialogListener((BaseDialogFragmentListener) o);
            return;
        }
        Class c = o.getClass();
        Field[] fs = c.getDeclaredFields();
        for (int i = 0; i < fs.length; i++) {
            Field f = fs[i];
            try {
                Object instance = f.get(o);
                if ((instance instanceof BaseDialogFragmentListener) && instance.getClass().getName().equals(mDialogListenerKey)) {
                    setDialogListener((BaseDialogFragmentListener) f.get(o));

                }
            } catch (Exception e) {

            }
        }
    }

    private boolean isNeedRestoreDialogListener() {
        return mDialogListenerKey == null ? false : mListerer == null;

    }
}
