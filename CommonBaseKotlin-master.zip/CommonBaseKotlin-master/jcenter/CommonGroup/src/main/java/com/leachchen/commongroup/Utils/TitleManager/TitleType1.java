package com.leachchen.commongroup.Utils.TitleManager;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.leachchen.commongroup.R;


/**
 * ClassName:   TitleType1.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/11/6 14:20
 **/

public class TitleType1 {

    View rl_title_bar;
    private LinearLayout ll_title_left, ll_title_right;
    private ImageView iv_title_left, iv_title_right;
    private TextView tv_title;

    public TitleType1(Activity activity, Context context) {
        rl_title_bar = activity.findViewById(R.id.rl_title_bar);
        ll_title_left = (LinearLayout) activity.findViewById(R.id.ll_title_left);
        ll_title_right = (LinearLayout) activity.findViewById(R.id.ll_title_right);
        iv_title_left = (ImageView) activity.findViewById(R.id.iv_title_left);
        iv_title_right = (ImageView) activity.findViewById(R.id.iv_title_right);
        tv_title = (TextView) activity.findViewById(R.id.tv_title);
    }

    public TitleType1(Activity activity, Context context, View view) {
        rl_title_bar = activity.findViewById(R.id.rl_title_bar);
        ll_title_left = (LinearLayout) view.findViewById(R.id.ll_title_left);
        ll_title_right = (LinearLayout) view.findViewById(R.id.ll_title_right);
        iv_title_left = (ImageView) view.findViewById(R.id.iv_title_left);
        iv_title_right = (ImageView) view.findViewById(R.id.iv_title_right);
        tv_title = (TextView) view.findViewById(R.id.tv_title);
    }

    /**
     * 设置标题栏背景色
     * @param color
     */
    public void setTitleBarBackgroud(int color){
        rl_title_bar.setBackgroundColor(color);
    }

    /**
     * 设置标题
     *
     * @param str
     */
    public void setTitle(String str) {
        if (str != null && tv_title != null) {
            tv_title.setText(str);
        }
    }

    /**
     * 设置左边图片
     *
     * @param drawable
     */
    public void setImageLeft(Drawable drawable) {
        if (iv_title_left != null) {
            iv_title_left.setImageDrawable(drawable);
        }
    }

    /**
     * 设置右边图片
     *
     * @param drawable
     */
    public void setImageRight(Drawable drawable) {
        if (iv_title_right != null) {
            iv_title_right.setImageDrawable(drawable);
        }
    }

    /**
     * 设置左边显示隐藏
     *
     * @param visible
     */
    public void setImageLeftVisible(int visible) {
        if (iv_title_left != null) {
            iv_title_left.setVisibility(visible);
        }
    }


    /**
     * 获取左边点击监听
     *
     * @return
     */
    public void setLeftListener(View.OnClickListener onClickListener) {
        if (ll_title_left != null) {
            ll_title_left.setOnClickListener(onClickListener);
        }
    }

    /**
     * 获取右边边点击监听
     *
     * @return
     */
    public void setRightListener(View.OnClickListener onClickListener) {
        if (ll_title_right != null) {
            ll_title_right.setOnClickListener(onClickListener);
        }
    }


}
