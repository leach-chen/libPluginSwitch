package com.leachchen.commongroup.Utils.Utils;

import android.app.Activity;
import android.content.res.Configuration;
import android.view.WindowManager;

/**
 * ClassName:   StatusControl.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/7/20 14:54
 **/

public class StatusControl {
    public static  void fullScreen(Activity activity, boolean enable) {
        if (enable) { //隐藏状态栏
            WindowManager.LayoutParams lp = activity.getWindow().getAttributes();
            lp.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
            activity.getWindow().setAttributes(lp);
            //activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            //againstLowProfile(activity);

/*            View decorView = activity.getWindow().getDecorView();
            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);*/

        } else { //显示状态栏
            WindowManager.LayoutParams lp = activity.getWindow().getAttributes();
            lp.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
            activity.getWindow().setAttributes(lp);
            //activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

            //enterLowProfile(activity);
        }
    }

    /**
     * judge the screen direction flag = 1 is shuping,flag = 2 is hengping
     */
    public static int ScreenOrientation(Activity activity)
    {
        int flag = -1;
        Configuration mConfiguration = activity.getResources().getConfiguration(); //获取设置的配置信息
        int ori = mConfiguration.orientation ;
        if(ori == mConfiguration.ORIENTATION_PORTRAIT) {
            flag = 1; //shu ping
        }else if(ori == mConfiguration.ORIENTATION_LANDSCAPE)
        {
            flag = 2; //hengping
        }
        return flag;
    }

}
