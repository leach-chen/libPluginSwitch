package com.leachchen.commongroup.Utils.Dialog.DialogActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.leachchen.commongroup.Utils.Dialog.DialogFragment.ToastDialogFragment;

/**
 * ClassName:   BaseDialogActivity.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/24 17:56
 **/

public abstract class BaseDialogActivity extends AppCompatActivity {

    public static final int DIALOG_ONE_POSITION = 1;
    public static final int DIALOG_TWO_POSITION = 2;


    protected static final String EXTRA_TITLE_KEY = "extra_title_key";
    protected static final String EXTRA_MESSAGE_KEY = "extra_message_key";
    protected static final String EXTRA_TXT_ONEBTN_KEY = "extra_txt_onebtn_key";
    protected static final String EXTRA_TXT_LEFTBTN_KEY = "extra_txt_leftbtn_key";
    protected static final String EXTRA_TXT_RIGHTBTN_KEY = "extra_txt_rightbtn_key";

    protected static final String EXTRA_COLOR_TITLE_KEY = "extra_color_title_key";
    protected static final String EXTRA_COLOR_MESSAGE_KEY = "extra_color_message_key";
    protected static final String EXTRA_COLOR_ONEBTN_KEY = "extra_color_one_key";
    protected static final String EXTRA_COLOR_LEFTBTN_KEY = "extra_color_leftbtn_key";
    protected static final String EXTRA_COLOR_RIGHTBTN_KEY = "extra_color_rightbtn_key";

    protected static final String EXTRA_CANCELABLE_KEY = "extra_cancelable_key";
    protected static final String EXTRA_SELFDIALOG_KEY = "extra_selfdialog_key";
    protected static final String EXTRA_WRAPMESSAGE_KEY = "extra_wrapmessage_key";
    protected static final String EXTRA_TOASTTYPE_KEY = "extra_toasttype_key";

    protected String mTitle = "";   //标题
    protected String mMessage = ""; //内容
    protected String mOneBtnText = "";//单个按钮文案
    protected String mTwoBtnLeftText = "";//左按钮文案
    protected String mTwoBtnRightText = "";//右按钮文案
    protected boolean mIsCancelAble = false; //是否点击空白区域可以取消 true可以取消，false不可以
    protected boolean mIsSelfDialog = true; //是否是自定义的窗口   true是自定义窗口，false为系统窗口
    protected boolean mIsWrapMessage = false; //是否窗口高度适应内容  true为适应高度，false为固定高度
    protected int mToastDialogType = 1001; //toast弹窗类型


    protected Class<?> mClassz;
    protected  BaseDialogActivity mInstance;
    protected Bundle mBundle;

    protected static BaseDialogActivityListener mBtnOneListener;
    protected static BaseDialogActivityListener mBtnTwoListener;

    protected boolean isShowing; //弹窗是否已显示


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mTitle = this.getIntent().getExtras().getString(EXTRA_TITLE_KEY, "");
        mMessage = this.getIntent().getExtras().getString(EXTRA_MESSAGE_KEY, "");
        mOneBtnText = this.getIntent().getExtras().getString(EXTRA_TXT_ONEBTN_KEY, "")/* == null ? "" : getArguments().getString(EXTRA_TXT_ONEBTN_KEY)*/;
        mTwoBtnLeftText = this.getIntent().getExtras().getString(EXTRA_TXT_LEFTBTN_KEY, "");
        mTwoBtnRightText = this.getIntent().getExtras().getString(EXTRA_TXT_RIGHTBTN_KEY, "");
        mIsCancelAble = this.getIntent().getExtras().getBoolean(EXTRA_CANCELABLE_KEY, true);
        mIsSelfDialog = this.getIntent().getExtras().getBoolean(EXTRA_SELFDIALOG_KEY, true);
        mIsWrapMessage = this.getIntent().getExtras().getBoolean(EXTRA_WRAPMESSAGE_KEY, false);
        mToastDialogType = this.getIntent().getExtras().getInt(EXTRA_TOASTTYPE_KEY, ToastDialogFragment.SHOW_SUCCESS);
    }

    protected void init() {
        initView();
        setListener();
        initData();
        onCreateDialog();
        onCreateView();
    }

    public BaseDialogActivity setTitle(String title) {
        if (title == null) title = "";
        mBundle.putString(EXTRA_TITLE_KEY, title);
        return mInstance;
    }

    public BaseDialogActivity setMessage(String message) {
        if (message == null) message = "";
        mBundle.putString(EXTRA_MESSAGE_KEY, message);
        return mInstance;
    }


    public BaseDialogActivity setCancelAble(boolean isCancelAble) {
        mBundle.putBoolean(EXTRA_CANCELABLE_KEY, isCancelAble);
        return mInstance;
    }

    public BaseDialogActivity setSelfDialog(boolean isSelfDialog) {
        mBundle.putBoolean(EXTRA_SELFDIALOG_KEY, isSelfDialog);
        return mInstance;
    }

    public BaseDialogActivity setWrapContent(boolean isWrapContent) {
        mBundle.putBoolean(EXTRA_WRAPMESSAGE_KEY, isWrapContent);
        return mInstance;
    }


    public BaseDialogActivity setToastType(int type) {
        mBundle.putInt(EXTRA_TOASTTYPE_KEY, type);
        return mInstance;
    }

    public BaseDialogActivity setBtnOneListener(BaseDialogActivityListener listener) {
        mBtnOneListener = listener;
        return mInstance;
    }

    public BaseDialogActivity setBtnTwoListener(BaseDialogActivityListener listener) {
        mBtnTwoListener = listener;
        return mInstance;
    }

    public void showDialog(Context context)
    {
        if(!isShowing) {
            Intent intent = new Intent();
            intent.setClass(context, mClassz);
            startActivity(context, mClassz, mBundle);
        }
        isShowing = true;
    }

    private void startActivity(Context context, Class<?> cls, Bundle bundle)
    {
        Intent intent = new Intent();
        intent.setClass(context,cls);
        if(bundle != null)
        {
            intent.putExtras(bundle);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }


    public abstract void onCreateDialog();

    public abstract void onCreateView();

    protected abstract void initView();

    protected abstract void setListener();

    protected abstract void initData();

    public abstract void dimissDialog();

}
