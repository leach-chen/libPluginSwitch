package com.leachchen.commongroup.Utils.Views;

import android.content.Context;
import android.graphics.Canvas;
import android.support.v4.view.ViewPager;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.leachchen.commongroup.R;

import java.util.ArrayList;
import java.util.List;

/**
 * ClassName:   CircleIndicatorView.java
 * Description:
 * Author :     vincent.chen
 * Date:        2017/12/26 19:04
 **/
public class CircleIndicatorView extends LinearLayout implements ViewPager.OnPageChangeListener  {

    private List<ImageView> mDotViewList;
    private ViewPager mViewPager;
    private int mCount; // indicator 的数量
    private Context mContext;
    private int mIndicatorHeight;
    private int currentNo = 0;
    private int mStartWidth = 0;//缩小的宽
    private int mEndWidth  = 0;//放大的宽
    private int m_dp5;

    public CircleIndicatorView(Context context) {
        super(context);
        mContext = context;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    public void setViewPager(ViewPager viewPager) {
        releaseViewPager();
        if(viewPager == null || viewPager.getAdapter() == null){
            return;
        }
        mViewPager = viewPager;
        mViewPager.addOnPageChangeListener(this);
        int count = mViewPager.getAdapter().getCount();
        setCount(count);
        initView();
    }

    private void initView() {
        mDotViewList = new ArrayList<>();
        mIndicatorHeight  = mContext.getResources().getDimensionPixelOffset(R.dimen.dp_10);
        m_dp5 = mContext.getResources().getDimensionPixelOffset(R.dimen.dp_5);

        mDotViewList.clear();
        removeAllViews();
        for (int i = 0; i < mCount; i++) {
            ImageView iv = new ImageView(mContext);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(mIndicatorHeight, mIndicatorHeight);
            params.leftMargin = mContext.getResources().getDimensionPixelOffset(R.dimen.dp_10);
            if (currentNo == i) {
                iv.setImageResource(R.drawable.blue_radius);
                params.width = mIndicatorHeight * 2;
            } else {
                iv.setImageResource(R.drawable.white_radius);
                params.width = mIndicatorHeight;
            }
            iv.setLayoutParams(params);
            mDotViewList.add(iv);
            addView(iv);
        }
    }

    private void releaseViewPager() {
        if(mViewPager!=null){
            mViewPager.removeOnPageChangeListener(this);
            mViewPager = null;
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        changeDot(position,positionOffset);
    }

    @Override
    public void onPageSelected(int position) {
        currentNo = position;
        for (int i = 0; i < mCount;i++){
            if (currentNo == i) {
                mDotViewList.get(i).setImageResource(R.drawable.blue_radius);
            } else {
                mDotViewList.get(i).setImageResource(R.drawable.white_radius);
            }
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    public void setCount(int count) {
        mCount = count;
    }

    /**
     * 圆点变化
     * @param position
     * @param positionOffset
     */
    private void changeDot(int position, float positionOffset) {

        boolean right = position + positionOffset - currentNo > 0;
        if (right){//右边圆点变大，自己变小
            drawByPositionOffset(currentNo,(currentNo+1),positionOffset);
        }else {
            drawByPositionOffset(currentNo,(currentNo-1),1 - positionOffset);
        }

    }

    /**
     * 指示器偏移动画
     * @param fromPos   开始点，变小
     * @param toPos     目标点，变大
     * @param positionOffset    放大缩小倍数
     */
    private void drawByPositionOffset(int fromPos, int toPos, float positionOffset) {

        if (positionOffset == 0 || positionOffset >= 1.0f || fromPos <0 || toPos < 0){
            return;
        }

        mStartWidth = (int) (mIndicatorHeight*2 - mIndicatorHeight*positionOffset);
        mEndWidth = (int) (mIndicatorHeight + mIndicatorHeight*positionOffset);
        if (mEndWidth == (mIndicatorHeight*2-1)){
            mEndWidth = mIndicatorHeight*2;
        }

//        LogWrite.e("fromPos:" + fromPos + "    toPos:" + toPos + "  positionOffset:"+positionOffset+"    isTurnRight:" + isTurnRight + "    mStartWidth:"+mStartWidth+"    mEndWidth:"+mEndWidth , LogModel.MODEL_COMMON);

        ImageView iv_unselect =  mDotViewList.get(fromPos);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(mStartWidth, mIndicatorHeight);
        params.leftMargin = m_dp5;
        params.rightMargin = m_dp5;
        iv_unselect.setLayoutParams(params);

        ImageView iv_select = mDotViewList.get(toPos);
        LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(mEndWidth, mIndicatorHeight);
        params1.leftMargin = m_dp5;
        params1.rightMargin = m_dp5;
        iv_select.setLayoutParams(params1);

        for (int i = 0;i<mDotViewList.size();i++){
            if (i!=fromPos && i!=toPos){
                ImageView iv_other = mDotViewList.get(i);
                LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(mIndicatorHeight, mIndicatorHeight);
                params2.leftMargin = m_dp5;
                params2.rightMargin = m_dp5;
                iv_other.setLayoutParams(params2);
            }
        }
    }

}
