package com.leachchen.commongroup.MvpBase.BizBase

import com.leachchen.commongroup.Utils.Other.BInterface

/**
 * ClassName:   BaseBiz.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/29 17:10
 **/
abstract class BaseBiz:IBaseBiz{
    protected var mPresenterCallBack: BInterface.PresenterCallBack? = null
}