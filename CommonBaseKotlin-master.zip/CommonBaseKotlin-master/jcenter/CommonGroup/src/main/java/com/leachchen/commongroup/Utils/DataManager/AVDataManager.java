package com.leachchen.commongroup.Utils.DataManager;

/**
 * ClassName:   AVDataManager.java
 * Description:
 * Author :     vincent.chen
 * Date:        2017/9/6 13:37
 **/
public class AVDataManager {

    private int SlowPlayCount = 7;
    private int SlowPlaySpeed = 7;
    public int DecFPS = 0;

    private AVDataQueue VideoDataQueue;
    private AVDataQueue AudioDataQueue;

    public AVDataManager(){
        VideoDataQueue = new AVDataQueue();
        AudioDataQueue = new AVDataQueue();
    }

    public void AddVideoData(AVData avData){
        VideoDataQueue.addLast(avData);
    }

    public void AddAudioData(AVData avData){
        AudioDataQueue.addLast(avData);
    }

    public AVData GetVideoData(){
        return VideoDataQueue.removeHead();
    }

    public AVData GetAudioData(){
        return AudioDataQueue.removeHead();
    }

    public int getVideoDataSize(){
        return VideoDataQueue.getDataCount();
    }

    public int getAudioDataSize(){
        return AudioDataQueue.getDataCount();
    }

    public void RemoveVideoData(){
        VideoDataQueue.removeAll();
    }

    public void RemoveAudioData(){
        AudioDataQueue.removeAll();
    }

    public void RemoveAllData(){
        VideoDataQueue.removeAll();
        AudioDataQueue.removeAll();
    }

    public int getSlowPlayCount() {
        return SlowPlayCount;
    }

    public void setSlowPlayCount(int slowPlayCount) {
        SlowPlayCount = slowPlayCount;
    }

    public int getSlowPlaySpeed() {
        return SlowPlaySpeed;
    }

    public void setSlowPlaySpeed(int slowPlaySpeed) {
        SlowPlaySpeed = slowPlaySpeed;
    }
}
