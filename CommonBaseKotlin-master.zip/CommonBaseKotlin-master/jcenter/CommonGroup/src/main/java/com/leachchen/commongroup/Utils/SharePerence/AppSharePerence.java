package com.leachchen.commongroup.Utils.SharePerence;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * ClassName:   AppSharePerence.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/5/5 11:55
 **/
public class AppSharePerence {

    private SharedPreferences mSharedPreferences;

    private static AppSharePerence mInstance;
    public static final String SHAREDPREFERENCE = "sharedpreference";

    public AppSharePerence(Context context)
    {
        mSharedPreferences = context.getSharedPreferences(SHAREDPREFERENCE,0);
    }

    public static AppSharePerence getInstance(Context context)
    {
        if(mInstance == null)
        {
            mInstance = new AppSharePerence(context);
        }

        return  mInstance;
    }


    public void saveString(String key, String value)
    {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putString(key,value);
        editor.commit();
    }

    public String getString(String key)
    {
        return mSharedPreferences.getString(key,"");
    }

    public String getString(String key, String defaultValue)
    {
        return mSharedPreferences.getString(key,defaultValue);
    }

    public void saveInt(String key, int value)
    {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putInt(key,value);
        editor.commit();
    }

    public int getInt(String key)
    {
        return mSharedPreferences.getInt(key,0);
    }


    public void saveBoolean(String key, boolean value)
    {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putBoolean(key,value);
        editor.commit();
    }

    //默认false,DataManager.java中需要依赖该默认值
    public boolean getBooleanDefaultFalse(String key)
    {
        return mSharedPreferences.getBoolean(key,false);
    }


    //默认false,DataManager.java中需要依赖该默认值
    public boolean getBooleanDefaultTrue(String key)
    {
        return mSharedPreferences.getBoolean(key,true);
    }


}
