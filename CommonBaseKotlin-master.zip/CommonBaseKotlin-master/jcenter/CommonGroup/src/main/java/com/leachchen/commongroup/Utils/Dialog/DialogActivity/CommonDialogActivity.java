package com.leachchen.commongroup.Utils.Dialog.DialogActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.leachchen.commongroup.R;

public class CommonDialogActivity extends BaseDialogActivity {

    private static boolean isTwoBtnShow;//是否显示两个按钮
    private TextView tv_dialog_title, tv_dialog_message;
    private Button btn_dialog_finish, btn_dialog_left, btn_dialog_right;
    private LinearLayout ll_dialog_bomcontent, ll_dialog_tm, ll_dialog_one, ll_dialog_two, ll_dialog_content;
    private RelativeLayout rl_dialog_content;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_common);
        init();
    }

    @Override
    public void onCreateDialog() {
        if (!mIsSelfDialog) {
            ll_dialog_content.setVisibility(View.GONE);
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            if (!TextUtils.isEmpty(mTitle)) {
                builder.setTitle(mTitle);
            }
            if (!TextUtils.isEmpty(mMessage)) {
                builder.setMessage(mMessage);
            }

            if (isTwoBtnShow) {
                builder.setPositiveButton(mTwoBtnLeftText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mBtnOneListener != null) mBtnOneListener.onClickListener(DIALOG_ONE_POSITION,CommonDialogActivity.this);
                    }
                });

                builder.setNegativeButton(mTwoBtnRightText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mBtnTwoListener != null) mBtnTwoListener.onClickListener(DIALOG_TWO_POSITION,CommonDialogActivity.this);
                    }
                });
            } else {
                builder.setPositiveButton(mOneBtnText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mBtnOneListener != null) mBtnOneListener.onClickListener(DIALOG_ONE_POSITION,CommonDialogActivity.this);
                    }
                });
            }
            builder.create();
            builder.show();
        }
    }

    @Override
    public void onCreateView() {
        if (mIsSelfDialog) {
            ll_dialog_content.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void initView() {
        tv_dialog_title = (TextView) this.findViewById(R.id.tv_dialog_title);
        tv_dialog_message = (TextView) this.findViewById(R.id.tv_dialog_message);
        btn_dialog_finish = (Button) this.findViewById(R.id.btn_dialog_finish);
        ll_dialog_bomcontent = (LinearLayout) this.findViewById(R.id.ll_dialog_bomcontent);
        ll_dialog_tm = (LinearLayout) this.findViewById(R.id.ll_dialog_tm);
        rl_dialog_content = (RelativeLayout) this.findViewById(R.id.rl_dialog_content);
        ll_dialog_one = (LinearLayout) this.findViewById(R.id.ll_dialog_one);
        ll_dialog_two = (LinearLayout) this.findViewById(R.id.ll_dialog_two);
        btn_dialog_left = (Button) this.findViewById(R.id.btn_dialog_left);
        btn_dialog_right = (Button) this.findViewById(R.id.btn_dialog_right);
        ll_dialog_content = (LinearLayout) this.findViewById(R.id.ll_dialog_content);
    }

    @Override
    protected void setListener() {
        btn_dialog_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBtnOneListener != null) mBtnOneListener.onClickListener(DIALOG_ONE_POSITION,CommonDialogActivity.this);
            }
        });

        btn_dialog_left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBtnOneListener != null) mBtnOneListener.onClickListener(DIALOG_ONE_POSITION,CommonDialogActivity.this);
            }
        });

        btn_dialog_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBtnTwoListener != null) mBtnTwoListener.onClickListener(DIALOG_TWO_POSITION,CommonDialogActivity.this);
            }
        });
    }

    @Override
    protected void initData() {
        tv_dialog_title.setText(mTitle);
        tv_dialog_message.setText(mMessage);
        btn_dialog_finish.setText(mOneBtnText);
        btn_dialog_left.setText(mTwoBtnLeftText);
        btn_dialog_right.setText(mTwoBtnRightText);
        if (TextUtils.isEmpty(mTitle)) {
            tv_dialog_title.setVisibility(View.GONE);
        }
        wrapMessage();
        if (isTwoBtnShow) {
            ll_dialog_one.setVisibility(View.GONE);
            ll_dialog_two.setVisibility(View.VISIBLE);
        } else {
            ll_dialog_one.setVisibility(View.VISIBLE);
            ll_dialog_two.setVisibility(View.GONE);
        }
    }

    private void wrapMessage() {
        Context context = this;
        if (mIsWrapMessage) {
            int width = (int) context.getResources().getDimension(R.dimen.dp_270);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT);
            rl_dialog_content.setLayoutParams(params);

            RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            params1.leftMargin = (int) context.getResources().getDimension(R.dimen.dp_10);
            params1.rightMargin = (int) context.getResources().getDimension(R.dimen.dp_10);
            params1.topMargin = (int) context.getResources().getDimension(R.dimen.dp_18);
            ll_dialog_tm.setId(R.id.wrap_dialog);
            ll_dialog_tm.setLayoutParams(params1);

            int btnHeight = (int) context.getResources().getDimension(R.dimen.dp_44);
            RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, btnHeight);
            params2.addRule(RelativeLayout.BELOW, R.id.wrap_dialog);
            ll_dialog_bomcontent.setLayoutParams(params2);
        } else {
            int width = (int) context.getResources().getDimension(R.dimen.dp_270);
            int height = (int) context.getResources().getDimension(R.dimen.dp_148);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
            rl_dialog_content.setLayoutParams(params);

            int btnHeight = (int) context.getResources().getDimension(R.dimen.dp_44);
            RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, btnHeight);
            params2.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            ll_dialog_bomcontent.setLayoutParams(params2);
            ll_dialog_bomcontent.setId(R.id.size_dialog);

            RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
            params1.leftMargin = (int) context.getResources().getDimension(R.dimen.dp_10);
            params1.rightMargin = (int) context.getResources().getDimension(R.dimen.dp_10);
            params1.topMargin = (int) context.getResources().getDimension(R.dimen.dp_18);
            params1.addRule(RelativeLayout.ABOVE, R.id.size_dialog);
            ll_dialog_tm.setLayoutParams(params1);
        }
    }

    @Override
    public void dimissDialog() {
        isShowing = false;
        CommonDialogActivity.this.finish();
        mInstance.finish();
    }

    public CommonDialogActivity newOneBtnInstance(String message, String oneBtnText, CommonDialogActivity commonDialogActivity) {
        mClassz = commonDialogActivity.getClass();
        mBundle = new Bundle();
        mBundle.putString(EXTRA_MESSAGE_KEY, message);
        mBundle.putString(EXTRA_TXT_ONEBTN_KEY, oneBtnText);
        isTwoBtnShow = false;
        mInstance = commonDialogActivity;
        return commonDialogActivity;
    }

    public  CommonDialogActivity newTwoBtnInstance(String message, String twoBtnLeftText, String twoBtnRightText) {
        mBundle = new Bundle();
        mBundle.putString(EXTRA_MESSAGE_KEY, message);
        mBundle.putString(EXTRA_TXT_LEFTBTN_KEY, twoBtnLeftText);
        mBundle.putString(EXTRA_TXT_RIGHTBTN_KEY, twoBtnRightText);
        isTwoBtnShow = true;
        mInstance = new CommonDialogActivity();
        return (CommonDialogActivity) mInstance;
    }

}
