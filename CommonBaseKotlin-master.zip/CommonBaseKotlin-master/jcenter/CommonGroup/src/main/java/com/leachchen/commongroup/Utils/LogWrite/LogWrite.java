package com.leachchen.commongroup.Utils.LogWrite;

import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.Log;

import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.FormatStrategy;
import com.orhanobut.logger.Logger;
import com.orhanobut.logger.PrettyFormatStrategy;
import com.tencent.bugly.crashreport.CrashReport;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;


/**
 * ClassName:   LogWrite.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/6/15 15:57
 **/

public class LogWrite extends LogModel {
    private static String mFilePath = "";
    private static Handler mHandler;
    private static HandlerThread mHandlerThread;
    private static String mLogname;
    private static String mTag;
    private static boolean mIsShowSystemLog;

    /**
     * @param tag   打印log的tag
     * @param filePath  异常日志保存路径
     * @param isDebug   是否是debug模式，true打印日志，false不打印日志
     * @param isShowSystemLog   是否用系统打印日志方式打印log
     * @param methodCount   log打印显示的函数层级
     */
    public static void init(String tag, String filePath, boolean isDebug, boolean isShowSystemLog, int methodCount) {
        mFilePath = filePath;
        mIsDebug = isDebug;
        mTag = tag;
        mIsShowSystemLog = isShowSystemLog;
        setFormat(tag, methodCount);

        // 初始化handler线程处理
        mHandlerThread = new HandlerThread("writelog");
        mHandlerThread.start();
        mHandler = new Handler(mHandlerThread.getLooper());

        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();
        SimpleDateFormat sdformat = new SimpleDateFormat("HH_mm_ss", Locale.getDefault());//24小时制
        mLogname = sdformat.format(date).toString();
    }


    /**
     * 该函数可以重设tag，及显示的函数层级
     * @param tag
     * @param methodCount
     */
    public static void setFormat(String tag, int methodCount) {
        mTag = tag;
        clearFormat();
        FormatStrategy oneFormatStrategy;
        if (TextUtils.isEmpty(tag)) {
            oneFormatStrategy = PrettyFormatStrategy.newBuilder()
                    .showThreadInfo(false)
                    .methodCount(methodCount)
                    .build();
        } else {
            oneFormatStrategy = PrettyFormatStrategy.newBuilder()
                    .showThreadInfo(false)
                    .methodCount(methodCount)
                    .tag(tag)
                    .build();
        }
        Logger.addLogAdapter(new AndroidLogAdapter(oneFormatStrategy));
    }

    public static void clearFormat() {
        Logger.clearLogAdapters();
    }

    /**
     * 打印json数据
     * @param str 日志内容
     * @param model 详见LogModel
     */
    public static void json(String str, int model) {
        if (isShowLog(model)) {
            Logger.json(str);
        }
    }

    /**
     * 打印map数据
     * @param map 日志内容
     * @param model 详见LogModel
     */
    public static void map(Map<Object, Object> map, int model) {
        if (isShowLog(model)) {
            Logger.d(map);
        }
    }


    /**
     * 打印普通日志
     * @param str 日志内容
     * @param model 详见LogModel
     */
    public static void d(String str, int model) {
        if (isShowLog(model)) {
            if (mIsShowSystemLog) {
                if (isShowLog(model))
                    Log.d(mTag, logShowStr(str, model));
            } else {
                if (isShowLog(model))
                    Logger.d(logShowStr(str, model));
            }
        }
    }

    /**
     * 打印标红日志
     * @param str 日志内容
     * @param model 详见LogModel
     */
    public static void e(String str, int model) {
        if (isShowLog(model)) {
            if (mIsShowSystemLog) {
                if (isShowLog(model))
                    Log.e(mTag, logShowStr(str, model));
            } else {
                if (isShowLog(model))
                    Logger.e(logShowStr(str, model));
            }
        }
    }


    /**
     * 异常日志保存至文件
     * @param e
     */
    public static void writeMsg(Throwable e) {
        CrashReport.postCatchedException(e);
        Writer writer = new StringWriter();
        PrintWriter printWriter = new PrintWriter(writer);
        e.printStackTrace(printWriter);
        Throwable cause = e.getCause();
        while (cause != null) {
            cause.printStackTrace(printWriter);
            cause = cause.getCause();
        }
        printWriter.close();
        final String result = writer.toString();
        Logger.e(result);
        mHandler.post(new WriteRunnable(result));
    }

    static class WriteRunnable implements Runnable {
        private String msg;

        public WriteRunnable(String msg) {
            this.msg = msg;
        }

        @Override
        public void run() {
            //获取文件路径
            RandomAccessFile rFile = makeRandomFile();
            //将日志写入文件
            if (rFile != null) {
                try {
                    rFile.seek(rFile.length());
                    byte[] bytemsg = (msg + "\n\n\n").getBytes("gbk");
                    rFile.write(bytemsg);
                    rFile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static RandomAccessFile makeRandomFile() {
        //判断是否有sd卡
        boolean sdCardExist = Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED);

        RandomAccessFile randomAccessFile = null;

        if (sdCardExist) {

            //检查根目录
            File rootDir = new File(mFilePath);
            if (!rootDir.exists()) {
                rootDir.mkdir();
            }

            //新建日期文件夹
            Calendar calendar = Calendar.getInstance();
            Date date = calendar.getTime();
            DateFormat dateFormat = new DateFormat();
            String dateString = dateFormat.format("yyyy-MM-dd", date)
                    .toString();
            File logDir = new File(rootDir.getPath() + File.separator
                    + dateString);
            if (!logDir.exists()) {
                logDir.mkdir();
            }

            String filename = logDir.getPath() + File.separator + mLogname + ".txt";
            File logfile = new File(filename);

            //新建RandomAccessFile 文件
            try {
                randomAccessFile = new RandomAccessFile(logfile, "rw");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return randomAccessFile;
    }

    /*    private static void loggerD(String str, boolean model) {
        if (isShowLog(model))
            Logger.d(str);
    }

    private static void loggerE(String str, boolean model) {
        if (isShowLog(model))
            Logger.e(str);
    }

    private static void systemD(String str, boolean model) {
        if (isShowLog(model))
            Log.d(mTag,str);
    }

    private static void systemE(String str, boolean model) {
        if (isShowLog(model))
            Log.e(mTag,str);
    }*/

}
