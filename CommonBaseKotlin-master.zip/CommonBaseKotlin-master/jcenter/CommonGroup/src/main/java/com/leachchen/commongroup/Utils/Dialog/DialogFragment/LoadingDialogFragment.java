package com.leachchen.commongroup.Utils.Dialog.DialogFragment;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import com.leachchen.commongroup.R;

/**
 * ClassName:   LoadingDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/20 16:56
 **/

public class LoadingDialogFragment extends BaseDialogFragment{

    private LoadingDialogListener mListener;
    private TextView loading_tv;


    public static LoadingDialogFragment newInstance(FragmentManager fragmentManager, String dialogId) {
        mFragmentManager = fragmentManager;
        mDialogId = dialogId;
        mInstance = new LoadingDialogFragment();
        mBundle = new Bundle();
        return (LoadingDialogFragment) mInstance;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        if (!mIsSelfDialog) {
            ProgressDialog dialog = new ProgressDialog(getActivity());
            if(!mTitle.equals(""))
            {
                dialog.setTitle(mTitle);
            }
            if(!mMessage.equals(""))
            {
                dialog.setMessage(mMessage);
            }
            return dialog;
        } else {
            return super.onCreateDialog(savedInstanceState);
        }
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mIsSelfDialog) {
            getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
            getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            getDialog().getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            mView = inflater.inflate(R.layout.dialog_loading, container, false);
            initDialog();
            return mView;
        } else {
            return super.onCreateView(inflater, container, savedInstanceState);
        }
    }

    @Override
    protected void initView() {
        loading_tv =  (TextView)mView.findViewById(R.id.loading_tv);
    }

    @Override
    protected void setListener() {

    }

    @Override
    protected void initData() {
        if(!TextUtils.isEmpty(mMessage))
        {
            loading_tv.setVisibility(View.VISIBLE);
            loading_tv.setText(mMessage);
        }else
        {
            loading_tv.setVisibility(View.GONE);
        }
    }

    @Override
    public void setDialogListener(BaseDialogFragmentListener listener) {
        if (listener instanceof LoadingDialogListener) {
            mListener   = (LoadingDialogListener) listener;
        }
    }

    public interface LoadingDialogListener extends BaseDialogFragmentListener
    {

    }

}
