package com.leachchen.commongroup.Utils.Banner.listener;

public interface OnBannerListener {
    public void OnBannerClick(int position);
    public void OnBannerMove(boolean isMove);
}
