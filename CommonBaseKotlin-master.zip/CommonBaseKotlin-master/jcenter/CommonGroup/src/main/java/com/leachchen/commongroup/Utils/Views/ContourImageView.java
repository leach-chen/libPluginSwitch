package com.leachchen.commongroup.Utils.Views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;

/**
 * ClassName:   ContourImageView.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/1/6 15:29
 **/

public class ContourImageView extends android.support.v7.widget.AppCompatImageView {

    private int color = Color.parseColor("#00000000");

    public ContourImageView(Context context) {
        super(context);
    }

    public ContourImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ContourImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
        Rect rect = canvas.getClipBounds();
        Paint paint = new Paint();
        paint.setColor(color);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(6);
        canvas.drawRect(rect,paint);
    }

    public void updateImage(int color)
    {
        this.color = color;
        this.postInvalidate();
    }


}
