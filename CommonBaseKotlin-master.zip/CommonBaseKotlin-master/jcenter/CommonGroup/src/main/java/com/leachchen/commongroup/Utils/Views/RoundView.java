package com.leachchen.commongroup.Utils.Views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

/**
 * ClassName:   RoundView.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/4/27 13:58
 **/

public class RoundView extends View {

    private int mColor;

    public RoundView(Context context) {
        super(context);
        init();
    }

    public RoundView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RoundView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init()
    {
        mColor = Color.parseColor("#e6e6e6");
    }

    @Override
    public void onDraw(Canvas canvas)
    {
        Paint paint = new Paint();
        paint.setColor(mColor);
        paint.setAntiAlias(true);
        canvas.drawCircle(getWidth()/2,getHeight()/2,getWidth()/2,paint);
    }

    public void setRoundColor(int color)
    {
        this.mColor = color;
        invalidate();
    }
}
