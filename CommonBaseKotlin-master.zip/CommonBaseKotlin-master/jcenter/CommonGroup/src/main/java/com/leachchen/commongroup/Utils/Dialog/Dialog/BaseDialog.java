package com.leachchen.commongroup.Utils.Dialog.Dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.view.KeyEvent;

import com.leachchen.commongroup.MvpBase.UIBase.BaseActivity;
import com.leachchen.commongroup.R;
import com.leachchen.commongroup.Utils.LogWrite.LogWrite;

/**
 * ClassName:   BaseDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/27 10:06
 **/

public abstract class BaseDialog extends Dialog {

    protected Context mContext;
    protected String mTitle = "";   //标题
    protected String mMessage = ""; //内容
    protected String mOneBtnText = "";//单个按钮文案
    protected String mTwoBtnLeftText = "";//左按钮文案
    protected String mTwoBtnRightText = "";//右按钮文案
    protected boolean mIsCancelAble = false; //是否点击空白区域可以取消 true可以取消，false不可以
    protected boolean mIsSelfDialog = true; //是否是自定义的窗口   true是自定义窗口，false为系统窗口
    protected int mTitleColor = this.getContext().getResources().getColor(R.color.color_2B2B2B);    //标题颜色
    protected int mMessageColor = this.getContext().getResources().getColor(R.color.color_2B2B2B);  //消息颜色
    protected float mTitleSize = this.getContext().getResources().getDimensionPixelSize(R.dimen.sp_18);
    protected float mMessageSize = this.getContext().getResources().getDimensionPixelSize(R.dimen.sp_14);


    protected AlertDialog.Builder mBuilder;
    protected AlertDialog mAlertDialog;
    protected ProgressDialog mProgressDialog;


    public BaseDialog(@NonNull Context context, int theme) {
        super(context, theme);
        mContext = context;
    }

    protected void createInit() {
        initView();
        setListener();
    }


    protected void showInit() {
        initData();
        onCreateDialog();
        onCreateView();
        setCanceledOnTouchOutside(mIsCancelAble);
        if (mIsCancelAble) {
            setOnKeyListener(new DialogInterface.OnKeyListener() {
                public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
                    return false;
                }
            });
        } else {
            setOnKeyListener(new DialogInterface.OnKeyListener() {
                public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
                    if (i == KeyEvent.KEYCODE_BACK) {
                        return true;
                    }
                    return false;
                }
            });
        }
    }


    public void showDialog() {
        if (mContext == null || ((BaseActivity)mContext).isFinishing()){
            return;
        }
        ((BaseActivity)mContext).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    showInit();
                    if (mIsSelfDialog) {
                        show();
                    } else {
                        if (mBuilder != null) {
                            mAlertDialog = mBuilder.create();
                            mAlertDialog.show();
                        }

                        if (mProgressDialog != null) {
                            mProgressDialog.show();
                        }
                    }
                }catch (Exception e)
                {
                    LogWrite.writeMsg(e);
                }
            }
        });
    }

    public void dimissDialog() {
        try{
            if (mContext == null || ((BaseActivity)mContext).isFinishing()){
                return;
            }
            mMessage = "";
            if (mIsSelfDialog) {
                this.dismiss();
            } else {
                if (mAlertDialog != null)
                    mAlertDialog.dismiss();
                if (mProgressDialog != null)
                    mProgressDialog.dismiss();
            }
        }catch (Exception e){
            LogWrite.writeMsg(e);
        }
    }


    public abstract void onCreateDialog();

    public abstract void onCreateView();

    protected abstract void initView();

    protected abstract void setListener();

    protected abstract void initData();

}
