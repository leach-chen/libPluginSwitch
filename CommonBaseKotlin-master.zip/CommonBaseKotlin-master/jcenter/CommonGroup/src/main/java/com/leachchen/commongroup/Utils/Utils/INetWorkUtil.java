package com.leachchen.commongroup.Utils.Utils;

/**
 * ClassName:   INetWorkUtil.java
 * Description:
 * Author :     vincent.chen
 * Date:        2017/12/19 19:49
 **/
public interface INetWorkUtil {
    public void onSuccess();
    public void onFail();
}
