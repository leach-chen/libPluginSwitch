package com.leachchen.commongroup.Utils.Dialog.DialogFragment;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.text.Layout;
import android.text.TextPaint;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.leachchen.commongroup.R;

/**
 * ClassName:   ToastDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/23 16:08
 **/

public class ToastDialogFragment extends BaseDialogFragment {

    public static final int SHOW_SUCCESS = 1001;
    public static final int SHOW_WARNING = 1002;
    public static final int SHOW_FAIL = 1003;
    private ToastDialogListener mListener;
    private Handler mHandle = new Handler();
    private ImageView toast_iv;
    private TextView toast_tv;
    private LinearLayout toast_ll;
    private int mOtherWidth = 0;
    private int mMaxWidth = 0;
    private int mMinWidth = 0;

    @Override
    public void onStart() {
        super.onStart();
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams windowParams = window.getAttributes();
        windowParams.dimAmount = 0.0f;
        window.setAttributes(windowParams);
    }


    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        if (!mIsSelfDialog) {
            Toast.makeText(getContext(), mMessage, Toast.LENGTH_SHORT).show();
            ToastDialogFragment.this.dismiss();
            return super.onCreateDialog(savedInstanceState);
        } else {
            return super.onCreateDialog(savedInstanceState);
        }

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mIsSelfDialog) {
            getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
            getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            getDialog().getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            mView = inflater.inflate(R.layout.dialog_toast, container, false);
            initDialog();
            return mView;
        } else {
            return super.onCreateView(inflater, container, savedInstanceState);
        }
    }


    @Override
    protected void initView() {
        toast_ll = (LinearLayout) mView.findViewById(R.id.toast_ll);
        toast_iv = (ImageView) mView.findViewById(R.id.toast_iv);
        toast_tv = (TextView) mView.findViewById(R.id.toast_tv);

        mOtherWidth = (int) getContext().getResources().getDimension(R.dimen.dp_10) * 2;
        mMaxWidth = (int) getContext().getResources().getDimension(R.dimen.dp_200);
        mMinWidth = (int) getContext().getResources().getDimension(R.dimen.dp_120);
    }

    @Override
    protected void setListener() {
        mView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                mHandle.removeCallbacks(mRunnable);
                ToastDialogFragment.this.dismiss();
                return false;
            }
        });
    }

    @Override
    protected void initData() {
        if (mToastDialogType == SHOW_SUCCESS) {
            toast_iv.setImageResource(R.drawable.tips_icon_done);
        } else if (mToastDialogType == SHOW_WARNING) {
            toast_iv.setImageResource(R.drawable.taost_ico_warning);
        } else if (mToastDialogType == SHOW_FAIL) {
            toast_iv.setImageResource(R.drawable.tips_icon_failed);
        }
        toast_tv.setText(mMessage);
        TextPaint paint = toast_tv.getPaint();
        int width = (int) Layout.getDesiredWidth(toast_tv.getText().toString(), 0, toast_tv.getText().length(), paint);
        int totalWidth = width + mOtherWidth;

        if (totalWidth < mMinWidth) {
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(mMinWidth, RelativeLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
            toast_ll.setLayoutParams(layoutParams);
        } else if (totalWidth > mMinWidth && totalWidth < mMaxWidth) {
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
            toast_ll.setLayoutParams(layoutParams);
        } else if (totalWidth > mMaxWidth) {
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(mMaxWidth, RelativeLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
            toast_ll.setLayoutParams(layoutParams);
        }
        mHandle.postDelayed(mRunnable, 1500);
    }

    Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
           ToastDialogFragment.this.dismiss();
        }
    };

    public static ToastDialogFragment newInstance(String message, FragmentManager fragmentManager, String dialogId) {
        mFragmentManager = fragmentManager;
        mDialogId = dialogId;
        mInstance = new ToastDialogFragment();
        mBundle = new Bundle();
        mBundle.putString(EXTRA_MESSAGE_KEY, message);
        return (ToastDialogFragment) mInstance;
    }


    @Override
    public void setDialogListener(BaseDialogFragmentListener listener) {
        if (listener instanceof ToastDialogListener) {
            mListener = (ToastDialogListener) listener;
        }
    }


    public interface ToastDialogListener extends BaseDialogFragmentListener, DialogInterface.OnClickListener {
    }
}
