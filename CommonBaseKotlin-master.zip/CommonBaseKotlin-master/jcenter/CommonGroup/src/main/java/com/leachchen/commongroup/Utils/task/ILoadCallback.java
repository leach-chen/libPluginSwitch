package com.leachchen.commongroup.Utils.task;


public interface ILoadCallback {
	/**
	 * 在异步任务的doInBackground执行该方法
	 * @return data
	 */
	 Object run();
	
	/**
	 * 在异步任务的PostExecute执行该方法
	 * @param data
	 */
	 void loadedCallback(Object data);
}
