package com.leachchen.commongroup.MvpBase.PresenterBase

import rx.Subscription


/**
 * ClassName:   IBasePresenter.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/29 17:13
 **/
interface IBasePresenter {
     fun addSubscription(s: Subscription)
     fun unsubcrible()
     fun onPause()
     fun onResume()
     fun onDestroy()
}