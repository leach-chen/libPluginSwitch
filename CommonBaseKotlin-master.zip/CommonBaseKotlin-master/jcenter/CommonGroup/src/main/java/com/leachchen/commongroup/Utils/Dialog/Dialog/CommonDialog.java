package com.leachchen.commongroup.Utils.Dialog.Dialog;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.leachchen.commongroup.R;


/**
 * ClassName:   CommonDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/11/17 12:16
 **/

public class CommonDialog extends BaseCommonDialog {

    private TextView tv_dialog_title, tv_dialog_message;
    private Button btn_dialog_finish, btn_dialog_left, btn_dialog_right;
    private LinearLayout ll_dialog_bomcontent, ll_dialog_tm, ll_dialog_one, ll_dialog_two, ll_dialog_content;
    private RelativeLayout rl_dialog_content;

    public CommonDialog(Context context) {
        super(context,R.style.MyFullDialog);
        setContentView(R.layout.dialog_common);
        createInit();
    }

    @Override
    protected void initView() {
        tv_dialog_title = (TextView) this.findViewById(R.id.tv_dialog_title);
        tv_dialog_message = (TextView) this.findViewById(R.id.tv_dialog_message);
        btn_dialog_finish = (Button) this.findViewById(R.id.btn_dialog_finish);
        ll_dialog_bomcontent = (LinearLayout)this.findViewById(R.id.ll_dialog_bomcontent);
        ll_dialog_tm = (LinearLayout)this.findViewById(R.id.ll_dialog_tm);
        rl_dialog_content = (RelativeLayout) this.findViewById(R.id.rl_dialog_content);
        ll_dialog_one = (LinearLayout)this.findViewById(R.id.ll_dialog_one);
        ll_dialog_two = (LinearLayout)this.findViewById(R.id.ll_dialog_two);
        btn_dialog_left = (Button) this.findViewById(R.id.btn_dialog_left);
        btn_dialog_right = (Button) this.findViewById(R.id.btn_dialog_right);
        ll_dialog_content = (LinearLayout)this.findViewById(R.id.ll_dialog_content);
    }

    @Override
    protected void setListener() {
        btn_dialog_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBtnOneListener != null)
                    ((DialogOnClickListener)mBtnOneListener).onClickListener(DIALOG_ONE_POSITION, mInstance);
                dimissDialog();
            }
        });

        btn_dialog_left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBtnOneListener != null)
                    ((DialogOnClickListener)mBtnOneListener).onClickListener(DIALOG_ONE_POSITION, mInstance);
                dimissDialog();
            }
        });

        btn_dialog_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mBtnTwoListener != null)
                    ((DialogOnClickListener)mBtnTwoListener).onClickListener(DIALOG_TWO_POSITION, mInstance);
                dimissDialog();
            }
        });
    }

    @Override
    protected void initData() {
        tv_dialog_title.setText(mTitle);
        tv_dialog_message.setText(mMessage);
        btn_dialog_finish.setText(mOneBtnText);
        btn_dialog_left.setText(mTwoBtnLeftText);
        btn_dialog_right.setText(mTwoBtnRightText);


        tv_dialog_title.setTextColor(mTitleColor);
        tv_dialog_message.setTextColor(mMessageColor);
        btn_dialog_finish.setTextColor(mOneBtnColor);
        btn_dialog_left.setTextColor(mTwoBtnLeftColor);
        btn_dialog_right.setTextColor(mTwoBtnRightColor);


        tv_dialog_title.setTextSize(TypedValue.COMPLEX_UNIT_PX, mTitleSize);
        tv_dialog_message.setTextSize(TypedValue.COMPLEX_UNIT_PX,mMessageSize);
        btn_dialog_finish.setTextSize(TypedValue.COMPLEX_UNIT_PX,mOneBtnSize);
        btn_dialog_left.setTextSize(TypedValue.COMPLEX_UNIT_PX,mTwoBtnLeftSize);
        btn_dialog_right.setTextSize(TypedValue.COMPLEX_UNIT_PX,mTwoBtnRightSize);

        if (TextUtils.isEmpty(mTitle)) {
            tv_dialog_title.setVisibility(View.GONE);
        }
        wrapMessage();
        if (mShowTwoBtn) {
            ll_dialog_one.setVisibility(View.GONE);
            ll_dialog_two.setVisibility(View.VISIBLE);
        } else {
            ll_dialog_one.setVisibility(View.VISIBLE);
            ll_dialog_two.setVisibility(View.GONE);
        }
    }

    private void wrapMessage() {
        if (mIsWrapMessage) {
            int width = (int) mContext.getResources().getDimension(R.dimen.dp_270);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT);
            rl_dialog_content.setLayoutParams(params);

            RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            params1.leftMargin = (int) mContext.getResources().getDimension(R.dimen.dp_10);
            params1.rightMargin = (int) mContext.getResources().getDimension(R.dimen.dp_10);
            params1.topMargin = (int) mContext.getResources().getDimension(R.dimen.dp_18);
            ll_dialog_tm.setId(R.id.wrap_dialog);
            ll_dialog_tm.setLayoutParams(params1);

            int btnHeight = (int) mContext.getResources().getDimension(R.dimen.dp_44);
            RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, btnHeight);
            params2.addRule(RelativeLayout.BELOW, R.id.wrap_dialog);
            ll_dialog_bomcontent.setLayoutParams(params2);
        } else {
            int width = (int) mContext.getResources().getDimension(R.dimen.dp_270);
            int height = (int) mContext.getResources().getDimension(R.dimen.dp_148);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
            rl_dialog_content.setLayoutParams(params);

            int btnHeight = (int) mContext.getResources().getDimension(R.dimen.dp_44);
            RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, btnHeight);
            params2.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            ll_dialog_bomcontent.setLayoutParams(params2);
            ll_dialog_bomcontent.setId(R.id.size_dialog);

            RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
            params1.leftMargin = (int) mContext.getResources().getDimension(R.dimen.dp_10);
            params1.rightMargin = (int) mContext.getResources().getDimension(R.dimen.dp_10);
            params1.topMargin = (int) mContext.getResources().getDimension(R.dimen.dp_18);
            params1.addRule(RelativeLayout.ABOVE, R.id.size_dialog);
            ll_dialog_tm.setLayoutParams(params1);
        }
    }

    @Override
    public void onCreateDialog() {
        if (!mIsSelfDialog) {
            ll_dialog_content.setVisibility(View.GONE);
            mBuilder = new AlertDialog.Builder(mContext);
            if (!TextUtils.isEmpty(mTitle)) {
                mBuilder.setTitle(mTitle);
            }
            if (!TextUtils.isEmpty(mMessage)) {
                mBuilder.setMessage(mMessage);
            }

            if (mShowTwoBtn) {
                mBuilder.setPositiveButton(mTwoBtnLeftText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mBtnOneListener != null)
                            ((DialogOnClickListener) mBtnOneListener).onClickListener(DIALOG_ONE_POSITION, mInstance);
                    }
                });

                mBuilder.setNegativeButton(mTwoBtnRightText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mBtnTwoListener != null)
                            ((DialogOnClickListener)mBtnTwoListener).onClickListener(DIALOG_TWO_POSITION, mInstance);
                    }
                });
            } else {
                mBuilder.setPositiveButton(mOneBtnText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mBtnOneListener != null)
                            ((DialogOnClickListener)mBtnOneListener).onClickListener(DIALOG_ONE_POSITION, mInstance);
                        dimissDialog();
                    }
                });
            }
        }
    }

    @Override
    public void onCreateView() {
        if (mIsSelfDialog) {
            ll_dialog_content.setVisibility(View.VISIBLE);
        }
    }

    public interface DialogOnClickListener  extends BaseCommonDialogListener {
        void onClickListener(int position, BaseCommonDialog dialog);
    }

}
