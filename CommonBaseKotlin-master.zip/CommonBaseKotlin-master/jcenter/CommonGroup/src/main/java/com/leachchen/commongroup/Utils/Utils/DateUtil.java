package com.leachchen.commongroup.Utils.Utils;

import android.content.Context;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Formatter;
import java.util.Locale;
import java.util.TimeZone;

/**
 * ClassName:   DateHelp.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/6/19 10:11
 **/

public class DateUtil {

    public final static String FORMAT_ONE = "yyyy-MM-dd HH:mm:ss";

    /**
     * Date（long） 转换 String
     * @return
     */
    public static String dateNow() {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_ONE);
        String s = sdf.format(date);
        return s;
    }


    /**
     * Date（long） 转换 String
     *
     * @param time
     * @param format
     * @return
     */
    public static String date2String(long time, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        String s = sdf.format(time);
        return s;
    }

    /**
     * 倒计时时间
     * @param time
     * @return
     */
    public static String timeMMSS(int time)
    {
        int hour = time/3600;
        int min = time % 3600 / 60;
        int second = time % 60;
        //return String.format(Locale.CHINA,"%02d:%02d:%02d",hour,min,second);
        return String.format(Locale.CHINA,"%02d:%02d",min,second);
    }

    public static String stringForTime(int timeMs) {

        StringBuilder mFormatBuilder = new StringBuilder();
        Formatter mFormatter = new Formatter(mFormatBuilder, Locale.getDefault());

        int totalSeconds = timeMs / 1000;

        int seconds = totalSeconds % 60;
        int minutes = (totalSeconds / 60) % 60;
        int hours = totalSeconds / 3600;

        mFormatBuilder.setLength(0);
        if (hours > 0) {
            return mFormatter.format("%d:%02d:%02d", hours, minutes, seconds).toString();
        } else {
            return mFormatter.format("%02d:%02d", minutes, seconds).toString();
        }
    }

    /**
     * 获取时区
     * @return
     */
    public static String getTimeZone()
    {
        TimeZone tz = TimeZone.getDefault();
        String str =  tz.getDisplayName(false, TimeZone.SHORT);
        //String s = "TimeZone   " + tz.getDisplayName(false, TimeZone.SHORT) + " Timezon id :: " + tz.getID();
        if(str != null)
        {
            return str;
        }else
        {
            return "";
        }
    }

    /***
     * 获取当天时间
     * @return
     */
    public static String getToday() {
        String day1 = "";
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        day1 = year + "";
        int month = c.get(Calendar.MONTH) + 1;
        if (month >= 10) {
            day1 += month;
        } else {
            day1 += "0" + month;
        }
        int day = c.get(Calendar.DAY_OF_MONTH);
        if (day >= 10) {
            day1 += day;
        } else {
            day1 += "0" + day;
        }
        return day1;
    }

    /**
     * 根据年 月 获取对应的月份 天数
     */
    public static int getDaysByYearMonth(int year, int month) {

        Calendar a = Calendar.getInstance();
        a.set(Calendar.YEAR, year);
        a.set(Calendar.MONTH, month - 1);
        a.set(Calendar.DATE, 1);
        a.roll(Calendar.DATE, -1);
        int maxDate = a.get(Calendar.DATE);
        return maxDate;
    }


    public static String getAMPMTime(Context context, String time)
    {
        String str = "";
        try {
            boolean is24 = android.text.format.DateFormat.is24HourFormat(context);
            if (time.length() < 4) return str;
            int hour = Integer.parseInt(time.substring(0, 2));
            int minute = Integer.parseInt(time.substring(2, 4));


            if (is24) {
                str = String.format("%02d:%02d", hour, minute);
            } else {
                str = time24To12(hour,minute, -1);
            }
        }catch (Exception e)
        {
        }
        return str;
    }


    /**
     * 24小时制 转换 12小时制
     * @return
     */
    public static String time24To12(int hour, int minute, int second) {
        try {
            int h = hour;
            int m = minute;
            int nowH = h;
            String sx;
            if (h < 1) {
                h = 12;
                sx = "AM";
            } else if (h < 12) {
                sx = "PM";
            } else if (h < 13) {
                sx = "AM";
            } else {
                sx = "PM";
                h -= 12;
            }

            if (nowH >= 12) {
                sx = "PM";
            } else {
                sx = "AM";
            }
            if (second == -1) {
                return String.format("%d:%02d%s", h, m, sx);
            } else {
                return String.format("%d:%02d:%02d%s", h, m, second, sx);
            }
        }catch (Exception e)
        {

        }
        return "";
    }


    public static String getTimeStamp(long time) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String s = sdf.format(time);
        return s;
    }

    public static String timeSubtract(String startTime, String endTime, String format) {
        DateFormat df = new SimpleDateFormat(format);
        try {
            Date d1 = df.parse(endTime);
            Date d2 = df.parse(startTime);
            long diff = d1.getTime() - d2.getTime();//这样得到的差值是微秒级别
            long days = diff / (1000 * 60 * 60 * 24);

            long hours = (diff - days * (1000 * 60 * 60 * 24)) / (1000 * 60 * 60);
            long minutes = (diff - days * (1000 * 60 * 60 * 24) - hours * (1000 * 60 * 60)) / (1000 * 60);
            //System.out.println(""+days+"天"+hours+"小时"+minutes+"分");

            //if (minutes == 0) minutes = 1;

            return (days * 24 * 60 + hours * 60 + minutes) + "min";
        } catch (Exception e) {
        }
        return "";
    }



}
