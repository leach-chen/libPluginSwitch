package com.leachchen.commongroup.Utils.Dialog.Dialog;

import android.content.Context;

/**
 * ClassName:   DialogHelp.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/26 20:10
 **/

public class DialogFactory {

    private ToastDialog mToastDialog;
    public  CommonDialog mCommonDialog;
    private LoadingDialog mLoadingDialog;
    private Context mContext;


    public DialogFactory(Context context)
    {
        this.mContext = context;
    }


    public LoadingDialog showLoading()
    {
        if(mLoadingDialog == null)mLoadingDialog = new LoadingDialog(mContext);
        mLoadingDialog.setCancelAble(true);
        return mLoadingDialog;
    }

    public LoadingDialog showLoading(String message)
    {
        if(mLoadingDialog == null)mLoadingDialog = new LoadingDialog(mContext);
        mLoadingDialog.setCancelAble(true).setMessage(message);
        return mLoadingDialog;
    }

    public LoadingDialog showLoadingDisable()
    {
        if(mLoadingDialog == null)mLoadingDialog = new LoadingDialog(mContext);
        mLoadingDialog.setCancelAble(false);
        return mLoadingDialog;
    }

    public LoadingDialog showLoadingDisable(String message)
    {
        if(mLoadingDialog == null)mLoadingDialog = new LoadingDialog(mContext);
        mLoadingDialog.setCancelAble(false).setMessage(message);
        return mLoadingDialog;
    }

    public void hideLoadingDialog()
    {
        if(mLoadingDialog != null)mLoadingDialog.dimissDialog();
    }

    public ToastDialog showToastSuccess(String message)
    {
        if(mToastDialog == null)mToastDialog = new ToastDialog(mContext);
        mToastDialog.setToastType(ToastDialog.SHOW_SUCCESS).setMessage(message);
        return mToastDialog;
    }


    public ToastDialog showToastWarn(String message)
    {
        if(mToastDialog == null)mToastDialog = new ToastDialog(mContext);
        mToastDialog.setToastType(ToastDialog.SHOW_WARNING).setMessage(message);
        return mToastDialog;
    }

    public ToastDialog showToastFail(String message)
    {
        if(mToastDialog == null)mToastDialog = new ToastDialog(mContext);
        mToastDialog.setToastType(ToastDialog.SHOW_FAIL).setMessage(message);
        return mToastDialog;
    }

    public ToastDialog showToastTips(String message)
    {
        if(mToastDialog == null)mToastDialog = new ToastDialog(mContext);
        mToastDialog.setToastType(ToastDialog.SHOW_TIPS).setMessage(message);
        return mToastDialog;
    }

    public CommonDialog showOneBtnDialog(String title, String message, String oneBtnText)
    {
        if(mCommonDialog == null)mCommonDialog = new CommonDialog(mContext);
        mCommonDialog.setTitle(title).setMessage(message).setOneBtnText(oneBtnText).setCancelAble(true);
        return mCommonDialog;
    }

    public CommonDialog showOneBtnDialogDisable(String title, String message, String oneBtnText)
    {
        if(mCommonDialog == null)mCommonDialog = new CommonDialog(mContext);
        mCommonDialog.setTitle(title).setMessage(message).setOneBtnText(oneBtnText).setCancelAble(false);
        return mCommonDialog;
    }

    public CommonDialog showTwoBtnDialog(String title, String message, String twoBtnLeftText, String twoBtnRightText)
    {
        if(mCommonDialog == null)mCommonDialog = new CommonDialog(mContext);
        mCommonDialog.setTitle(title).setMessage(message).setTwoBtnLeftText(twoBtnLeftText).setTwoBtnRightText(twoBtnRightText).setCancelAble(true);
        return mCommonDialog;
    }

    public CommonDialog showTwoBtnDialogDisable(String title, String message, String twoBtnLeftText, String twoBtnRightText)
    {
        if(mCommonDialog == null)mCommonDialog = new CommonDialog(mContext);
        mCommonDialog.setTitle(title).setMessage(message).setTwoBtnLeftText(twoBtnLeftText).setTwoBtnRightText(twoBtnRightText).setCancelAble(false);
        return mCommonDialog;
    }

    public void hideCommonDialog()
    {
        if(mCommonDialog != null)mCommonDialog.dimissDialog();
    }
}
