package com.leachchen.commongroup.Utils.Dialog.DialogFragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

/**
 * ClassName:   DialogFactory.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/16 14:11
 **/

public class DialogFragmentFactory {

    public static final String COMMON_DIALOG_FRAGMENT = "common_dialog_fragment";
    public static final String LOADING_DIALOG_FRAGMENT = "loading_dialog_fragment";
    public static final String TOAST_DIALOG_FRAGMENT = "toast_dialog_fragment";
    private FragmentManager mFragmentManager;
    public DialogFragmentListenerHolder mListenerHolder = new DialogFragmentListenerHolder();


    public DialogFragmentFactory(FragmentManager fragmentManager, Bundle savedInstanceState) {
        this.mFragmentManager = fragmentManager;
        mListenerHolder.getDialogListenerKey(savedInstanceState);
    }

    public void restoreDialogListener(Object o){
        mListenerHolder.restoreDialogListener(o);
    }

    public CommonDialogFragment showOneBtnDialog(String message, String oneBtnText, CommonDialogFragment.CommonDialogListener listener) {
        FragmentTransaction ft = mFragmentManager.beginTransaction();
        Fragment fragment = mFragmentManager.findFragmentByTag(COMMON_DIALOG_FRAGMENT);
        if (null != fragment) {
            ft.remove(fragment);
        }
        mListenerHolder.setDialogListener(listener);
        CommonDialogFragment df = CommonDialogFragment.newOneBtnInstance(message,oneBtnText,mFragmentManager,COMMON_DIALOG_FRAGMENT);
        return df;
    }

    public CommonDialogFragment showTwoBtnDialog(String message, String twoBtnLeftText, String twoBtnRightText, CommonDialogFragment.CommonDialogListener listener) {
        FragmentTransaction ft = mFragmentManager.beginTransaction();
        Fragment fragment = mFragmentManager.findFragmentByTag(COMMON_DIALOG_FRAGMENT);
        if (null != fragment) {
            ft.remove(fragment);
        }
        mListenerHolder.setDialogListener(listener);
        CommonDialogFragment df = CommonDialogFragment.newTwoBtnInstance(message,twoBtnLeftText,twoBtnRightText,mFragmentManager,COMMON_DIALOG_FRAGMENT);
        return df;
    }

    public LoadingDialogFragment showLoadingDialog(LoadingDialogFragment.LoadingDialogListener listener)
    {
        FragmentTransaction ft = mFragmentManager.beginTransaction();
        Fragment fragment = mFragmentManager.findFragmentByTag(LOADING_DIALOG_FRAGMENT);
        if (null != fragment) {
            ft.remove(fragment);
        }
        mListenerHolder.setDialogListener(listener);
        LoadingDialogFragment df = LoadingDialogFragment.newInstance(mFragmentManager,LOADING_DIALOG_FRAGMENT);
        return df;
    }

    public ToastDialogFragment showToastDialog(String message, LoadingDialogFragment.LoadingDialogListener listener)
    {
        FragmentTransaction ft = mFragmentManager.beginTransaction();
        Fragment fragment = mFragmentManager.findFragmentByTag(TOAST_DIALOG_FRAGMENT);
        if (null != fragment) {
            ft.remove(fragment);
        }
        mListenerHolder.setDialogListener(listener);
        ToastDialogFragment df = ToastDialogFragment.newInstance(message,mFragmentManager,TOAST_DIALOG_FRAGMENT);
        return df;
    }


}
