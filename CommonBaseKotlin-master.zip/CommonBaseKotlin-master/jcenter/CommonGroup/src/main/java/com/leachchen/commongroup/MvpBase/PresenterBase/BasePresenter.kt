package com.leachchen.commongroup.MvpBase.PresenterBase

import android.os.Parcel
import android.os.Parcelable
import com.leachchen.commongroup.MvpBase.UIBase.BaseImpl
import com.leachchen.commongroup.Utils.Other.BInterface
import com.tencent.bugly.proguard.s
import rx.Subscription
import rx.subscriptions.CompositeSubscription

/**
 * ClassName:   BasePresenter.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/29 17:13
 **/
abstract class BasePresenter(impl: BaseImpl) : IBasePresenter, BInterface.PresenterCallBack {

    private var mCompositeSubscription: CompositeSubscription? = null
    protected var mImpl: BaseImpl? = null

    init {
        this.mImpl = impl
        mCompositeSubscription = CompositeSubscription()
        impl.setPresenter(this)
    }

    @Override
    override fun addSubscription(s: Subscription) {
        if (this.mCompositeSubscription == null) {
            this.mCompositeSubscription = CompositeSubscription()
        }
        this.mCompositeSubscription!!.add(s)
    }

    @Override
    override fun unsubcrible() {
        if (this.mCompositeSubscription != null) {
            this.mCompositeSubscription!!.unsubscribe()
        }
    }

    @Override
    override fun onPause() {}

    @Override
    override fun onResume() {}

    @Override
    override fun onDestroy() {
        unsubcrible()
    }

    @Override
    override fun getBizData(dataList: List<*>) {

    }

}
