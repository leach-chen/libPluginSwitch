package com.leachchen.commongroup.Utils.Dialog.Dialog;

import android.content.Context;
import android.support.annotation.NonNull;

/**
 * ClassName:   BaseLoadingDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/27 10:01
 **/

public abstract class BaseLoadingDialog extends BaseDialog{

    protected static BaseLoadingDialog mInstance;

    public BaseLoadingDialog(@NonNull Context context, int theme) {
        super(context,theme);
        mInstance = this;
    }

    /**********************************************************************************************/
    public BaseLoadingDialog setTitleColor(int titleColor) {
        mTitleColor = titleColor;
        return mInstance;
    }

    public BaseLoadingDialog setMessageColor(int messageColor) {
        mMessageColor = messageColor;
        return mInstance;
    }


    public BaseLoadingDialog setTitleSize(float titleSize) {
        mTitleSize = titleSize;
        return mInstance;
    }

    public BaseLoadingDialog setMessageSize(float messageSize) {
        mMessageSize = messageSize;
        return mInstance;
    }


    public BaseLoadingDialog setTitle(String title) {
        if (title == null) title = "";
        mTitle = title;
        return mInstance;
    }

    public BaseLoadingDialog setMessage(String message) {
        if (message == null) message = "";
        mMessage = message;
        return mInstance;
    }


    public BaseLoadingDialog setCancelAble(boolean isCancelAble) {
        mIsCancelAble = isCancelAble;
        return mInstance;
    }

    public BaseLoadingDialog setSelfDialog(boolean isSelfDialog) {
        mIsSelfDialog = isSelfDialog;
        return mInstance;
    }
    /**********************************************************************************************/

}
