package com.leachchen.commongroup.Utils.Utils;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * ClassName:   FileHelp.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/8/10 13:50
 **/
public class FileHelp {

    /**
     * 拷贝文件
     *
     * @param sourcePath 原始文件路径
     * @param targetPath 目标存放文件路径
     */
    public static void copyFile(String sourcePath, String targetPath) {

        //文件非空判断
        if (TextUtils.isEmpty(sourcePath) || TextUtils.isEmpty(targetPath)) {
            return;
        }

        File source = new File(sourcePath);
        File target = new File(targetPath);

        //源文件，和目标文件是同一个文件，并且目标文件存在，直接返回
        if (sourcePath.equals(targetPath) && target.exists()) {
            return;
        }

        if (!target.exists()) {
            String path = targetPath.substring(0, targetPath.lastIndexOf("/"));
            File s = new File(path);
            s.mkdirs();
        }


        InputStream in = null;
        OutputStream out = null;
        try {
            in = new BufferedInputStream(new FileInputStream(source));
            out = new BufferedOutputStream(new FileOutputStream(target));
            byte[] buf = new byte[8192];
            int i;
            while ((i = in.read(buf)) != -1) {
                out.write(buf, 0, i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null)
                    out.close();
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * Java文件操作 获取文件扩展名
     */
    public static String getExtensionName(String filename) {
        if ((filename != null) && (filename.length() > 0)) {
            int dot = filename.lastIndexOf('.');
            if ((dot > -1) && (dot < (filename.length() - 1))) {
                return filename.substring(dot + 1);
            }
        }
        return filename;
    }

    /**
     * Java文件操作 获取不带扩展名的文件名
     */
    public static String getFileNameNoEx(String filename) {
        if ((filename != null) && (filename.length() > 0)) {
            int dot = filename.lastIndexOf('.');
            if ((dot > -1) && (dot < (filename.length()))) {
                return filename.substring(0, dot);
            }
        }
        return filename;
    }

    /**
     * 获取路径文件名
     *
     * @param filePath
     * @return
     */
    public static String getFileName(String filePath) {
        if ((filePath != null) && (filePath.length() > 0)) {
            filePath = filePath.replace("\\", "/");
            int dot = filePath.lastIndexOf('/');
            if ((dot > -1) && (dot < (filePath.length()))) {
                return filePath.substring(dot + 1, filePath.length());
            }
        }
        return "";
    }


    /**
     * 判断文件是否存在
     *
     * @param filePath 文件路径
     * @return
     */
    public static boolean isExist(String filePath) {
        try {
            File f = new File(filePath);
            if (!f.exists()) {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static long getFileLength(String filePath) {
        File file = new File(filePath);
        if (file != null) {
            return file.length();
        }
        return 0;
    }

    /**
     * 删除文件下所有文件
     */
    public static void delFileList(File file) {
        if (file != null) {
            for (File f : file.listFiles()) {
                f.delete();
            }
        }
    }

    public static void deleteFile(File file) {
        if (file != null) {
            file.delete();
        }
    }

    /**
     * 保存方法 byte[]
     */
    public static void saveBitmapBybytes(String imgName, byte[] bytes) {
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            FileOutputStream fos = null;
            try {
                File imgDir = new File(imgName);
                if (imgDir.exists()) {
                    imgDir.mkdirs();
                }
                fos = new FileOutputStream(imgName);
                fos.write(bytes);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (fos != null) {
                        fos.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
        }
    }

    /**
     * 保存方法
     */
    public static void saveBitmap(Bitmap bitmap, String path) {
        File f = new File(path);
        if (f.exists()) {
            f.delete();
        }
        try {
            FileOutputStream out = new FileOutputStream(f);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            out.close();

            if (bitmap != null && !bitmap.isRecycled()) {
                bitmap.recycle();
                bitmap = null;
            }
            System.gc();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static boolean saveDrawable(Drawable drawable, String path) {
        Bitmap bitmap = Bitmap.createBitmap(
                drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(),
                drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565);
        Canvas canvas = new Canvas(bitmap);
        //canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);

        if (bitmap != null) {
            FileHelp.saveBitmap(bitmap, path);
            return true;
        } else {
            return false;
        }
    }

    public static void createNomediaFile(String path) {
        path = path + "/.nomedia";
        File file = new File(path);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 删除目录下的文件
     *
     * @param root
     */
    public static void deleteAllFiles(File root) {
        File files[] = root.listFiles();
        if (files != null)
            for (File f : files) {
                if (f.isDirectory()) { // 判断是否为文件夹
                    deleteAllFiles(f);
                    try {
                        f.delete();
                    } catch (Exception e) {
                    }
                } else {
                    if (f.exists()) { // 判断是否存在
                        deleteAllFiles(f);
                        try {
                            f.delete();
                        } catch (Exception e) {
                        }
                    }
                }
            }
    }

    /**
     * 将字节数据保存为文件
     *
     * @param bs
     */
    public static void saveByteToFile(byte[] bs, String path) {
        File file = new File(path);
        try {
            FileOutputStream fos = new FileOutputStream(file, true);
            fos.write(bs);
            fos.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 生成dp，sp资源
     *
     * @param path
     */
    public static void getResourceData(String path) {
        try {
            File file = new File(path);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            for (int i = 1; i <= 1000; i++) {
                String str = "<dimen name=\"dp_" + i + "\">" + i + "dp</dimen>\r\n";
                //String str = "<dimen name=\"sp_" + i + "\">" + i + "sp</dimen>\r\n";
                fileOutputStream.write(str.getBytes());
            }
            fileOutputStream.close();
        } catch (Exception e) {
            //Log.e("mytest",e.toString());
        }
    }

    /**
     * 获取目录下所有文件
     *
     * @param realpath
     * @param files
     * @return
     */
    public static List<File> getFiles(String realpath, List<File> files) {

        File realFile = new File(realpath);
        if (realFile.isDirectory()) {
            File[] subfiles = realFile.listFiles();
            for (File file : subfiles) {
                if (file.isDirectory()) {
                    getFiles(file.getAbsolutePath(), files);
                } else {
                    files.add(file);
                }
            }
        }
        return files;
    }

    /**
     * 获取目录下所有文件(按时间排序)
     *
     * @param path
     * @return
     */
    public static List<File> getFileSort(String path) {

        List<File> list = getFiles(path, new ArrayList<File>());

        if (list != null && list.size() > 0) {

            Collections.sort(list, new Comparator<File>() {
                public int compare(File file, File newFile) {
                    if (file.lastModified() < newFile.lastModified()) {
                        return 1;
                    } else if (file.lastModified() == newFile.lastModified()) {
                        return 0;
                    } else {
                        return -1;
                    }
                }
            });

        }

        return list;
    }

    /**
     * 将图片保存到系统图库
     *
     * @param imageFile
     * @param context
     */
    public static boolean saveToSystemAlbum(String imageFile, Context context) {

        try {

            //把文件插入到系统图库
            File file = new File(imageFile);
            MediaStore.Images.Media.insertImage(context.getContentResolver(), imageFile, file.getName(), "describer");

            //保存图片后发送广播通知更新数据库
            Uri uri = Uri.fromFile(file);
            context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 删除文件、文件夹
     */
    public static void delFileAndFolder(File file) {
        if (file.exists()) {//判断文件是否存在
            if (file.isFile()) {//判断是否是文件
                file.delete();//删除文件
            } else if (file.isDirectory()) {//否则如果它是一个目录
                File[] files = file.listFiles();//声明目录下所有的文件 files[];
                for (int i = 0; i < files.length; i++) {//遍历目录下所有的文件
                    delFileAndFolder(files[i]);//把每个文件用这个方法进行迭代
                }
                file.delete();//删除文件夹
            }
        } else {
            System.out.println("所删除的文件不存在");
        }
    }
}
