package com.leachchen.commongroup.MvpBase.BaseView

import android.content.Context
import android.view.View

/**
 * ClassName:   BaseView.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/29 16:59
 **/
class BaseView(context: Context)
{
    protected  var mContext : Context
    protected lateinit var mView : View

    init {
        this.mContext = context
    }

    fun getView() = mView


}