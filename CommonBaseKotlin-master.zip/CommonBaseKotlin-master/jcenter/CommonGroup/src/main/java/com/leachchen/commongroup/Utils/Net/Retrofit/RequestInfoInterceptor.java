package com.leachchen.commongroup.Utils.Net.Retrofit;

import com.leachchen.commongroup.Utils.LogWrite.LogModel;
import com.leachchen.commongroup.Utils.LogWrite.LogWrite;

import java.io.IOException;
import java.nio.charset.Charset;

import okhttp3.FormBody;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;

/**
 * ClassName:   RequestInfoInterceptor.java
 * Description:
 * Author :     jame.liu
 * Date:        2017/7/27 15:11
 **/

public class RequestInfoInterceptor implements Interceptor {
    /**
     * 获取body内容
     *
     * @param request
     * @return
     */
    private String getBody(Request request) {

        RequestBody requestBody = request.body();

        Buffer buffer = new Buffer();
        try {
            requestBody.writeTo(buffer);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Charset charset = Charset.forName("UTF-8");
        MediaType contentType = requestBody.contentType();
        if (contentType != null) {
            charset = contentType.charset(Charset.forName("UTF-8"));
        }
        String body = buffer.readString(charset);
        return body;
    }


    @Override
    public Response intercept(Chain chain) throws IOException {
        //这个chain里面包含了request和response，所以你要什么都可以从这里拿
        Request request = chain.request();
        long t1 = System.nanoTime();//请求发起的时间

        String method = request.method();

        //完整的请求
        String fullUrl = "";
        String bodyString = "\nbody:" + getBody(request);

        if ("POST".equals(method)) {
            StringBuilder sb = new StringBuilder();
            String requestName = request.body().getClass().getSimpleName();
            //Log.d("ManagerRequest", "Request:" + requestName);

            if (request.body() instanceof FormBody) {
                FormBody body = (FormBody) request.body();
                for (int i = 0; i < body.size(); i++) {
                    sb.append(body.encodedName(i) + "=" + body.encodedValue(i) + "&");
                }
                sb.delete(sb.length() - 1, sb.length());
                //Log.d("CSDN_LQR", String.format("发送请求 %s on %s %n%s %nRequestParams:{%s}",request.url(), chain.connection(), request.headers(), sb.toString()));
                fullUrl = String.format("%s&%s", request.url(), sb.toString());
                LogWrite.d("POST:" + fullUrl + bodyString, LogModel.MODEL_LOGGINGINTERCEPTOR);

            } else if (request.body() instanceof RequestBody) {

                fullUrl = String.format("%s", request.url());
                LogWrite.d("POST:" + fullUrl + bodyString, LogModel.MODEL_LOGGINGINTERCEPTOR);
            }

        } else {
            fullUrl = String.format("%s", request.url());
            LogWrite.d("GET:" + fullUrl + bodyString, LogModel.MODEL_LOGGINGINTERCEPTOR);
        }
        Response response = chain.proceed(request);
        long t2 = System.nanoTime();//收到响应的时间
        //这里不能直接使用response.body().string()的方式输出日志
        //因为response.body().string()之后，response中的流会被关闭，程序会报错，我们需要创建出一
        //个新的response给应用层处理
        ResponseBody responseBody = response.peekBody(1024 * 1024);
        //Log.d("ManagerRequest", String.format("接收响应: [%s] %n返回json:【%s】 %.1fms %n%s", response.request().url(), responseBody.string(), (t2 - t1) / 1e6d, response.headers()));

        String content = "响应url:" + fullUrl + "\n";
        String json = responseBody.string();
        content += ("响应内容：" + json);
        LogWrite.d(content, LogModel.MODEL_LOGGINGINTERCEPTOR);
        LogWrite.json(json, LogModel.MODEL_LOGGINGINTERCEPTOR);

        return response;
    }
}
