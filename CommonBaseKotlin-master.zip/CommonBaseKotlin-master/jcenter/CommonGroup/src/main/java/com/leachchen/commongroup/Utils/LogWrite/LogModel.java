package com.leachchen.commongroup.Utils.LogWrite;

/**
 * ClassName:   LogModel.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/6/22 10:15
 **/

public class LogModel {

    /**
     * Original 输出日志时不添加前缀
     */
    protected static final int CASE_MODEL_ORIGINAL = 0x0001;
    public static int MODEL_ORIGINAL = 0x0001;

    /**
     * Common
     */
    public static int MODEL_COMMON = 0x0002;        //设置该值，可控制该模块日志是否打开
    protected static final int CASE_MODEL_COMMON = 0x0002;
    protected static String STR_MODEL_COMMON = "【Common】-->";

    /**
     * DB
     */
    public static int MODEL_DB = 0x0003;
    protected static final int CASE_MODEL_DB = 0x0003;
    protected static String STR_MODEL_DB = "【DB】-->";


    /**
     * Start
     */
    public static int MODEL_START = 0x0004;
    protected static final int CASE_MODEL_START = 0x0004;
    protected static String STR_MODEL_START = "【Start】-->";


    /**
     * Main
     */
    public static int MODEL_MAIN = 0x0005;
    protected static final int CASE_MODEL_MAIN = 0x0005;
    protected static String STR_MODEL_MAIN = "【Main】-->";


    /**
     * Device
     */
    public static int MODEL_DEVICE = 0x0006;
    protected static final int CASE_MODEL_DEVICE = 0x0006;
    protected static String STR_MODEL_DEVICE = "【Device】-->";


    /**
     * RoadBook
     */
    public static int MODEL_ROADBOOK = 0x0007;
    protected static final int CASE_MODEL_ROADBOOK = 0x0007;
    protected static String STR_MODEL_ROADBOOK = "【RoadBook】-->";


    /**
     * Track
     */
    public static int MODEL_TRACK = 0x0008;
    protected static final int CASE_MODEL_TRACK = 0x0008;
    protected static String STR_MODEL_TRACK = "【Track】-->";



    /**
     * Album
     */
    public static int MODEL_ALBUM = 0x0009;
    protected static final int CASE_MODEL_ALBUM = 0x0009;
    protected static String STR_MODEL_ALBUM = "【Album】-->";


    /**
     * Account
     */
    public static int MODEL_ACCOUNT = 0x0010;
    protected static final int CASE_MODEL_ACCOUNT = 0x0010;
    protected static String STR_MODEL_ACCOUNT = "【Account】-->";


    /**
     * MyCenter
     */
    public static int MODEL_MYCENTER = 0x0011;
    protected static final int CASE_MODEL_MYCENTER = 0x0011;
    protected static String STR_MODEL_MYCENTER = "【MyCenter】-->";

    /**
     * Update APP
     */
    public static int MODEL_UPDATE_APP = 0x0012;
    protected static final int CASE_MODEL_UPDATE_APP = 0x0012;
    protected static String STR_MODEL_UPDATE_APP = "【Update APP】-->";


    /**
     * Update Firmware
     */
    public static int MODEL_UPDATE_FIRMWARE = 0x0013;
    protected static final int CASE_MODEL_UPDATE_FIRMWARE = 0x0013;
    protected static String STR_MODEL_UPDATE_FIRMWARE = "【Update APP】-->";

    /**
     * DeviceSet
     */
    public static int MODEL_DEVICESET= 0x0014;
    protected static final int CASE_MODEL_DEVICESET = 0x0014;
    protected static String STR_MODEL_DEVICESET = "【DeviceSet】-->";


    /**
     * AlbumFull
     */
    public static int MODEL_ALBUMFULL= 0x0015;
    protected static final int CASE_MODEL_ALBUMFULL = 0x0015;
    protected static String STR_MODEL_ALBUMFULL = "【AlbumFull】-->";

    /**
     * LoggingInterceptor
     */
    public static int MODEL_LOGGINGINTERCEPTOR= 0x0016;
    protected static final int CASE_MODEL_LOGGINGINTERCEPTOR = 0x0016;
    protected static String STR_MODEL_LOGGINGINTERCEPTOR = "【LoggingInterceptor】-->";


    /**
     * DeviceSend
     */
    public static int MODEL_DEVICE_SEND = 0x0017;
    protected static final int CASE_MODEL_DEVICESEND = 0x0017;
    protected static String STR_MODEL_DEVICESEND = "【DeviceSend】-->";

    /**
     * DeviceGet
     */
    public static int MODEL_DEVICE_GET = 0x0018;
    protected static final int CASE_MODEL_DEVICEGET = 0x0018;
    protected static String STR_MODEL_DEVICEGET = "【DeviceGet】-->";

    /**
     * DeviceRespone
     */
    public static int MODEL_DEVICE_RESPONE = 0x0019;
    protected static final int CASE_MODEL_DEVICERESPONE = 0x0019;
    protected static String STR_MODEL_DEVICERESPONE = "【DeviceRespone】-->";

    /**
     * Login
     */
    public static int MODEL_LOGIN = 0x0020;
    protected static final int CASE_MODEL_LOGIN = 0x0020;
    protected static String STR_MODEL_LOGIN = "【Login】-->";

    /**
     * Register
     */
    public static int MODEL_REGISTER = 0x0021;
    protected static final int CASE_MODEL_REGISTER = 0x0021;
    protected static String STR_MODEL_REGISTER = "【Register】-->";


    /**
     * 关闭某个模块打印日志
     */
    public static final int MODEL_CLOSE = 0x00;
    protected static boolean mIsDebug; //是否是Debug模式，是的话才打印日志


    /**
     * 每次新增LogModel 需要对应在此处添加
     *
     * @param str
     * @param model
     * @return
     */
    protected static String logShowStr(String str, int model) {
        String logStr = "";
        switch (model) {
            case LogModel.CASE_MODEL_ORIGINAL:
                logStr = str;
                break;
            case LogModel.CASE_MODEL_COMMON:
                logStr = LogModel.STR_MODEL_COMMON + str;
                break;
            case LogModel.CASE_MODEL_DB:
                logStr = LogModel.STR_MODEL_DB + str;
                break;
            case LogModel.CASE_MODEL_START:
                logStr = LogModel.STR_MODEL_START + str;
                break;
            case LogModel.CASE_MODEL_MAIN:
                logStr = LogModel.STR_MODEL_MAIN + str;
                break;
            case LogModel.CASE_MODEL_DEVICE:
                logStr = LogModel.STR_MODEL_DEVICE + str;
                break;
            case LogModel.CASE_MODEL_ROADBOOK:
                logStr = LogModel.STR_MODEL_ROADBOOK + str;
                break;
            case LogModel.CASE_MODEL_TRACK:
                logStr = LogModel.STR_MODEL_TRACK + str;
                break;
            case LogModel.CASE_MODEL_ALBUM:
                logStr = LogModel.STR_MODEL_ALBUM + str;
                break;
            case LogModel.CASE_MODEL_ACCOUNT:
                logStr = LogModel.STR_MODEL_ACCOUNT + str;
                break;
            case LogModel.CASE_MODEL_MYCENTER:
                logStr = LogModel.STR_MODEL_MYCENTER + str;
                break;
            case LogModel.CASE_MODEL_UPDATE_APP:
                logStr = LogModel.STR_MODEL_UPDATE_APP + str;
                break;
            case LogModel.CASE_MODEL_UPDATE_FIRMWARE:
                logStr = LogModel.STR_MODEL_UPDATE_FIRMWARE + str;
                break;
            case LogModel.CASE_MODEL_DEVICESET:
                logStr = LogModel.STR_MODEL_DEVICESET + str;
                break;
            case LogModel.CASE_MODEL_ALBUMFULL:
                logStr = LogModel.STR_MODEL_ALBUMFULL + str;
                break;
            case LogModel.CASE_MODEL_LOGGINGINTERCEPTOR:
                logStr = LogModel.STR_MODEL_LOGGINGINTERCEPTOR + str;
                break;
            case LogModel.CASE_MODEL_DEVICEGET:
                logStr = LogModel.STR_MODEL_DEVICEGET + str;
                break;
            case LogModel.CASE_MODEL_DEVICESEND:
                logStr = LogModel.STR_MODEL_DEVICESEND + str;
                break;
            case LogModel.CASE_MODEL_DEVICERESPONE:
                logStr = LogModel.STR_MODEL_DEVICERESPONE + str;
                break;
            case LogModel.CASE_MODEL_LOGIN:
                logStr = LogModel.STR_MODEL_LOGIN + str;
                break;
            case LogModel.CASE_MODEL_REGISTER:
                logStr = LogModel.STR_MODEL_REGISTER + str;
                break;
        }
        return logStr;
    }


    /**
     * 每次新增LogModel 需要对应在此处添加
     *
     * @param model
     * @return
     */
    protected static boolean isShowLog(int model) {
        switch (model) {
            case LogModel.CASE_MODEL_ORIGINAL:
            case LogModel.CASE_MODEL_COMMON:
            case LogModel.CASE_MODEL_DB:
            case LogModel.CASE_MODEL_START:
            case LogModel.CASE_MODEL_MAIN:
            case LogModel.CASE_MODEL_DEVICE:
            case LogModel.CASE_MODEL_ROADBOOK:
            case LogModel.CASE_MODEL_TRACK:
            case LogModel.CASE_MODEL_ALBUM:
            case LogModel.CASE_MODEL_ACCOUNT:
            case LogModel.CASE_MODEL_MYCENTER:
            case LogModel.CASE_MODEL_UPDATE_APP:
            case LogModel.CASE_MODEL_UPDATE_FIRMWARE:
            case LogModel.CASE_MODEL_LOGGINGINTERCEPTOR:
            case LogModel.CASE_MODEL_DEVICESET:
            case LogModel.CASE_MODEL_DEVICEGET:
            case LogModel.CASE_MODEL_DEVICESEND:
            case LogModel.CASE_MODEL_DEVICERESPONE:
                if (mIsDebug) {
                    return true;
                }
            default:
                return false;
        }
    }

    /**
     * 每次新增LogModel 需要对应在此处添加
     *
     * @return
     */
    public static String printAllLogModel() {
        return "";
    }


    public static void setModelOriginal(int modelOriginal) {
        MODEL_ORIGINAL = modelOriginal;
    }

    public static void setModelCommon(int modelCommon) {
        MODEL_COMMON = modelCommon;
    }

    public static void setModelDb(int modelDb) {
        MODEL_DB = modelDb;
    }

    public static void setModelStart(int modelStart) {
        MODEL_START = modelStart;
    }

    public static void setModelMain(int modelMain) {
        MODEL_MAIN = modelMain;
    }

    public static void setModelDevice(int modelDevice) {
        MODEL_DEVICE = modelDevice;
    }

    public static void setModelRoadbook(int modelRoadbook) {
        MODEL_ROADBOOK = modelRoadbook;
    }

    public static void setModelTrack(int modelTrack) {
        MODEL_TRACK = modelTrack;
    }

    public static void setModelAlbum(int modelAlbum) {
        MODEL_ALBUM = modelAlbum;
    }

    public static void setModelAccount(int modelAccount) {
        MODEL_ACCOUNT = modelAccount;
    }

    public static void setModelMycenter(int modelMycenter) {
        MODEL_MYCENTER = modelMycenter;
    }

    public static void setModelUpdateApp(int modelUpdateApp) {
        MODEL_UPDATE_APP = modelUpdateApp;
    }

    public static void setModelUpdateFirmware(int modelUpdateFirmware) {
        MODEL_UPDATE_FIRMWARE = modelUpdateFirmware;
    }

    public static void setModelDeviceset(int modelDeviceset) {
        MODEL_DEVICESET = modelDeviceset;
    }

    public static void setModelAlbumfull(int modelAlbumfull) {
        MODEL_ALBUMFULL = modelAlbumfull;
    }


    public static void setModelLogginginterceptor(int modelLogginginterceptor) {
        MODEL_LOGGINGINTERCEPTOR = modelLogginginterceptor;
    }

    public static void setModelDeviceSend(int modelDeviceSend) {
        MODEL_DEVICE_SEND = modelDeviceSend;
    }

    public static void setModelDeviceGet(int modelDeviceGet) {
        MODEL_DEVICE_GET = modelDeviceGet;
    }

    public static void setModelDeviceRespone(int modelDeviceRespone) {
        MODEL_DEVICE_RESPONE = modelDeviceRespone;
    }
}
