package com.leachchen.commongroup.MvpBase.UIBase

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.leachchen.commongroup.Utils.Dialog.Dialog.CommonDialog
import com.leachchen.commongroup.Utils.Dialog.Dialog.LoadingDialog
import com.leachchen.commongroup.Utils.Dialog.Dialog.ToastDialog
import rx.Subscription

/**
 * ClassName:   IBaseImpl.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/30 16:01
 **/
interface IBaseImpl {
    abstract fun getActivity(): Activity

    abstract fun getContext(): Context

    abstract fun addSubscription(s: Subscription)

    abstract fun unsubcrible()

    abstract fun finish()

    abstract fun onPause()

    abstract fun onResume()

    abstract fun onDestroy()

    abstract fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent)

    abstract fun logout()

    abstract fun showLoading(): LoadingDialog

    abstract fun showLoading(message: String): LoadingDialog

    abstract fun showLoadingDisable(): LoadingDialog

    abstract fun showLoadingDisable(message: String): LoadingDialog

    abstract fun hideLoadingDialog()

    abstract fun showToastSuccess(message: String): ToastDialog

    abstract fun showToastWarn(message: String): ToastDialog

    abstract fun showToastFail(message: String): ToastDialog

    abstract fun showOneBtnDialog(title: String, message: String, oneBtnText: String): CommonDialog

    abstract fun showOneBtnDialogDisable(title: String, message: String, oneBtnText: String): CommonDialog

    abstract fun showTwoBtnDialog(title: String, message: String, twoBtnLeftText: String, twoBtnRightText: String): CommonDialog

    abstract fun showTwoBtnDialogDisable(title: String, message: String, twoBtnLeftText: String, twoBtnRightText: String): CommonDialog

    abstract fun hideCommonDialog()
}