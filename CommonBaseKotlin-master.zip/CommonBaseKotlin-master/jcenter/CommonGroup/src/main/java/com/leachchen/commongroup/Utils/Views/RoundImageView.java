package com.leachchen.commongroup.Utils.Views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * ClassName:   RoundImageView.java
 * Description:
 * Author :     leach.chen
 * Date:        2018/12/29 17:40
 **/
public class RoundImageView extends ImageView {
    private Paint paint;
    private int cornerRadius = 100;
    private RectF layer;  //内容区域
    public Path mClipPath;// 剪裁区域路径

    public RoundImageView(Context context) {
        super(context);
        init(context, null, 0);
    }

    public RoundImageView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs, 0);
    }

    public RoundImageView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr);
    }

    private void init(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        if (paint == null) {
            paint = new Paint();
            mClipPath = new Path();
            paint.setAntiAlias(true);
            paint.setColor(Color.YELLOW);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        layer = new RectF(0, 0, w, h);
        RectF pathRect = new RectF(getPaddingLeft(), getPaddingTop(), getWidth() - getPaddingRight(), getHeight() - getPaddingBottom());
        mClipPath.reset();
        mClipPath.addRoundRect(pathRect, cornerRadius, cornerRadius, Path.Direction.CW);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int count = canvas.saveLayer(layer, null, Canvas.ALL_SAVE_FLAG);
        super.onDraw(canvas);
        canvas.drawPath(mClipPath, paint);
        canvas.restoreToCount(count);
    }
}
