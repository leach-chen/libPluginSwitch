package com.leachchen.commongroup.Utils.Dialog.DialogFragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.leachchen.commongroup.R;


/**
 * ClassName:   OneBtnDialog.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/16 14:24
 **/

public class CommonDialogFragment extends BaseDialogFragment {
    private static boolean isTwoBtnShow;//是否显示两个按钮
    private CommonDialogListener mListener;
    private TextView tv_dialog_title, tv_dialog_message;
    private Button btn_dialog_finish, btn_dialog_left, btn_dialog_right;
    private LinearLayout ll_dialog_bomcontent, ll_dialog_tm, ll_dialog_one, ll_dialog_two;
    private RelativeLayout rl_dialog_content;


    @Override
    public void onStart() {
        super.onStart();
/*      Window window = getDialog().getWindow();
        WindowManager.LayoutParams windowParams = window.getAttributes();
        windowParams.dimAmount = 0.8f;
        window.setAttributes(windowParams);*/
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //1 通过样式定义
        //setStyle(DialogFragment.STYLE_NORMAL,R.style.MyFullDialog);
        //2代码设置 无标题 无边框
        //setStyle(DialogFragment.STYLE_NO_TITLE|DialogFragment.STYLE_NO_FRAME,0);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        if (!mIsSelfDialog) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            if (!TextUtils.isEmpty(mTitle)) {
                builder.setTitle(mTitle);
            }

            if (!TextUtils.isEmpty(mMessage)) {
                builder.setMessage(mMessage);
            }

            if (isTwoBtnShow) {
                builder.setPositiveButton(mTwoBtnLeftText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mListener != null) mListener.oneBtnClick(mInstance);
                    }
                });

                builder.setNegativeButton(mTwoBtnRightText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mListener != null) mListener.twoBtnClick(mInstance);
                    }
                });
            } else {
                builder.setPositiveButton(mOneBtnText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mListener != null) mListener.oneBtnClick(mInstance);
                    }
                });
            }
            return builder.create();
        } else {
            return super.onCreateDialog(savedInstanceState);
        }

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mIsSelfDialog) {

            getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
            getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            getDialog().getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            mView = inflater.inflate(R.layout.dialog_common, container, false);
            initDialog();
            return mView;
        } else {
            return super.onCreateView(inflater, container, savedInstanceState);
        }
    }

    @Override
    protected void initView() {
        tv_dialog_title = (TextView) mView.findViewById(R.id.tv_dialog_title);
        tv_dialog_message = (TextView) mView.findViewById(R.id.tv_dialog_message);
        btn_dialog_finish = (Button) mView.findViewById(R.id.btn_dialog_finish);
        ll_dialog_bomcontent = (LinearLayout)mView.findViewById(R.id.ll_dialog_bomcontent);
        ll_dialog_tm = (LinearLayout)mView.findViewById(R.id.ll_dialog_tm);
        rl_dialog_content = (RelativeLayout) mView.findViewById(R.id.rl_dialog_content);
        ll_dialog_one = (LinearLayout)mView.findViewById(R.id.ll_dialog_one);
        ll_dialog_two = (LinearLayout)mView.findViewById(R.id.ll_dialog_two);
        btn_dialog_left = (Button) mView.findViewById(R.id.btn_dialog_left);
        btn_dialog_right = (Button) mView.findViewById(R.id.btn_dialog_right);
    }

    @Override
    protected void setListener() {
        btn_dialog_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.oneBtnClick(mInstance);
            }
        });

        btn_dialog_left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.oneBtnClick(mInstance);
            }
        });

        btn_dialog_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.twoBtnClick(mInstance);
            }
        });
    }

    @Override
    protected void initData() {
        tv_dialog_title.setText(mTitle);
        tv_dialog_message.setText(mMessage);
        btn_dialog_finish.setText(mOneBtnText);
        btn_dialog_left.setText(mTwoBtnLeftText);
        btn_dialog_right.setText(mTwoBtnRightText);
        if (TextUtils.isEmpty(mTitle)) {
            tv_dialog_title.setVisibility(View.GONE);
        }
        wrapMessage();
        if (isTwoBtnShow) {
            ll_dialog_one.setVisibility(View.GONE);
            ll_dialog_two.setVisibility(View.VISIBLE);
        } else {
            ll_dialog_one.setVisibility(View.VISIBLE);
            ll_dialog_two.setVisibility(View.GONE);
        }
    }

    private void wrapMessage() {
        Context context = getContext();
        if (mIsWrapMessage) {
            int width = (int) context.getResources().getDimension(R.dimen.dp_270);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT);
            rl_dialog_content.setLayoutParams(params);

            RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            params1.leftMargin = (int) context.getResources().getDimension(R.dimen.dp_10);
            params1.rightMargin = (int) context.getResources().getDimension(R.dimen.dp_10);
            params1.topMargin = (int) context.getResources().getDimension(R.dimen.dp_18);
            ll_dialog_tm.setId(R.id.wrap_dialog);
            ll_dialog_tm.setLayoutParams(params1);

            int btnHeight = (int) context.getResources().getDimension(R.dimen.dp_44);
            RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, btnHeight);
            params2.addRule(RelativeLayout.BELOW, R.id.wrap_dialog);
            ll_dialog_bomcontent.setLayoutParams(params2);
        } else {
            int width = (int) context.getResources().getDimension(R.dimen.dp_270);
            int height = (int) context.getResources().getDimension(R.dimen.dp_148);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
            rl_dialog_content.setLayoutParams(params);

            int btnHeight = (int) context.getResources().getDimension(R.dimen.dp_44);
            RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, btnHeight);
            params2.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            ll_dialog_bomcontent.setLayoutParams(params2);
            ll_dialog_bomcontent.setId(R.id.size_dialog);

            RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
            params1.leftMargin = (int) context.getResources().getDimension(R.dimen.dp_10);
            params1.rightMargin = (int) context.getResources().getDimension(R.dimen.dp_10);
            params1.topMargin = (int) context.getResources().getDimension(R.dimen.dp_18);
            params1.addRule(RelativeLayout.ABOVE, R.id.size_dialog);
            ll_dialog_tm.setLayoutParams(params1);
        }
    }


    public static CommonDialogFragment newOneBtnInstance(String message, String oneBtnText, FragmentManager fragmentManager, String dialogId) {
        mFragmentManager = fragmentManager;
        mDialogId = dialogId;
        mInstance = new CommonDialogFragment();
        mBundle = new Bundle();
        mBundle.putString(EXTRA_MESSAGE_KEY, message);
        mBundle.putString(EXTRA_TXT_ONEBTN_KEY, oneBtnText);
        isTwoBtnShow = false;
        return (CommonDialogFragment) mInstance;
    }

    public static CommonDialogFragment newTwoBtnInstance(String message, String twoBtnLeftText, String twoBtnRightText, FragmentManager fragmentManager, String dialogId) {
        mFragmentManager = fragmentManager;
        mDialogId = dialogId;
        mInstance = new CommonDialogFragment();
        mBundle = new Bundle();
        mBundle.putString(EXTRA_MESSAGE_KEY, message);
        mBundle.putString(EXTRA_TXT_LEFTBTN_KEY, twoBtnLeftText);
        mBundle.putString(EXTRA_TXT_RIGHTBTN_KEY, twoBtnRightText);
        isTwoBtnShow = true;
        return (CommonDialogFragment) mInstance;
    }


    @Override
    public void setDialogListener(BaseDialogFragmentListener listener) {
        if (listener instanceof CommonDialogListener) {
            mListener = (CommonDialogListener) listener;
        }
    }

    public interface CommonDialogListener extends BaseDialogFragmentListener {
        void oneBtnClick(BaseDialogFragment baseDialogFragment);

        void twoBtnClick(BaseDialogFragment baseDialogFragment);
    }

}
