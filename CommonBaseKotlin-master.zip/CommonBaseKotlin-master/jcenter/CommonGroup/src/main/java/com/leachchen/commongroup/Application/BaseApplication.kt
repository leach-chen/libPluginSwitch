package com.leachchen.commongroup.Application

import android.app.Application
import android.content.Context
import android.support.multidex.MultiDex
import android.support.multidex.MultiDexApplication
import com.leachchen.commongroup.Utils.Exception.InitException
import com.leachchen.commongroup.Utils.SharePerence.AppSharePerence


open class BaseApplication : MultiDexApplication() {

    private lateinit var mSharedPreference : AppSharePerence
    private lateinit var mException : InitException

    override fun onCreate() {
        super.onCreate()
        mSharedPreference = AppSharePerence(this)
        mException = InitException(this)
        mException.initUncaughtException()
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    fun getSharedPreference(): AppSharePerence {
        return mSharedPreference
    }

}