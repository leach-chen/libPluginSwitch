package com.leachchen.commongroup.Utils.ImageFilter;

import android.content.Context;

import com.bumptech.glide.Glide;

import jp.co.cyberagent.android.gpuimage.GPUImageFilter;
import jp.wasabeef.glide.transformations.gpu.GPUFilterTransformation;

/**
 * ClassName:   MyFilterTransformation.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/11/14 13:37
 **/

public class MyFilterTransformation extends GPUFilterTransformation {

    private int mPosition;
    public MyFilterTransformation(Context context, GPUImageFilter filter, int position) {
        super(context, Glide.get(context).getBitmapPool(), filter);
        this.mPosition = position;
    }

    @Override
    public String getId() {
        return "com.vava.dashcam.Utils.ImageFilter.MyFilterTransformation"+mPosition;
    }

}
