package com.leachchen.commongroup.Utils.Exception;

import android.content.Context;


import com.leachchen.commongroup.Utils.LogWrite.LogWrite;

import java.lang.Thread.UncaughtExceptionHandler;

/**
 * 异常类的处理，如果应用程序崩溃了，那么这个类可以将崩溃的信息打印到文件中，这样就可以方便查询是哪里出错了
 */
public class AppException implements UncaughtExceptionHandler {
	private static AppException instance;
	private UncaughtExceptionHandler mDefaultHandler;
	  
	private AppException(Context context){
		init(context); 
	}

	/**
	 * Java Single Modul 
	 * @param context
	 * @return
	 */
	public static AppException getInstance(Context context){
		if (instance == null){
			instance = new AppException(context);
		}
		return instance;
	}

	private void init(Context context){
		mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
	}

	@Override
	public void uncaughtException(Thread thread, Throwable ex){
		if (!handleException(ex) && mDefaultHandler != null){
			mDefaultHandler.uncaughtException(thread, ex);
		} else {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			}
			android.os.Process.killProcess(android.os.Process.myPid());
			System.exit(10);
		}
	}

	/**
	 * 自定义错误处理,收集错误信息 发送错误报告等操作均在此完成. 开发者可以根据自己的情况来自定义异常处理逻辑
	 * 
	 * @param ex
	 * @return true:如果处理了该异常信息;否则返回false
	 */
	private boolean handleException(final Throwable ex){
		if (ex == null){
			return true;
		}
        /**
         * 将崩溃的错误信息写入到文件中
         */
        LogWrite.writeMsg(ex);
		return true;
	} 
}