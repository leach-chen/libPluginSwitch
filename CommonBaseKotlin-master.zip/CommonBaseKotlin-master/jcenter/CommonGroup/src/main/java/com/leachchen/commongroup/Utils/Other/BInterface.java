package com.leachchen.commongroup.Utils.Other;

import android.view.View;

import java.util.List;

/**
 * ClassName:   Interface.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/8/15 18:03
 **/
public class BInterface {
    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }
    public interface PresenterCallBack
    {
        void getBizData(List dataList);
    }
}
