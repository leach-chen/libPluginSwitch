package com.leachchen.commongroup.Utils.Net.Retrofit;


import android.content.Context;

import com.leachchen.commongroup.Utils.Utils.Certificate;

import java.util.HashMap;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * ClassName:   RequestCreate.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/24 12:26
 **/

public class RequestCreate {
    private static String HTTP_VAVA_HOST = "";
    private static HashMap<String, Object> mServiceMap = new HashMap<>();
    private static final Object monitor = new Object();
    private static Context mContext;

    public static void setHost(String host)
    {
        HTTP_VAVA_HOST = host;
    }

    public static String getHost()
    {
        return HTTP_VAVA_HOST;
    }

    private static OkHttpClient client = null;
    private static OkHttpClient getOkHttpClient(){
        if(null == client){
            client = new OkHttpClient.Builder()
                    .addNetworkInterceptor(new RequestInfoInterceptor())
                    .sslSocketFactory(Certificate.getSSLSocketFactory(mContext,Certificate.certificates))
                    .build();
        }
        return client;
    }

    public static <T> T createService(Context context, Class<T> cl) {
        mContext = context;
        T service = (T) mServiceMap.get(cl.getName());
        synchronized (monitor) {
            if (service == null) {
                service = new Retrofit.Builder()
                        .baseUrl(HTTP_VAVA_HOST)
                        .client(getOkHttpClient())
                        .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                        .addConverterFactory(GsonConverterFactory.create())
                        .build().create(cl);
                mServiceMap.put(cl.getName(), service);
            }
            return service;
        }
    }

}
