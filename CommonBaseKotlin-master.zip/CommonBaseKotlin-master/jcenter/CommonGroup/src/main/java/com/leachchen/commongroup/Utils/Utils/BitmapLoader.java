package com.leachchen.commongroup.Utils.Utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.os.Environment;
import android.text.TextUtils;
import android.text.format.Time;
import android.util.Log;
import android.widget.ImageView;


import com.leachchen.commongroup.Utils.task.ILoadCallback;
import com.leachchen.commongroup.Utils.task.MyTask;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

/**
 * Bitmap加载工具(简单版)
 * @author liuyuanqi
 */
public class BitmapLoader {

    /**
     * 单例
     **/
    private static BitmapLoader loader;

    /**
     * 获取单例
     **/
    public static BitmapLoader getInstance(Context context) {
        if (null == loader) {
            loader = new BitmapLoader(context);
        }
        return loader;
    }


    /**
     * 上下文
     **/
    private Context context;

    /**
     * 图片缓存
     **/
    private Map<String, WeakReference<Bitmap>> bitmapMap;


    private BitmapLoader(Context context) {
        this.context = context;
        this.bitmapMap = new HashMap<String, WeakReference<Bitmap>>();
    }

    /**
     * 加载bitmap
     *
     * @param imageView
     * @param url
     */
    public void loadBitmap(final ImageView imageView, final String url) {

        //非空判断
        if(TextUtils.isEmpty(url) || null == imageView){
            return;
        }

        //添加图片前缀
        String temp = url;
        if(!temp.startsWith("http:")){
            temp = /**HttpUrls.BASE_URL_IMAGE + **/url;
        }else{
            temp = url;
        }
        final String fileUrl = temp;

        //设置标记，记住当前加载的图片地址
        imageView.setTag(fileUrl);

        //从缓存里面获取bitmap
        Bitmap bmp = null;
        if (bitmapMap.containsKey(fileUrl)) {
            WeakReference<Bitmap> bmpwr = bitmapMap.get(fileUrl);
            if (null != bmpwr) {
                bmp = bmpwr.get();
            }
        }

        //判断获取到的bitmap是否被回收
        if (null != bmp && !bmp.isRecycled()) {
            imageView.setImageBitmap(bmp);
        } else {

            //这个参数是为了图片裁剪时，使用的，将图片裁剪成与ImageView显示的实际大小
            int twidth = imageView.getMeasuredWidth();
            int theight = imageView.getMeasuredHeight();
            if(twidth <=0 || theight <= 0){
                twidth = 200;
                theight = 200;
            }
            final int width = twidth;
            final int height = theight;


            //启线程下载图片
            new MyTask(context, new ILoadCallback() {

                @Override
                public Object run() {

                    Bitmap bmp = null;

                    //下载图片
                    String saveFile = null;
                    if(fileUrl.startsWith("http")) {
                        saveFile = downloadFile(fileUrl);
                    }else{
                        saveFile = fileUrl;
                    }

                    //读取本地图片到bitmap
                    bmp = getBitmapNoRange(saveFile, width, height);

                    return bmp;
                }

                @Override
                public void loadedCallback(Object data) {
                    WeakReference<Bitmap> bmpwr = null;
                    if (null != data) {
                        bmpwr = new WeakReference<Bitmap>((Bitmap) data);
                        bitmapMap.put(fileUrl, bmpwr);

                        //显示bitmap
                        String tag = imageView.getTag().toString();
                        if (null != tag && tag.equals(fileUrl)) {
                            imageView.setImageBitmap(bmpwr.get());
                        }
                    }
                }
            }).execute(0);

        }

    }

    //----------------------------------以下代码为辅助代码-------------------------------------------

    /**
     * @param path
     * @return
     * @throws Exception
     */
    private Bitmap getBitmapNoRange(String path, int width, int height) {
        if (TextUtils.isEmpty(path)) {
            return null;
        }
        File file = new File(path);
        if (file.exists()) {
            int rate = 1;
            if (width > 0 && height > 0) {
                Options options = new Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(path, options);
                // if (bmp != null) {
                rate = options.outWidth / width;
                if (rate < 1) {
                    rate = options.outHeight / height;
                }
                if (rate < 1) {
                    rate = 1;
                }
            }
            Options o2 = new Options();
            o2.inSampleSize = rate;
            o2.inJustDecodeBounds = false;
            o2.inPreferredConfig = Config.RGB_565;
            Bitmap bitmap = BitmapFactory.decodeFile(path, o2);
            int rangle = readPictureDegree(path);
            return rotaingImageView(rangle, bitmap);
        }
        return null;
    }

    /**
     * @param angle
     * @param bitmap
     * @return Bitmap
     */
    private Bitmap rotaingImageView(int angle, Bitmap bitmap) {
        if (null == bitmap) {
            return null;
        }
        if (angle != 90) {
            return bitmap;
        }
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0,
                bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        bitmap.recycle();
        return resizedBitmap;
    }


    /**
     * 获取图片的方向
     *
     * @param path
     * @return degre
     */
    private int readPictureDegree(String path) {
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(path);
            int orientation = exifInterface.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return degree;
    }


    /**
     * 获取下载文件保存的路径
     *
     * @return
     */
    private File getTempImageName(String fileUrl) {
        Time t = new Time("GMT+8");
        t.setToNow();
        int year = t.year;
        int month = t.month;
        int day = t.monthDay;
        int hour = t.hour;
        int minute = t.minute;
        int second = t.second;
        //String filename = "" + year + month + day + hour + minute + second;
        String filename = null;

        //根据url得到一个唯一的文件名
        try {
            //filename = Des3.encodeOpen(fileUrl);
            filename = md5(fileUrl);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //app缓存目录
        //String dir = context.getCacheDir().getAbsolutePath();
        File welcomeimgFlord = new File(Environment.getExternalStorageDirectory().getPath() + "/vava/cache/tempImage");
        if (!welcomeimgFlord.exists()) {
            welcomeimgFlord.mkdirs();
        }


        File tempImage = new File(welcomeimgFlord, "tempimage_" + filename + ".png");

        return tempImage;
    }

    /**
     * MD5加密密码
     *
     * @param pwd
     * @return
     */
    public static String md5(String pwd) {
        char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'a', 'b', 'c', 'd', 'e', 'f' };
        try {
            byte[] strTemp = pwd.getBytes();
            MessageDigest mdTemp = MessageDigest.getInstance("MD5");
            mdTemp.update(strTemp);
            byte[] md = mdTemp.digest();
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
                str[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(str);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 下载文件，返回文件路径
     *
     * @param fileUrl
     * @return
     */
    private String downloadFile(String fileUrl) {
        try {

            //获取文件保存的路径
            File fileLocal = getTempImageName(fileUrl);
            String saveFile = fileLocal.getAbsolutePath();
            if (fileLocal.isFile() && fileLocal.exists()) {

                //文件已经下载过了，直接返回
                return saveFile;
            }


            //得到保存文件的目录
            String savePath = new File(saveFile).getParent();
            File file = new File(savePath);
            if (!file.exists()) {
                file.mkdir();
            }

            //temp.file的作用在于为了避免文件下载失败，而不会再去下载的问题
            //具体表现：图片永远加载不出来
            //文件下载到缓存文件中
            File tempFile = new File(savePath, "temp.file");
            if (tempFile.exists()) {
                //删除旧文件
                tempFile.delete();
            }

            // 创建连接
            URL url = new URL(fileUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(15000);
            conn.connect();

            // 获取文件大小
            int length = conn.getContentLength();
            int progress = 0;

            // 创建输入流
            InputStream is = conn.getInputStream();

            FileOutputStream fos = new FileOutputStream(tempFile);
            int count = 0;
            // 缓存
            byte buf[] = new byte[1024];
            // 写入到文件中
            int numread = 0;
            boolean downloaded = false;
            do {
                numread = is.read(buf);
                count += numread;
                // 计算进度条位置
                progress = (int) (((float) count / length) * 100);
                Log.d("FileDownload", "文件下载进度:" + progress + "%");

                if (numread <= 0) {
                    Log.d("FileDownload", "文件下载进度:" + 100 + "%");
                    downloaded = true;
                    break;
                }

                // 写入文件
                fos.write(buf, 0, numread);
            } while (numread > 0);// 点击取消就停止下载.
            fos.close();
            is.close();

            // 下载完成，文件重命名-作用就一个，防止文件下载失败
            if (downloaded) {
                File newPath = new File(saveFile);
                tempFile.renameTo(newPath);

                //返回路径
                return saveFile;
            }
        } catch (Exception e) {
//            e.printStackTrace();
        }

        return "";
    }

}
