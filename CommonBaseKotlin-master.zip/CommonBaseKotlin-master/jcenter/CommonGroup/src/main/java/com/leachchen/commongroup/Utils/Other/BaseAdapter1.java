package com.leachchen.commongroup.Utils.Other;

import android.content.Context;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


/**
 * ClassName:   BaseAdapter.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/8/15 18:06
 **/
public abstract class BaseAdapter1<T extends RecyclerView.ViewHolder, V> extends RecyclerView.Adapter<T> {

    public Context mContext;
    /**
     * 上下文
     */

    public BInterface.OnItemClickListener mOnItemClickListener;

    public IDataChangeListener mDataChangeListener;

    /**
     * 数据源
     */
    protected List<V> mDataList;


    public BaseAdapter1(Context context) {
        this.mContext = context;
        this.mDataList = new ArrayList<V>();
    }

    @Override
    public int getItemCount() {
        return null != mDataList ? mDataList.size() : 0;
    }

    public void setOnDataChangeListener(IDataChangeListener mDataChangeListener) {
        this.mDataChangeListener = mDataChangeListener;
    }

    /**
     * 获取position对应的数据
     * @param position
     * @return
     */
    public V getItem(int position){
        if(position >= 0 && position < getItemCount()){
            return mDataList.get(position);
        }
        return null;
    }

    /**
     * 设置数据
     *
     * @param list
     */
    public void setDataList(List<V> list) {
        this.mDataList = list;
        this.notifyDataSetChanged();
    }

    /**
     * 累加数据-分页
     *
     * @param list
     */
    public void addData(List<V> list) {
        if (null == mDataList) {
            mDataList = new ArrayList<V>();
        }
        mDataList.addAll(list);
        this.notifyDataSetChanged();
    }

    /**
     * 累加数据-分页
     *
     * @param data
     */
    public void addData(V data) {
        if (null == mDataList) {
            mDataList = new ArrayList<V>();
        }
        mDataList.add(data);
        this.notifyDataSetChanged();
    }

    /**
     * 返回数据列表
     * @return
     */
    public List<V> getDataList() {
        return mDataList;
    }

    public void setOnItemClickListener(BInterface.OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public void clean() {
        if(null != mDataList){
            mDataList.clear();
            notifyDataSetChanged();
        }
    }

}
