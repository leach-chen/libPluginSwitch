package com.leachchen.commongroup.MvpBase.UIBase

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment

/**
 * ClassName:   BaseFragment.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/30 15:59
 **/
abstract class BaseFragment : Fragment(){

    @Override
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }

    abstract fun init()

    fun startActivity(cls: Class<*>) {
        startActivity(cls, null)
    }

    fun startActivity(cls: Class<*>, bundle: Bundle?) {
        val intent = Intent()
        intent.setClass(context!!, cls)
        if (bundle != null) {
            intent.putExtras(bundle)
        }
        startActivity(intent)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

    }

    /**
     * 当前显示的fragment
     */
    private var currentFragment: Fragment? = null
    get() {
        return field
    }

    /**
     * 显示framgnet
     *
     * @param fragment
     */
    fun showFragment(frameLayoutId: Int, fragment: Fragment?) {

        //非空
        if (null == fragment) {
            return
        }

        //已经显示
        if (fragment.isAdded && !fragment.isHidden) {
            return
        }


        //FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        val fragmentManager = childFragmentManager
        val transation = fragmentManager.beginTransaction()

        //隐藏当前显示的fragment
        if (null != currentFragment && currentFragment!!.isAdded()) {
            transation.hide(currentFragment!!)
        }

        //显示传入的fragment
        if (!fragment.isAdded) {
            transation.add(frameLayoutId, fragment)
            transation.commit()
        } else {

            transation.show(fragment)
            transation.commit()
        }

        //记住当前的fragment
        currentFragment = fragment
    }

    fun hideFragment(fragment: Fragment?) {
        if (null != fragment && fragment.isAdded && !fragment.isHidden) {
            val fragmentManager = childFragmentManager
            val transation = fragmentManager.beginTransaction()
            transation.hide(fragment)
            transation.commit()
        }
    }

}