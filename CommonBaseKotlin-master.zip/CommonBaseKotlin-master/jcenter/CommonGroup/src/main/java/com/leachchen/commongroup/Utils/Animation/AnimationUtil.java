package com.leachchen.commongroup.Utils.Animation;

import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;

/**
 * ClassName:   AnimationHelp.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/8/29 19:29
 **/

public class AnimationUtil {

    public static final int ANIMATION_DURATION = 500;
    /*@android:anim/accelerate_interpolator： 越来越快
    @android:anim/decelerate_interpolator：越来越慢
    @android:anim/accelerate_decelerate_interpolator：先快后慢
    @android:anim/anticipate_interpolator: 先后退一小步然后向前加速
    @android:anim/overshoot_interpolator：快速到达终点超出一小步然后回到终点
    @android:anim/anticipate_overshoot_interpolator：到达终点超出一小步然后回到终点
    @android:anim/bounce_interpolator：到达终点产生弹球效果，弹几下回到终点
    @android:anim/linear_interpolator：均匀速度。*/
    private static Handler mHandler = new Handler();


    public interface AnimationListener extends Animation.AnimationListener{
        void onAnimationFinish();
    }

    private static void listenerHelp(Animation animation, final AnimationListener animationListener) {
        if (animationListener == null) return;
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                animationListener.onAnimationStart(animation);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                animationListener.onAnimationEnd(animation);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                animationListener.onAnimationRepeat(animation);
            }
        });

        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                animationListener.onAnimationFinish();  //防止动画在后台时不触发finish
            }
        }, ANIMATION_DURATION);
    }

    /**
     * 由下往上进入动画,animationListener不需要时传NULL
     */
    public static TranslateAnimation animationBottomIn(AnimationListener animationListener) {
        TranslateAnimation translateAnimation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 1, Animation.RELATIVE_TO_SELF, 0);
        translateAnimation.setDuration(ANIMATION_DURATION);
        translateAnimation.setInterpolator(new LinearInterpolator());
        translateAnimation.setFillAfter(true);
        listenerHelp(translateAnimation,animationListener);
        return translateAnimation;
    }

    /**
     * 向下消失动画
     */
    public static TranslateAnimation animationBottomOut(AnimationListener animationListener) {
        TranslateAnimation translateAnimation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 1);
        translateAnimation.setDuration(ANIMATION_DURATION);
        translateAnimation.setInterpolator(new LinearInterpolator());
        translateAnimation.setFillAfter(true);
        listenerHelp(translateAnimation,animationListener);
        return translateAnimation;
    }


    /**
     * 由上往下进入动画
     */
    public static TranslateAnimation animationTopIn(AnimationListener animationListener) {
        TranslateAnimation translateAnimation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, -1, Animation.RELATIVE_TO_SELF, 0);
        translateAnimation.setDuration(ANIMATION_DURATION);
        translateAnimation.setInterpolator(new LinearInterpolator());
        translateAnimation.setFillAfter(true);
        listenerHelp(translateAnimation,animationListener);
        return translateAnimation;
    }

    /**
     * 向上消失动画
     */
    public static TranslateAnimation animationTopOut(AnimationListener animationListener) {
        TranslateAnimation translateAnimation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, -1);
        translateAnimation.setDuration(ANIMATION_DURATION);
        translateAnimation.setInterpolator(new LinearInterpolator());
        translateAnimation.setFillAfter(true);
        listenerHelp(translateAnimation,animationListener);
        return translateAnimation;
    }


    /**
     * 向左进入动画
     */
    public static TranslateAnimation animationLeftIn(AnimationListener animationListener) {
        TranslateAnimation translateAnimation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 1, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0);
        translateAnimation.setDuration(ANIMATION_DURATION);
        translateAnimation.setInterpolator(new LinearInterpolator());
        translateAnimation.setFillAfter(true);
        listenerHelp(translateAnimation,animationListener);
        return translateAnimation;
    }

    /**
     * 向右消失动画
     */
    public static TranslateAnimation animationRightOut(AnimationListener animationListener) {
        TranslateAnimation translateAnimation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 1, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0);
        translateAnimation.setDuration(ANIMATION_DURATION);
        translateAnimation.setInterpolator(new LinearInterpolator());
        translateAnimation.setFillAfter(true);
        listenerHelp(translateAnimation,animationListener);
        return translateAnimation;
    }

    /**
     * 淡入动画
     */
    public static AlphaAnimation animationAlphaIn(AnimationListener animationListener) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(ANIMATION_DURATION);
        alphaAnimation.setInterpolator(new LinearInterpolator());
        alphaAnimation.setFillAfter(true);
        listenerHelp(alphaAnimation,animationListener);
        return alphaAnimation;
    }

    /**
     * 淡出动画
     */
    public static AlphaAnimation animationAlphaOut(AnimationListener animationListener) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
        alphaAnimation.setDuration(ANIMATION_DURATION);
        alphaAnimation.setInterpolator(new LinearInterpolator());
        alphaAnimation.setFillAfter(true);
        listenerHelp(alphaAnimation,animationListener);
        return alphaAnimation;
    }

    public static void animationRemove() {
        mHandler.removeCallbacksAndMessages(null);
    }


}
