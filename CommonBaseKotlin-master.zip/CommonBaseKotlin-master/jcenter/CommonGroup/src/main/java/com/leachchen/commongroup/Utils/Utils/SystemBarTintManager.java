package com.leachchen.commongroup.Utils.Utils;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.view.View;
import android.view.Window;


import com.leachchen.commongroup.Utils.LogWrite.LogWrite;

import java.lang.reflect.Method;

/**
 * ClassName:   SystemBarTintManager.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/11/10 18:17
 **/

public class SystemBarTintManager {

    public static void setHideVirtualKey(Context context, Window window){
        try {
            //保持布局状态
            int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                    //布局位于状态栏下方
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    //全屏
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    //隐藏导航栏
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
            if (Build.VERSION.SDK_INT >= 19) {
                uiOptions |= 0x00001000;
            } else {
                uiOptions |= View.SYSTEM_UI_FLAG_LOW_PROFILE;
            }
            if(Build.VERSION.SDK_INT >= 19 && checkDeviceHasNavigationBar(context)) {
                window.getDecorView().setSystemUiVisibility(uiOptions);
            }
        }catch (Exception e)
        {
            LogWrite.writeMsg(e);
        }
    }

    public static boolean checkDeviceHasNavigationBar(Context context) {
        boolean hasNavigationBar = false;
        Resources rs = context.getResources();
        int id = rs.getIdentifier("config_showNavigationBar", "bool", "android");
        if (id > 0) {
            hasNavigationBar = rs.getBoolean(id);
        }
        try {
            Class systemPropertiesClass = Class.forName("android.os.SystemProperties");
            Method m = systemPropertiesClass.getMethod("get", String.class);
            String navBarOverride = (String) m.invoke(systemPropertiesClass, "qemu.hw.mainkeys");
            if ("1".equals(navBarOverride)) {
                hasNavigationBar = false;
            } else if ("0".equals(navBarOverride)) {
                hasNavigationBar = true;
            }
        } catch (Exception e) {
        }
        return hasNavigationBar;
    }

    public static void setShowVirtualKey(Context context, Window window){
        try {
            //保持布局状态
            int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                    //布局位于状态栏下方
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            if(Build.VERSION.SDK_INT >= 19 && checkDeviceHasNavigationBar(context))  {
                window.getDecorView().setSystemUiVisibility(uiOptions);
            }
        }catch (Exception e)
        {
            LogWrite.writeMsg(e);
        }
    }

}
