package com.leachchen.commongroup.Utils.Net.callbak;

/**
 * 回调
 * ClassName:   IBaseCallback.java
 * Description:
 * Author :     jame.liu
 * Date:        2017/9/7 13:51
 **/
public interface IBaseCallback1<T> {
    public void onSuccess(T t);
    public void onFailed(String code, String msg);
}
