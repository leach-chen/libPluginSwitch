package com.leachchen.commongroup.Utils.Other;

/**
 * ClassName:   Constant.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/6/16 13:55
 **/

public class BaseConstant {
    /**
     * show toast or snackbar,true is snackbar false is toast
     */
    public static final int SNACKBAR = 1;
    public static final int TOAST = 2;
    public static final int SELF = 3;
}
