package com.leachchen.commongroup.Utils.Net.Retrofit;

/**
 * 异常类，当获取的数据不是我们需要时，抛出异常
 *
 * Created by jame on 2017/7/27.
 */
public class ApiException extends RuntimeException {

    public String stateCode;

    /**
     * 异常信息
     * @param detailMessage
     */
    public ApiException(String stateCode, String detailMessage) {
        super(detailMessage);
        this.stateCode = stateCode;
    }
}
