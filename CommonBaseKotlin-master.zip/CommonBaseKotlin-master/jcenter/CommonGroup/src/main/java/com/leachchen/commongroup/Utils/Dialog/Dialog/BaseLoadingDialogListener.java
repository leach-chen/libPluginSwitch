package com.leachchen.commongroup.Utils.Dialog.Dialog;

/**
 * ClassName:   BaseDialoglListener.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/25 19:25
 **/

public interface BaseLoadingDialogListener {
}
