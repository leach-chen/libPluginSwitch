package com.leachchen.commongroup.Utils.DataManager;
/**
 * ClassName:   AVData.java
 * Description:
 * Author :     vincent.chen
 * Date:        2017/9/6 13:51
 **/
public class AVData {

    //流类型
    public static final int S_TYPE_VIDEO = 0x01;//视频流
    public static final int S_TYPE_AUDIO = 0x02;//音频流

    //编码类型
    public static final int E_TYPE_VIDEO_H264 = 0x01;//H264
    public static final int E_TYPE_VIDEO_MJPEG = 0x02;//MJPEG
    public static final int E_TYPE_AUDIO_PCM = 0x00;//H264
    public static final int E_TYPE_AUDIO_G711A = 0x01;//MJPEG


    //I/P/B帧
    public static final int F_TYPE_IFRAME = 0x01; //I帧.
    public static final int F_TYPE_PFRAME = 0x02; //P帧.
    public static final int F_TYPE_BFRAME = 0x03; //B帧.

    private int S_type = 0;//音频/视频流
    private int F_type = 0;//I/P/B帧
    private int F_rate = 0;//设备发送的视频帧率
    private int Width = 0;//视频高度
    private int Height = 0;//视频高度
    private int Tsnap = 0;//时间戳
    private byte[] BufData = null;//音/视频数据
    private int DataSize = 0;//有效数据长度

    private int VideoFormat = E_TYPE_VIDEO_H264;
    private int AudioFormat = E_TYPE_AUDIO_G711A;

    public AVData(int s_type, int f_type, int f_rate, int width, int height, int tsnap, byte[] bufData, int dataSize, int videoFormat, int audioFormat){
        S_type = s_type;
        F_type = f_type;
        F_rate = f_rate;
        Width = width;
        Height = height;
        Tsnap = tsnap;
        BufData = bufData;
        DataSize = dataSize;
        VideoFormat = videoFormat;
        AudioFormat = audioFormat;
    }

    public int getS_type() {
        return S_type;
    }

    public void setS_type(int s_type) {
        S_type = s_type;
    }

    public int getF_type() {
        return F_type;
    }

    public void setF_type(int f_type) {
        F_type = f_type;
    }

    public int getF_rate() {
        return F_rate;
    }

    public void setF_rate(int f_rate) {
        F_rate = f_rate;
    }

    public int getWidth() {
        return Width;
    }

    public void setWidth(int width) {
        Width = width;
    }

    public int getHeight() {
        return Height;
    }

    public void setHeight(int height) {
        Height = height;
    }

    public int getTsnap() {
        return Tsnap;
    }

    public void setTsnap(int tsnap) {
        Tsnap = tsnap;
    }

    public byte[] getBufData() {
        return BufData;
    }

    public void setBufData(byte[] bufData) {
        BufData = bufData;
    }

    public int getDataSize() {
        return DataSize;
    }

    public void setDataSize(int dataSize) {
        DataSize = dataSize;
    }

    public int getVideoFormat() {
        return VideoFormat;
    }

    public void setVideoFormat(int videoFormat) {
        VideoFormat = videoFormat;
    }

    public int getAudioFormat() {
        return AudioFormat;
    }

    public void setAudioFormat(int audioFormat) {
        AudioFormat = audioFormat;
    }
}
