package com.leachchen.commongroup.Utils.task;


public interface ILoadCallback0 {
	/**
	 * 在异步任务的doInBackground执行该方法
	 * @return data
	 */
	public Object run();
}
