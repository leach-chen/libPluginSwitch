package com.leachchen.provider.service

import android.support.v4.app.Fragment


/**
 * 定义Home模块提供的服务
 */
interface HomeService {

    fun getHomeFragment(): Fragment

}