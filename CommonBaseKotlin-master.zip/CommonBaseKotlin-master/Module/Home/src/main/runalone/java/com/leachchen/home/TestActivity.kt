package com.leachchen.home

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.leachchen.home.UI.HomeFragment

class TestActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home_activity_test)

        supportFragmentManager.beginTransaction().replace(R.id.test_ll, HomeFragment()).commit()
    }
}
