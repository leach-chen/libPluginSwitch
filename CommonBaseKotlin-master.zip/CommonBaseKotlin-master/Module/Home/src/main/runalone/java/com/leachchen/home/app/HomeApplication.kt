package com.leachchen.home.app


class HomeApplication : android.app.Application() {
    override fun onCreate() {
        super.onCreate()
    }
}