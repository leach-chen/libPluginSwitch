package com.leachchen.home.Presenter.Interface

import com.leachchen.home.UI.HomeImpl

/**
 * ClassName:   IHomePresenter.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 15:40
 **/
interface IHomePresenter {
    fun requestData(bk: HomeImpl.FunCallBack)
}