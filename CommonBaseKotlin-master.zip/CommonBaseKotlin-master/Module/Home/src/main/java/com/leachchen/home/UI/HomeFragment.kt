package com.leachchen.home.UI

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.leachchen.home.Presenter.HomePresenter
import com.leachchen.home.R
import com.leachchen.mbase.MBase.MBaseNormalFragment
import com.leachchen.mbase.API.RequestImpl.ConstantService


/**
 * ClassName:   HomeFragment.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/25 18:08
 **/
class HomeFragment : MBaseNormalFragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.home_fragment, container, false)
    }

    override fun init() {

        ConstantService.setDevelop(ConstantService.isPtest)
        mImpl = HomeImpl(context as Activity, context as Activity,true)
        mPresenter = HomePresenter(mImpl as HomeImpl)
    }
}