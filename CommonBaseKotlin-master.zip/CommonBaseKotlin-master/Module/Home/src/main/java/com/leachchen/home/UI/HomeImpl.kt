package com.leachchen.home.UI

import android.app.Activity
import android.content.Context
import android.view.View
import android.widget.Toast
import com.leachchen.commongroup.Utils.RxBus.RxBus
import com.leachchen.home.Presenter.HomePresenter
import com.leachchen.home.UI.Interface.IHomeImpl
import com.leachchen.mbase.Constant.ConstantRxbus
import com.leachchen.mbase.MBase.MBaseImpl
import com.leachchen.mbase.API.Common.Auth.AuthRespone

/**
 * ClassName:   HomeImpl.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 15:41
 **/
class HomeImpl(activity: Activity, context: Context, isInit: Boolean) : MBaseImpl(activity, context, isInit), IHomeImpl {
    override fun initView() {
    }

    override fun setListener() {
    }

    override fun initData() {

        var sub = RxBus.get().register(ConstantRxbus.RXBUS_TEST_MESSAGE, String::class.java).subscribe {
            (mPresenter as HomePresenter).requestData(object : FunCallBack {
                override fun success(obj: Any) {
                    Toast.makeText(getContext(), "request success:" + (obj as AuthRespone).stateMsg, Toast.LENGTH_SHORT).show()
                }

                override fun fail(e: Exception) {
                    Toast.makeText(getContext(), "request fail:" + e.toString(), Toast.LENGTH_SHORT).show()
                }
            })
        }

        addSubscription(sub)
    }

    override fun onClick(v: View?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    interface FunCallBack {
        fun success(obj: Any)
        fun fail(e: Exception)
    }
}