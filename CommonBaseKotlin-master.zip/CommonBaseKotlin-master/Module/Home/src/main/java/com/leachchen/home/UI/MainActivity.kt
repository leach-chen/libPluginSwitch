package com.leachchen.home.UI

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.leachchen.home.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home_activity_main)
    }
}
