package com.leachchen.home.component

import com.leachchen.provider.component.IApplicationLoad
import com.leachchen.provider.component.Router
import com.leachchen.provider.service.HomeService

class HomeApplicationLoad : IApplicationLoad {

    var router = Router.instance

    override fun registered() {
        router.addService(HomeService::class.java.simpleName, HomeServiceImpl())
    }

    override fun unregistered() {
        router.removeService(HomeService::class.java.simpleName)
    }

}