package com.leachchen.home.UI.Interface

/**
 * ClassName:   IHomeImpl.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 15:41
 **/
interface IHomeImpl {
}