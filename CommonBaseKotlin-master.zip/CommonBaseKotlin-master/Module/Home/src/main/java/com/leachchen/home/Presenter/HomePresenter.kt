package com.leachchen.home.Presenter

import com.leachchen.commongroup.MvpBase.UIBase.BaseImpl
import com.leachchen.commongroup.Utils.Net.Retrofit.RequestCreate
import com.leachchen.home.Presenter.Interface.IHomePresenter
import com.leachchen.home.UI.HomeImpl
import com.leachchen.mbase.MBase.MBasePresenter
import com.leachchen.mbase.API.Common.Auth.AuthApi
import com.leachchen.mbase.API.Common.Auth.AuthBodyData
import com.leachchen.mbase.API.Common.Auth.AuthRespone
import com.leachchen.mbase.API.Other.ResultFuc
import com.leachchen.mbase.API.RequestImpl.ParamsDefine
import rx.Subscriber
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.lang.Exception

/**
 * ClassName:   HomeImpl.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 15:40
 **/
class HomePresenter(impl : BaseImpl) : MBasePresenter(impl) ,IHomePresenter{

    override fun requestData(bk: HomeImpl.FunCallBack) {
        mImpl!!.showLoading().showDialog()
        RequestCreate.createService(mImpl!!.getContext(), AuthApi::class.java).getAuthToken(ParamsDefine.getRequestParams("0"), AuthBodyData(ParamsDefine.appCode, ParamsDefine.appSecret, ParamsDefine.grantType, ParamsDefine.appVersionOut)).map(object : ResultFuc<AuthRespone>() {
            override fun handSuccessResult(authRespone: AuthRespone): AuthRespone {
                return authRespone
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(object : Subscriber<AuthRespone>() {
            override fun onNext(t: AuthRespone?) {
                if (t != null) {
                    mImpl!!.hideLoadingDialog()
                    bk.success(t)
                }
            }

            override fun onCompleted() {
            }

            override fun onError(e: Throwable) {
                mImpl!!.hideLoadingDialog()
                bk.fail(e as Exception)
            }
        })
    }


}