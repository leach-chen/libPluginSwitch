package com.leachchen.home.component

import android.support.v4.app.Fragment
import com.leachchen.home.UI.HomeFragment
import com.leachchen.provider.service.HomeService

/**
 * home模块提供服务的具体实现者
 */
class HomeServiceImpl : HomeService {

    override fun getHomeFragment(): Fragment {
        return HomeFragment()
    }
}