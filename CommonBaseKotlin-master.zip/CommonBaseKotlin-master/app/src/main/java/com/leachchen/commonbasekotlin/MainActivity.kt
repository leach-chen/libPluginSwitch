package com.leachchen.commonbasekotlin

import android.support.v4.app.Fragment
import com.leachchen.commongroup.Utils.RxBus.RxBus
import com.leachchen.mbase.Constant.ConstantRxbus
import com.leachchen.mbase.MBase.MBaseNormalActivity
import com.leachchen.provider.component.Router
import com.leachchen.provider.service.HomeService
import kotlinx.android.synthetic.main.app_activity_main.*

class MainActivity : MBaseNormalActivity() {

    private lateinit var mHomeFragment: Fragment

    override fun setContentView() {
        setContentView(R.layout.app_activity_main)
    }

    override fun init() {
        val router = Router.instance
        val homeService = router.getService(HomeService::class.simpleName)
        if (homeService != null) {
            mHomeFragment = (homeService as HomeService).getHomeFragment()
        }
        val bt = supportFragmentManager.beginTransaction()
        bt.add(R.id.fl_content, mHomeFragment)
        bt.commit()

        btn_gorequest.setOnClickListener {
            RxBus.get().post(ConstantRxbus.RXBUS_TEST_MESSAGE,"")
        }
    }
}
