package com.leachchen.commonbasekotlin

import android.animation.ValueAnimator
import android.app.PendingIntent.getActivity
import android.os.Handler
import android.view.Window
import android.view.WindowManager
import com.leachchen.mbase.MBase.MBaseNormalActivity
import android.R.attr.animation
import android.util.Log
import kotlinx.android.synthetic.main.app_activity_welcome.*


/**
 * ClassName:   WelcomeActivity.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 12:01
 **/
class WelcomeActivity : MBaseNormalActivity(){
    override fun init() {
        Handler().postDelayed({
            startActivity(MainActivity::class.java)
            this@WelcomeActivity.finish()
            this@WelcomeActivity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        },3000)

        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.setDuration(3000)
        anim.addUpdateListener(object :ValueAnimator.AnimatorUpdateListener{
            override fun onAnimationUpdate(animation: ValueAnimator?) {
                val currentValue = animation!!.getAnimatedValue() as Float
                Log.e("mytest","aa:"+currentValue)

                if(currentValue < 0.5f) {
                    text_wlecome.alpha = 1 - currentValue
                }else
                {
                    text_wlecome.alpha = currentValue
                }
                //text_wlecome.requestLayout()
            }
        })
        anim.start()
    }

    override fun setContentView() {
        //全屏
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val flag = WindowManager.LayoutParams.FLAG_FULLSCREEN
        val window = window
        window.setFlags(flag, flag)

        setContentView(R.layout.app_activity_welcome)
    }
}