package com.leachchen.commonbasekotlin

import com.alibaba.android.arouter.launcher.ARouter
import com.leachchen.commongroup.Application.BaseApplication
import com.tencent.bugly.crashreport.CrashReport

class AppApplication : BaseApplication() {

    override fun onCreate() {
        super.onCreate()
        if(BuildConfig.DEBUG){
            // 打印日志
            ARouter.openLog()
            //开启调试模式
            ARouter.openDebug()
            CrashReport.initCrashReport(getApplicationContext(), "111", false)
        }
        ARouter.init(this)
    }


}