package com.leachchen.commongroup.Utils.Other;

import android.content.Context;
import android.support.v7.widget.RecyclerView;


/**
 * ClassName:   BaseAdapter.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/8/15 18:06
 **/
public abstract class BaseAdapter<T extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<T>{

    public BInterface.OnItemClickListener mOnItemClickListener;
    public Context mContext;

    public BaseAdapter(Context context)
    {
        this.mContext = context;
    }

    public void setOnItemClickListener(BInterface.OnItemClickListener onItemClickListener)
    {
        this.mOnItemClickListener = onItemClickListener;
    }
}
