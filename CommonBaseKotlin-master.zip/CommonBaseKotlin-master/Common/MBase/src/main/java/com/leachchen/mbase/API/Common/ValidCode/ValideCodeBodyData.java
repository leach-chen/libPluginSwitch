package com.leachchen.mbase.API.Common.ValidCode;

/**
 * ClassName:   BodyData.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 16:01
 **/
public class ValideCodeBodyData {


    private String userMail;
    private String useType;
    private String vfcode;

    public ValideCodeBodyData(String userMail, String useType, String vfcode)
    {
        this.userMail = userMail;
        this.useType = useType;
        this.vfcode = vfcode;
    }


    public String getUserMail() {
        return userMail;
    }

    public void setUserMail(String userMail) {
        this.userMail = userMail;
    }

    public String getUseType() {
        return useType;
    }

    public void setUseType(String useType) {
        this.useType = useType;
    }

    public String getVfcode() {
        return vfcode;
    }

    public void setVfcode(String vfcode) {
        this.vfcode = vfcode;
    }
}
