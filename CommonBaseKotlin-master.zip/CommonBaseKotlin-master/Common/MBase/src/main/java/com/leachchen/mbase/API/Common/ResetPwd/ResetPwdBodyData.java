package com.leachchen.mbase.API.Common.ResetPwd;

/**
 * ClassName:   BodyData.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 16:01
 **/
public class ResetPwdBodyData {


    private String userMail;
    private String userPwd;
    private String vfcode;
    private String useType;

    public ResetPwdBodyData(String userMail, String userPwd, String vfcode, String useType)
    {
        this.userMail = userMail;
        this.userPwd = userPwd;
        this.vfcode = vfcode;
        this.useType = useType;
    }

    public String getUserMail() {
        return userMail;
    }

    public void setUserMail(String userMail) {
        this.userMail = userMail;
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }

    public String getVfcode() {
        return vfcode;
    }

    public void setVfcode(String vfcode) {
        this.vfcode = vfcode;
    }

    public String getUseType() {
        return useType;
    }

    public void setUseType(String useType) {
        this.useType = useType;
    }
}
