package com.leachchen.mbase.API.RequestImpl;

import java.io.Serializable;

/**
 * Created by josh.hong on 2017/3/15.
 * 服务端请求公用返回
 */

public class BaseRespone implements Serializable {
    private static final long serialVersionUID = 100000012L;
    public String stateCode;
    public String stateMsg;

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getStateMsg() {
        return stateMsg;
    }

    public void setStateMsg(String stateMsg) {
        this.stateMsg = stateMsg;
    }

    /**
     * 是否为成功请求
     *
     * @return
     */
    public boolean isSuccessResponse() {
        if (null == stateCode) {
            return false;
        }
        if (stateCode.equals(ResponeCode.CODE_SUCCESS)) {
            return true;
        }
        return false;
    }
}
