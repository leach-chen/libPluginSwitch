package com.leachchen.mbase.API.Common.Help;

/**
 * ClassName:   BodyData.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 16:01
 **/
public class HelpBodyData {



    public final static String HELP_TYPE = "C101";
    public final static String FD_TYPE = "C102";

    private String fdMail;
    private String fdType;
    private String fdContent;

    public HelpBodyData(String fdMail, String fdType, String fdContent) {
        this.fdMail = fdMail;
        this.fdType = fdType;
        this.fdContent = fdContent;
    }

    public String getFdMail() {
        return fdMail;
    }

    public void setFdMail(String fdMail) {
        this.fdMail = fdMail;
    }

    public String getFdType() {
        return fdType;
    }

    public void setFdType(String fdType) {
        this.fdType = fdType;
    }

    public String getFdContent() {
        return fdContent;
    }

    public void setFdContent(String fdContent) {
        this.fdContent = fdContent;
    }
}
