package com.leachchen.mbase.API.Common.login;

import java.util.Map;

import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import rx.Observable;

/**
 * ClassName:   LoginApi.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 9:54
 **/
public interface LoginApi {
    @POST("mi/base/user/login/in?")
    Observable<LoginRespone> getLogin(
            @QueryMap Map<String, String> stringMap,
            @Body LoginBodyData loginBodyData
    );
}
