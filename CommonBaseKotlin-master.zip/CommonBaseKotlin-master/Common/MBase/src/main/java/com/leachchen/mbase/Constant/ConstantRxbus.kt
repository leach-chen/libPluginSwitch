package com.leachchen.mbase.Constant

/**
 * ClassName:   RxBus.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 16:06
 **/
class ConstantRxbus {
    companion object {
        val RXBUS_TEST_MESSAGE = "rxbus_test_message"
    }
}