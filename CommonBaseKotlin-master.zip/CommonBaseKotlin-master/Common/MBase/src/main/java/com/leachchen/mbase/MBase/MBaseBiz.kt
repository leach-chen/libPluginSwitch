package com.leachchen.mbase.MBase

import com.leachchen.commongroup.MvpBase.BizBase.BaseBiz
import com.leachchen.commongroup.Utils.Other.BInterface

/**
 * ClassName:   MBaseBiz.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 11:22
 **/
abstract class MBaseBiz : BaseBiz() {

    @Override
    override fun setPresenterCallBack(presenterCallBack: BInterface.PresenterCallBack) {
        this.mPresenterCallBack = presenterCallBack
    }
}