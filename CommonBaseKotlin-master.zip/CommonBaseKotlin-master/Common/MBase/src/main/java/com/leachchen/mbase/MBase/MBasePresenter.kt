package com.leachchen.mbase.MBase

import com.leachchen.commongroup.MvpBase.PresenterBase.BasePresenter
import com.leachchen.commongroup.MvpBase.UIBase.BaseImpl

/**
 * ClassName:   MBasePresenter.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 11:14
 **/
abstract class MBasePresenter(impl :BaseImpl) : BasePresenter(impl) {
    init {

    }
}