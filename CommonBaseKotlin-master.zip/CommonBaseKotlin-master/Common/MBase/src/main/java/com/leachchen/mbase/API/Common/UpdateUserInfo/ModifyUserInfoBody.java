package com.leachchen.mbase.API.Common.UpdateUserInfo;

/**
 * Created by josh.hong on 2017/5/25.
 */

public class ModifyUserInfoBody {
    private String userInfo;
    private int type;

    public ModifyUserInfoBody(String userInfo, int type)
    {
        this.userInfo = userInfo;
        this.type = type;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}

