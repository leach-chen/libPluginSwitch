package com.leachchen.mbase.MBase

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.leachchen.commongroup.MvpBase.UIBase.BaseImpl

/**
 * ClassName:   MBaseImpl.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 11:16
 **/
abstract class MBaseImpl(activity: Activity, context: Context, isInit: Boolean) : BaseImpl(activity, context, isInit) {
    init {
        if (isInit)
            init()
    }

    @Override
    override fun onResume() {
        super.onResume()
    }


    @Override
    override fun onPause() {
        super.onPause()
    }

    @Override
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {

    }

}