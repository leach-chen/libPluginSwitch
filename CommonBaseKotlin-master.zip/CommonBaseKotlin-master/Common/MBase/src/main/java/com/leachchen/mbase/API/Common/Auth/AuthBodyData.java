package com.leachchen.mbase.API.Common.Auth;

/**
 * ClassName:   Body.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/26 17:06
 **/
public class AuthBodyData {


    private String appCode;
    private String appSecret;
    private String grantType;
    private String appVersionOut;

    public AuthBodyData(String appCode, String appSecret, String grantType, String appVersionOut)
    {
        this.appCode = appCode;
        this.appSecret = appSecret;
        this.grantType = grantType;
        this.appVersionOut = appVersionOut;
    }


    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getGrantType() {
        return grantType;
    }

    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    public String getAppVersionOut() {
        return appVersionOut;
    }

    public void setAppVersionOut(String appVersionOut) {
        this.appVersionOut = appVersionOut;
    }

}