package com.leachchen.mbase.API.Common.login;

import com.leachchen.mbase.API.RequestImpl.BaseRespone;

import java.util.Map;

import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import rx.Observable;

/**
 * ClassName:   MyCenterAPI.java
 * Description: 个人中心接口
 * Author :     jame.liu
 * Date:        2017/7/31 13:57
 **/
public interface MyCenterAPI {

    @POST("mi/base/user/logout?")
    Observable<BaseRespone> logout(@QueryMap Map<String, String> stringMap);


}
