package com.leachchen.mbase.API.Common.Register;

/**
 * ClassName:   RegisterBody.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/28 10:39
 **/
public class RegisterBodyData {



    private String userMail;
    private String userPwd;
    private String validateCode;

    public RegisterBodyData(String userMail, String userPwd, String validateCode)
    {
        this.userMail = userMail;
        this.userPwd = userPwd;
        this.validateCode = validateCode;
    }


    public String getUserMail() {
        return userMail;
    }

    public void setUserMail(String userMail) {
        this.userMail = userMail;
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }


    public String getCode() {
        return validateCode;
    }

    public void setCode(String validateCode) {
        this.validateCode = validateCode;
    }


}
