package com.leachchen.mbase.API.RequestImpl;

import com.leachchen.commongroup.Utils.Net.Retrofit.RequestCreate;

/**
 * ClassName:   ConstantDebug.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/11/1 9:58
 **/

public class ConstantService {

    public static final int isDev = 1001;
    public static final int isTest = 1002;
    public static final int isPtest = 1003;
    public static final int isPro = 1004;
    public static boolean isDebug;


    public static void setDevelop(int type)
    {
        switch (type)
        {
            case isDev:
                RequestCreate.setHost("https://app-dev.vavafood.com");
                isDebug = true;
                break;
            case isTest:
                RequestCreate.setHost("https://app-test.vavafood.com");
                isDebug = true;
                break;
            case isPtest:
                RequestCreate.setHost("https://app-ptest.vavafood.com");
                isDebug = true;
                break;
            case isPro:
                RequestCreate.setHost("https://app.vavasmart.com");
                isDebug = false;
                break;
        }
    }



}
