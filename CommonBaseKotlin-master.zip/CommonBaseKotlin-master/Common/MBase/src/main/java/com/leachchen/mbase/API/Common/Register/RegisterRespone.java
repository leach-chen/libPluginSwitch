package com.leachchen.mbase.API.Common.Register;


import com.leachchen.mbase.API.RequestImpl.BaseRespone;

/**
 * ClassName:   RegisterRespone.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/28 10:46
 **/
public class RegisterRespone extends BaseRespone {


    /**
     * stateCode : 0
     * stateMsg : success
     * data : {"userMail":"test@qq","userFirstName":"c","userLastName":"c"}
     */

    /**
     * userMail : test@qq
     * userFirstName : c
     * userLastName : c
     */

    private DataBean data;

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getStateMsg() {
        return stateMsg;
    }

    public void setStateMsg(String stateMsg) {
        this.stateMsg = stateMsg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String userMail;
        private String userFirstName;
        private String userLastName;

        public String getUserMail() {
            return userMail;
        }

        public void setUserMail(String userMail) {
            this.userMail = userMail;
        }

        public String getUserFirstName() {
            return userFirstName;
        }

        public void setUserFirstName(String userFirstName) {
            this.userFirstName = userFirstName;
        }

        public String getUserLastName() {
            return userLastName;
        }

        public void setUserLastName(String userLastName) {
            this.userLastName = userLastName;
        }
    }
}
