package com.leachchen.mbase.API.RequestImpl;

import android.content.Context;
import android.text.TextUtils;

import java.util.HashMap;

public class ResponeCode {

    private static ResponeCode instance = null;

    public static ResponeCode getInstance() {
        if (instance == null) {
            instance = new ResponeCode();
        }
        return instance;
    }

    static HashMap<String, String> codeMap = new HashMap<String, String>();


    /**
     * code = 0，业务处理成功
     */
    public final static String CODE_SUCCESS = "0";

    /**
     * code = 0，msg = success，成功
     */
    public final static String MSG_EN_SUCCESS = "success";

    /**
     * code = -1，业务处理出错
     */
    public final static String CODE_FAIL = "-1";

    /**
     * code = -1，msg = fail, 失败
     */
    public final static String MSG_EN_FAIL = "fail";

    /**
     * code = 40000，请求参数有误
     */
    public final static String CODE_40000 = "40000";

    /**
     * code = 40000，msg = 错误的参数
     */
    public final static String MSG_EN_ERROR_PARAM = "error param";

    /**
     * code = 40001，版本有误
     */
    public final static String CODE_40001 = "40001";

    /**
     * code = 40001，msg = 错误的参数
     */
    public final static String MSG_EN_ERROR_APP_INFO = "error app info";

    /**
     * code = 40002，没有访问权限--accessToken过期
     */
    public final static String CODE_40002 = "40002";


    /**
     * code = 40003，账号已经在其他设备上登录，token失效
     */
    public final static String CODE_40003 = "40003";

    /**
     * code = 40002，msg = 没有权限
     */
    public final static String MSG_EN_ERROR_AUTHORITY = "no authority";



    /**
     * code = 40004，资源不存在
     */
    public final static String CODE_40004 = "40004";

    /**
     * code = 50000，数据不存在
     */
    public final static String CODE_50000 = "50000";

    /**
     * code = 50000，msg = 数据不存在
     */
    public final static String MSG_EN_DATA_NOT_EXIST = "data not exist";

    /**
     * code = 50001，用户已存在
     */
    public final static String CODE_50001 = "50001";

    /**
     * code = 50002，用户不存在
     */
    public final static String CODE_50002 = "50002";

    /**
     * code = 50003，用户名或密码错误
     */
    public final static String CODE_50003 = "50003";

    /**
     * code = 50003，msg = 用户名或密码错误
     */
    public final static String MSG_EN_USER_LOGIN_2 = "username or passwd error";

    /**
     * code = 50004，未登陆
     */
    public final static String CODE_50004 = "50004";

    /**
     * code = 50004，msg = 未登陆
     */
    public final static String MSG_EN_USER_LOGIN_4 = "user no login";

    /**
     * code = 50005，验证码失效
     */
    public final static String CODE_50005 = "50005";

    /**
     * code = 50006，验证码错误
     */
    public final static String CODE_50006 = "50006";

    /**
     * 无权限操作设备
     */
    public final static String CODE_60002 = "60002";

    /**
     * code = 60006，DEVICECODE不可用
     */
    public final static String CODE_60006 = "60006";


    /**
     * code = 6000，this camera by bound for other user(去权限操作摄像头)
     */
    public final static String CODE_60007 = "60007";


    /**
     * 分享用户不存在
     */
    public final static String CODE_60009 = "60009";



    /**
     * 设备号被使用或不存在
     */
    public final static String CODE_60100 = "60100";

    /**
     * 设备不能分享给自己
     */
    public final static String CODE_60011 = "60011";

    /**
     * 被分享的用户不存在
     */
    public final static String CODE_60104 = "60104";

    /**
     * 当前用户是否存在可以被分享的摄像头
     */
    public final static String CODE_60105 = "60105";

    /**
     * 不能分享给自己
     */
    public final static String CODE_60106 = "60106";

    /**
     * 当前用户与被分享用户已经建立好友关系，不能再次重复添加好友关系
     */
    public final static String CODE_60107 = "60107";

    /**
     * 当前用户与被分享用户已经建立好友关系，不能再次重复添加好友关系
     */
    public final static String CODE_60012 = "60012";

    /**
     * 当前无网络
     */
    public final static String CODE_NO_NETWORK = "-100";

    public interface ISetCodeCallback{
        public void setCodeMap(HashMap<String, String> codeMap);
    }


    /**
     * 增加错误码对应资源
     */
    public static void setCode(ISetCodeCallback callback) {
        callback.setCodeMap(codeMap);
    }

    /**
     * 提供给接口获取错误码提示语
     *
     * @param code
     * @return
     */
    public static String getCodeMsg(Context context, String code) {
        if(null == codeMap || codeMap.size()== 0) {
            codeMap = new HashMap<>();
        }
        String message = codeMap.get(code);
        //本地没有错误码，返回网络错误
        if(TextUtils.isEmpty(message)){
            return "";
        }
        return message;
    }
}
