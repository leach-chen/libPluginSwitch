package com.leachchen.mbase.API.Common.Code;


import com.leachchen.mbase.API.RequestImpl.BaseRespone;

/**
 * ClassName:   LoginRespone.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 9:53
 **/
public class CodeRespone  extends BaseRespone {


    /**
     * stateCode : 0
     * stateMsg : success
     * data : {}
     */

    private DataBean data;

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getStateMsg() {
        return stateMsg;
    }

    public void setStateMsg(String stateMsg) {
        this.stateMsg = stateMsg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
    }
}
