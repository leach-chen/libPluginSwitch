package com.leachchen.mbase.API.Common.UpdateApp;

/**
 * ClassName:   BodyData.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 16:01
 **/
public class UpdateAppBodyData {


    private String appCode;
    private String appSecret;
    private String grantType;
    private String appVersionIn;
    private String appVersionOut;
    private String language;



    public UpdateAppBodyData(String appCode, String appSecret, String grantType
                             , String appVersionOut, String appVersionIn, String language)
    {
        this.appCode = appCode;
        this.appSecret = appSecret;
        this.grantType = grantType;
        this.appVersionOut = appVersionOut;
        this.appVersionIn = appVersionIn;
        this.language = language;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getAppVersionIn() {
        return appVersionIn;
    }

    public void setAppVersionIn(String appVersionIn) {
        this.appVersionIn = appVersionIn;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getGrantType() {
        return grantType;
    }

    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    public String getAppVersionOut() {
        return appVersionOut;
    }

    public void setAppVersionOut(String appVersionOut) {
        this.appVersionOut = appVersionOut;
    }


}
