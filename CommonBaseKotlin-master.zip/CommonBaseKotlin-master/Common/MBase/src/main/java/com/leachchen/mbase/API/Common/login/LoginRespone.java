package com.leachchen.mbase.API.Common.login;


import com.leachchen.mbase.API.RequestImpl.BaseRespone;

/**
 * ClassName:   LoginRespone.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 9:53
 **/
public class LoginRespone extends BaseRespone {

    /**
     * stateCode : 0
     * stateMsg : success
     * data : {"userMail":"cjack.cao@sunvalley.com.cn","userFirstName":"c","userLastName":"jack","accessToken":"611ef0023b2803b08f824ae44c9b1f54","expiresIn":"7200"}
     */

    /**
     * userMail : cjack.cao@sunvalley.com.cn
     * userFirstName : c
     * userLastName : jack
     * accessToken : 611ef0023b2803b08f824ae44c9b1f54
     * expiresIn : 7200
     */

    private DataBean data;

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getStateMsg() {
        return stateMsg;
    }

    public void setStateMsg(String stateMsg) {
        this.stateMsg = stateMsg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String userId = "test_userid";
        private String userMail;
        private String userFirstName;
        private String userLastName;
        private String accessToken;
        private String expiresIn;
        private String userMPhone;

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getUserMail() {
            return userMail;
        }

        public void setUserMail(String userMail) {
            this.userMail = userMail;
        }

        public String getUserFirstName() {
            return userFirstName;
        }

        public void setUserFirstName(String userFirstName) {
            this.userFirstName = userFirstName;
        }

        public String getUserLastName() {
            return userLastName;
        }

        public void setUserLastName(String userLastName) {
            this.userLastName = userLastName;
        }

        public String getAccessToken() {
            return accessToken;
        }

        public void setAccessToken(String accessToken) {
            this.accessToken = accessToken;
        }

        public String getExpiresIn() {
            return expiresIn;
        }

        public void setExpiresIn(String expiresIn) {
            this.expiresIn = expiresIn;
        }

        public String getUserMPhone() {
            return userMPhone;
        }

        public void setUserMPhone(String userMPhone) {
            this.userMPhone = userMPhone;
        }
    }
}
