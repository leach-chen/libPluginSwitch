package com.leachchen.mbase.API.RequestImpl;

import android.content.Context;

import com.leachchen.commongroup.Utils.Net.Retrofit.RequestCreate;
import com.leachchen.mbase.API.Common.Auth.AuthApi;
import com.leachchen.mbase.API.Common.Auth.AuthBodyData;
import com.leachchen.mbase.API.Common.Auth.AuthRespone;
import com.leachchen.mbase.API.Common.login.LoginApi;
import com.leachchen.mbase.API.Common.login.LoginBodyData;
import com.leachchen.mbase.API.Common.login.LoginRespone;
import com.leachchen.mbase.API.Other.ResultFuc;

import rx.Observable;
import rx.functions.Func1;

/**
 * ClassName:   AuthHelp.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/24 13:42
 **/

public class AuthHelp {


    public interface AuthUpdateListener {
        void updateDBAuth(AuthRespone authRespone);
        void updateLoginDBAuth(LoginRespone loginRespone, String account, String pwd);
    }

    /**
     * 获取授权token
     * @param context
     * @param authInfo，本地记录的授权信息
     * @param authUpdateListener 取得授权结果的回调，用于将授权信息存入数据库
     * @return
     */
    public static Observable<AuthRespone> requestAuth(final Context context, CommonAuthInfo authInfo, final AuthUpdateListener authUpdateListener) {
        return Observable.just(authInfo).flatMap(new Func1<CommonAuthInfo, Observable<AuthRespone>>() {
            @Override
            public Observable<AuthRespone> call(CommonAuthInfo authInfo) {
                if (authInfo != null) {
                    //非登录接口才获取本地token
                    long startTime = authInfo.getAuthStartTime();
                    long endTime = System.currentTimeMillis();
                    //token还在有效期
                    if ((endTime - startTime) < authInfo.getAuthExpiresIn()) {
                        AuthRespone authRespone = new AuthRespone();
                        AuthRespone.DataBean data = new AuthRespone.DataBean();
                        data.setAccessToken(authInfo.getAuthAccessToken());
                        data.setExpiresIn("" + authInfo.getAuthExpiresIn() / 1000);
                        authRespone.setData(data);
                        return Observable.just(authRespone);
                    } else {
                        return authRequest(context,authUpdateListener);
                    }
                } else {
                    return authRequest(context,authUpdateListener);
                }
            }
        });
    }


    /**
     * 请求登录授权信息
     * @param context
     * @param authInfo  本地记录的授权信息
     * @param userInfo  本地记录的用户信息
     * @param authUpdateListener 取得授权结果的回调，用于将授权信息存入数据库
     * @return
     */
    public static Observable<LoginRespone> requestLoginAuth(final Context context, CommonAuthInfo authInfo, final CommonUserInfo userInfo, final AuthUpdateListener authUpdateListener) {
        return AuthHelp.requestAuth(context,authInfo, authUpdateListener)
                .flatMap(new Func1<AuthRespone, Observable<LoginRespone>>() {
                    @Override
                    public Observable<LoginRespone> call(AuthRespone authRespone) {
                        if (userInfo != null) {
                            long startTime = userInfo.getStartTime();
                            long endTime = System.currentTimeMillis();
                            //token还在有效期
                            if ((endTime - startTime) < userInfo.getExpiresIn() && !userInfo.getUserAccount().equals("-1")) {
                                LoginRespone loginRespone = new LoginRespone();
                                loginRespone.setStateCode("0");
                                loginRespone.setStateMsg("");
                                LoginRespone.DataBean data = new LoginRespone.DataBean();
                                data.setUserMail(userInfo.getUserAccount());
                                data.setUserFirstName(userInfo.getUserFirstName());
                                data.setUserLastName(userInfo.getUserLastName());
                                data.setAccessToken(userInfo.getAccessToken());
                                data.setExpiresIn("" + userInfo.getExpiresIn());
                                data.setUserMPhone(userInfo.getTelephone());
                                loginRespone.setData(data);
                                return Observable.just(loginRespone);
                            } else {
                                return loginRequest(context,authRespone.getData().getAccessToken(), userInfo.getUserAccount(), userInfo.getUserPwd(), authUpdateListener);
                            }
                        } else {
                            return loginRequest(context,authRespone.getData().getAccessToken(), userInfo.getUserAccount(), userInfo.getUserPwd(), authUpdateListener);
                        }
                    }
                });

    }

    /**
     * 请求登录
     * @param context
     * @param account   用户名
     * @param pwd   密码
     * @param authUpdateListener    取得授权结果的回调，用于将授权信息存入数据库
     * @return
     */
    public static Observable<LoginRespone> requestLogin(final Context context, final String account, final String pwd, final AuthUpdateListener authUpdateListener)
    {
        return authRequest(context,authUpdateListener).flatMap(new Func1<AuthRespone, Observable<LoginRespone>>() {
            @Override
            public Observable<LoginRespone> call(AuthRespone authRespone) {
                return loginRequest(context,authRespone.getData().getAccessToken(),account,pwd,authUpdateListener);
            }
        });
    }

    private static Observable<AuthRespone> authRequest(Context context, final AuthUpdateListener authUpdateListener) {
        return RequestCreate.createService(context,AuthApi.class).getAuthToken(ParamsDefine.getRequestParams("0"),
                new AuthBodyData(ParamsDefine.appCode, ParamsDefine.appSecret, ParamsDefine.grantType, ParamsDefine.appVersionOut)).
                map(new ResultFuc<AuthRespone>() {
                    @Override
                    public AuthRespone handSuccessResult(AuthRespone authRespone) {
                        authUpdateListener.updateDBAuth(authRespone);
                        return authRespone;
                    }
                });
    }

    private static Observable<LoginRespone> loginRequest(Context context, String authAccessToken, final String account, final String pwd, final AuthUpdateListener authUpdateListener) {
        return RequestCreate.createService(context,LoginApi.class).getLogin(ParamsDefine.getRequestParams(authAccessToken), new LoginBodyData(account, pwd))
                .map(new ResultFuc<LoginRespone>() {
                    @Override
                    public LoginRespone handSuccessResult(LoginRespone loginRespone) {
                        authUpdateListener.updateLoginDBAuth(loginRespone,account,pwd);
                        return loginRespone;
                    }
                });
    }

}
