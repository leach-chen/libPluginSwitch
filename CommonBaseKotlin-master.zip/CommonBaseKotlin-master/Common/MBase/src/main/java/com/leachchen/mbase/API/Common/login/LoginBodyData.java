package com.leachchen.mbase.API.Common.login;

/**
 * ClassName:   BodyData.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 16:01
 **/
public class LoginBodyData {


    private String userMail;
    private String userPwd;

    public LoginBodyData(String userMail, String userPwd)
    {
        this.userMail = userMail;
        this.userPwd = userPwd;
    }


    public String getUserMail() {
        return userMail;
    }

    public void setUserMail(String userMail) {
        this.userMail = userMail;
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }
}
