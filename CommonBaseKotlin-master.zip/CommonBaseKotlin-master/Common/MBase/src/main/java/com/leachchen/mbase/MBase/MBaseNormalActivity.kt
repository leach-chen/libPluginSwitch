package com.leachchen.mbase.MBase

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import com.leachchen.commongroup.MvpBase.UIBase.BaseActivity
import com.leachchen.commongroup.Utils.LogWrite.LogWrite

/**
 * ClassName:   MBaseNormalActivity.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 11:33
 **/
abstract class MBaseNormalActivity : BaseActivity() {
    var mImpl: MBaseImpl? = null
    var mPresenter: MBasePresenter? = null
    private var manager: InputMethodManager? = null

    @Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initStatusBar()
    }

    /**
     * 初始化状态栏
     */
    fun initStatusBar() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val window = window
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS or WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                /*            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);*/
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                window.statusBarColor = Color.TRANSPARENT
                //window.setNavigationBarColor(Color.TRANSPARENT);
            } else {

                //4.4以下版本，不能设置状态栏透明，所以需要将状态栏高度去掉
                //changeTitleBarHeight();
            }
            init()

            manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        } catch (e: Exception) {
            LogWrite.writeMsg(e)
        }

        //测试
        //        mApplication = AppApplication.getInstance();
        //        init();
        //        changeTitleBarHeight();
    }


    @Override
    override fun onPause() {
        super.onPause()
        if (mImpl != null) {
            mImpl!!.onPause()
        }
    }

    @Override
    override fun onResume() {
        super.onResume()
        if (mImpl != null) {
            mImpl!!.onResume()
        }
    }

    @Override
    override fun onDestroy() {
        super.onDestroy()
        if (mImpl != null)
            mImpl!!.onDestroy()
    }


    @Override
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (null != mImpl) {
            if (data != null) {
                mImpl!!.onActivityResult(resultCode, resultCode, data)
            }
        }
    }


    @Override
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
        }
        return super.onKeyDown(keyCode, event)
    }
}