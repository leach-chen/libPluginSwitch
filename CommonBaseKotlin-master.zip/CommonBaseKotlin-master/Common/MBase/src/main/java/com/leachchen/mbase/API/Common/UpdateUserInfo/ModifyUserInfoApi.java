package com.leachchen.mbase.API.Common.UpdateUserInfo;


import com.leachchen.mbase.API.RequestImpl.BaseRespone;

import java.util.Map;

import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import rx.Observable;

/**
 * Created by josh.hong on 2017/5/25.
 */

public interface ModifyUserInfoApi {
    @POST("mi/base/user/userInfoModify?")
    Observable<BaseRespone> modifyUserInfo(
            @QueryMap Map<String, String> stringMap,
            @Body ModifyUserInfoBody mModifyUserInfoBody
    );
}
