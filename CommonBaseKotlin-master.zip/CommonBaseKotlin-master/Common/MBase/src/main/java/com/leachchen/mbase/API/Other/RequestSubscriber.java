package com.leachchen.mbase.API.Other;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;

import com.leachchen.commongroup.Utils.Dialog.Dialog.DialogFactory;
import com.leachchen.commongroup.Utils.LogWrite.LogModel;
import com.leachchen.commongroup.Utils.LogWrite.LogWrite;
import com.leachchen.commongroup.Utils.Net.Retrofit.ApiException;
import com.leachchen.commongroup.Utils.RxBus.RxBus;
import com.leachchen.commongroup.Utils.RxBus.RxDefine;
import com.leachchen.mbase.API.RequestImpl.ResponeCode;

import rx.Subscriber;

/**
 * ClassName:   ProgressSubscriber.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/24 13:39
 **/

public abstract class RequestSubscriber<T> extends Subscriber<T> {

    /**
     * Token过期次数
     */
    private static int AccessTokenTimeoutCount = 0;

    private boolean isShowLoading;
    private String mMessage = "";
    protected DialogFactory mDialogFactory;
    protected Activity mActivity;
    protected Context mContext;

    public RequestSubscriber()
    {

    }

    public  RequestSubscriber(Activity activity, Context context) {
        this(activity,context,true);
    }

    public RequestSubscriber(Activity activity, Context context, boolean isShowLoading) {
        this(activity,context,isShowLoading,"");
    }

    public RequestSubscriber(Activity activity, Context context, boolean isShowLoading, String message) {
        this.mActivity = activity;
        this.mContext = context;
        this.isShowLoading = isShowLoading;
        this.mMessage = message;
        mDialogFactory = new DialogFactory(context);
    }

    @Override
    public void onStart() {

        if(isShowLoading) {
            mDialogFactory.showLoading(mMessage).showDialog();
        }
    }

    @Override
    public void onCompleted() {
        mDialogFactory.hideLoadingDialog();
    }

    /**
     * 是否显示错误信息
     * @return
     */
    public boolean shouldShowErrorMessage(){
        return false;
    }

    @Override
    public void onError(Throwable e) {
        mDialogFactory.hideLoadingDialog();
        if (e instanceof ApiException) {
            ApiException ae = (ApiException) e;
            String code = ae.stateCode;
            String message = ae.getMessage();
            boolean showErrorMsg = shouldShowErrorMessage();
            String msg = code + "@@" + message + "@@" + String.valueOf(showErrorMsg);
            RxBus.get().post(RxDefine.RXBUS_SERVER_CODE, msg);

            //token过去
            if (code.equals(ResponeCode.CODE_40002)) {

                //通知重新发起请求
                AccessTokenTimeoutCount++;
                if (AccessTokenTimeoutCount <= 3) {
                    //重发三次(等待1秒后再发，因为需要等待清除本地清除token)
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            onAccessTokenTimeout();
                        }
                    }, 1000);

                    return;
                } else {
                    //大于三次就不重复
                    AccessTokenTimeoutCount = 0;
                }
            }
        } else {

            //其他异常，统统显示网络错误
            if (shouldShowErrorMessage()) {
                mActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                    }
                });

            }
        }
        onFail(e);
    }

    @Override
    public void onNext(T t) {
        mDialogFactory.hideLoadingDialog();
        onSuccess(t);
    }


    /**
     * accessToken过期回调
     */
    public abstract void onAccessTokenTimeout();
    public abstract void onSuccess(T t);
    public void onFail(Throwable e){
        LogWrite.e("request onFail : " + e.getMessage(), LogModel.MODEL_COMMON);
    };

    /**
     * 无网络
     */
    public void onNoConnectNetwork(){}


}
