package com.leachchen.mbase.API.Common.ResetPwd;

import java.util.Map;

import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import rx.Observable;

/**
 * ClassName:   LoginApi.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 9:54
 **/
public interface ResetPwdApi {
    @POST("user/pwd/appmodify?")
    Observable<ResetPwdRespone> getResetPwd(
            @QueryMap Map<String, String> stringMap,
            @Body ResetPwdBodyData findPwdBodyData
    );
}
