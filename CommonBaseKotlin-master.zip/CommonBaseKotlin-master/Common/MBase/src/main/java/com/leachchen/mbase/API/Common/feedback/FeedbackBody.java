package com.leachchen.mbase.API.Common.feedback;

/**
 * Created by jame.liu on 2017/5/25.
 */

public class FeedbackBody {
    public String fdContent;//	反馈的内容，varchar(500)	string
    public String fdMail;//	用户邮箱	string
    public String fdTitle;//	标题	string
    public String fdType;//	反馈类型，C101：求助；C102：问题反馈

    public FeedbackBody(String fdContent, String fdMail, String fdTitle, String fdType) {
        this.fdContent = fdContent;
        this.fdMail = fdMail;
        this.fdTitle = fdTitle;
        this.fdType = fdType;
    }
}

