package com.leachchen.mbase.API.Common.Auth;

import java.util.Map;

import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import rx.Observable;

/**
 * ClassName:   AuthApi.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/26 15:57
 **/
public interface AuthApi {
    @POST("mi/base/security/authorize/getaccesstoken?")
    Observable<AuthRespone> getAuthToken(@QueryMap Map<String, String> stringMap,
                                         @Body AuthBodyData bodyData);
}
