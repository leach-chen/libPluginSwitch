package com.leachchen.mbase.API.Common.UpdateApp;


import android.text.TextUtils;

import com.leachchen.mbase.API.RequestImpl.BaseRespone;
import com.leachchen.mbase.API.RequestImpl.ParamsDefine;

import java.io.Serializable;

/**
 * ClassName:   LoginRespone.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 9:53
 **/
public class UpdateAppRespone extends BaseRespone {
    /**
     * data : {"attention":"测试内容m58w","download":"测试内容sv06","loop":"测试内容s248","md5Str":"测试内容3hl6","remark":"测试内容i41f","versionOut":"测试内容ytk3"}
     */

    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean implements Serializable {
        /**
         * attention : 测试内容m58w
         * download : 测试内容sv06
         * loop : 测试内容s248
         * md5Str : 测试内容3hl6
         * remark : 测试内容i41f
         * versionOut : 测试内容ytk3
         */

        private String attention;
        private String download;
        private String loop;
        private String md5Str;
        private String remark;
        private String versionOut;

        public String getAttention() {
            return attention;
        }

        public void setAttention(String attention) {
            this.attention = attention;
        }

        public String getDownload() {
            return download;
        }

        public void setDownload(String download) {
            this.download = download;
        }

        public String getLoop() {
            return loop;
        }

        public void setLoop(String loop) {
            this.loop = loop;
        }

        public boolean hasVersion(){

            if(TextUtils.isEmpty(loop)){
                return false;
            }

            return loop.equals(ParamsDefine.HAVE_UPDATE) || loop.equals(ParamsDefine.FORCE_UPDATE);
        }

        public String getMd5Str() {
            return md5Str;
        }

        public void setMd5Str(String md5Str) {
            this.md5Str = md5Str;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getVersionOut() {
            return versionOut;
        }

        public void setVersionOut(String versionOut) {
            this.versionOut = versionOut;
        }
    }
}
