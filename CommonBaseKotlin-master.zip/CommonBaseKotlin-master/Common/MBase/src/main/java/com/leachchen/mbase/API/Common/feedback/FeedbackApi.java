package com.leachchen.mbase.API.Common.feedback;


import com.leachchen.mbase.API.RequestImpl.BaseRespone;

import java.util.Map;

import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import rx.Observable;

/**
 * Created by jame.liu on 2017/5/25.
 */

public interface FeedbackApi {
    @POST("mi/base/experience/feedback/fromapp?")
    Observable<BaseRespone> feedback(
            @QueryMap Map<String, String> stringMap,
            @Body FeedbackBody body
    );
}
