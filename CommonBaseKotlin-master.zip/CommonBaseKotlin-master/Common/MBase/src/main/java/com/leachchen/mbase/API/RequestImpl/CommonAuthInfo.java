package com.leachchen.mbase.API.RequestImpl;

/**
 * ClassName:   AuthoInfo.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/24 13:46
 **/

public class CommonAuthInfo {
    private String host;//host
    private String authAccessToken; //授权token
    private long authExpiresIn; //授权token有效时长
    private long authStartTime; //授权token开始生效时间
    private String createTime;//字段创建时间

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getAuthAccessToken() {
        return authAccessToken;
    }

    public void setAuthAccessToken(String authAccessToken) {
        this.authAccessToken = authAccessToken;
    }

    public long getAuthExpiresIn() {
        return authExpiresIn;
    }

    public void setAuthExpiresIn(long authExpiresIn) {
        this.authExpiresIn = authExpiresIn;
    }

    public long getAuthStartTime() {
        return authStartTime;
    }

    public void setAuthStartTime(long authStartTime) {
        this.authStartTime = authStartTime;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
}
