package com.leachchen.mbase.API.Common.Code;

/**
 * ClassName:   BodyData.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 16:01
 **/
public class CodeBodyData {



    private String userMail;
    private String useType;

    public CodeBodyData(String userMail, String useType)
    {
        this.userMail = userMail;
        this.useType = useType;
    }

    public String getUserMail() {
        return userMail;
    }

    public void setUserMail(String userMail) {
        this.userMail = userMail;
    }

    public String getUseType() {
        return useType;
    }

    public void setUseType(String useType) {
        this.useType = useType;
    }
}
