package com.leachchen.mbase.MBase

import android.os.Bundle
import android.view.View
import com.leachchen.commongroup.MvpBase.UIBase.BaseFragment
import com.leachchen.commongroup.Utils.LogWrite.LogWrite

/**
 * ClassName:   BaseNormalFragment.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 11:23
 **/
abstract class MBaseNormalFragment : BaseFragment(){

    var mImpl: MBaseImpl? = null
    var mPresenter: MBasePresenter? = null
    protected var mView: View? = null

    @Override
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        try {
            init()
        } catch (e: Exception) {
            LogWrite.writeMsg(e)
        }
    }

    @Override
    override fun onPause() {
        super.onPause()
        if (mImpl != null) {
            mImpl!!.onPause()
        }
    }

    @Override
    override fun onResume() {
        super.onResume()
        if (mImpl != null) {
            mImpl!!.onResume()
        }
    }

    @Override
    override fun onDestroy() {
        super.onDestroy()
        if (mImpl != null)
            mImpl!!.onDestroy()
    }

}