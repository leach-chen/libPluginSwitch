package com.leachchen.mbase.API.RequestImpl;

import com.leachchen.commongroup.Utils.Utils.DateUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * ClassName:   ParamsDefine.java
 * Description:
 * Author :     leach.chen
 * Date:        2017/10/24 13:49
 **/

public class ParamsDefine {

    public static final String accessToken = "0";
    public static final String timeStamp = "20161020120000";
    public static final String clientType = "B102";
    public static final String clientChannel = "D101";

/*
    //2.0.0
    public static final String clientVer = "020000";
    public static final String appCode = "a62121e47a91fdfb14dd0d80700e8cf8";        //第三方用户唯一凭证
    public static final String appSecret = "e268895fde949d43741fec099134859a";     //第三方用户唯一凭证密钥，即appsecret
    public static final String grantType = "appCredential";                           //获取access_token填写app端：appCredential，pc端：pcCredential
    public static final String appVersionOut = "020000";                              //App六位外部版本号，例如：010000
    public static final String appVersionIn = "020000";                              //App六位内部版本号，例如：010000
    public static final String deviceNum = "P020201";                                       //子系统名称
    public static final String deviceType = "P01";                                       //子系统名称
    public static  String timeZone = "CTO";                                       //时区*/


/*
    //2.0.1
    public static final String clientVer = "020001";
    public static final String appCode = "a62121e47a91fdfb14dd0d80700e8cf8";        //第三方用户唯一凭证
    public static final String appSecret = "e268895fde949d43741fec099134859a";     //第三方用户唯一凭证密钥，即appsecret
    public static final String grantType = "appCredential";                           //获取access_token填写app端：appCredential，pc端：pcCredential
    public static final String appVersionOut = "020000";                              //App六位外部版本号，例如：010000
    public static final String appVersionIn = "020000";                              //App六位内部版本号，例如：010000
    public static final String deviceNum = "P020201";                                       //子系统名称
    public static final String deviceType = "P01";                                       //子系统名称
    public static  String timeZone = "CTO";                                       //时区*/


    //2.0.2
    public static final String clientVer = "020002";
    public static final String appCode = "a88fd0a47ea98e5000c1e4ae85d77408";        //第三方用户唯一凭证
    public static final String appSecret = "d99194afcb673cd9e6669f89116a6435";     //第三方用户唯一凭证密钥，即appsecret
    public static final String grantType = "appCredential";                           //获取access_token填写app端：appCredential，pc端：pcCredential
    public static final String appVersionOut = "020002";                              //App六位外部版本号，例如：010000
    public static final String appVersionIn = "020002";                              //App六位内部版本号，例如：010000
    public static final String deviceNum = "P020201";                                       //子系统名称
    public static final String deviceType = "P01";                                       //子系统名称
    public static String timeZone = "CTO";                                       //时区



    public static final String RESET_PWD = "A301";                              // A301:修改密码；
    public static final String FORGET_PWD = "A302";                             // A302:找回密码；
    public static final String FORGET_REG = "A303";                             // A303:注册；

    public static final String HAVE_UPDATE = "A100";  //不强制升级
    public static final String FORCE_UPDATE = "A101";  //强制升级
    public static final String NO_UPDATE = "A102";  //不升级
    //public static final String LANGUAGE = Locale.getDefault().getLanguage();
//    public static final String LANGUAGE = "EN";

    /**
     * reset pwd
     */
    public static final int MY_RESETPWD = 1001;
    public static final int MY_FORGETPWD = 1002;

    /**
     * 请求参数头部
     * @param token
     * @return
     */
    public static Map<String,String> getRequestParams(String token)
    {
        Map<String,String> commonMap = new HashMap<>();
        commonMap.put("accessToken",token);
        commonMap.put("timeStamp",getTimeStamp());
        commonMap.put("clientType",clientType);
        commonMap.put("clientChannel",clientChannel);
        commonMap.put("clientVer",clientVer);
        commonMap.put("deviceType",deviceType);
        return commonMap;
    }


    public static String getTimeStamp()
    {
        return DateUtil.getTimeStamp(System.currentTimeMillis());
    }
}
