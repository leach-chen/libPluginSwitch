package com.leachchen.mbase.API.Common.UpdateUserInfo;

/**
 * ClassName:   BodyData.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 16:01
 **/
public class UpdateUserInfoBodyData {



    private String userFirstName;
    private String userLastName;
    private String phoneNumber;
    private int type;
    public final static int UPDATE_USER_INFO = 0;
    public final static int UPDATE_FIRST_NAME = 1;
    public final static int UPDATE_LAST_NAME = 2;
    public final static int UPDATE_TEL = 3;

    public UpdateUserInfoBodyData(String userFirstName, String userLastName, String phoneNumber, int type)
    {
        this.userFirstName = userFirstName;
        this.userLastName = userLastName;
        this.phoneNumber = phoneNumber;
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getUserFirstName() {
        return userFirstName;
    }

    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    public String getUserLastName() {
        return userLastName;
    }

    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
