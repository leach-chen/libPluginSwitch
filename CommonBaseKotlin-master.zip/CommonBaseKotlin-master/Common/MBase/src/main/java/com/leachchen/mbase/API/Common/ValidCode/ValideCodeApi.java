package com.leachchen.mbase.API.Common.ValidCode;

import java.util.Map;

import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import rx.Observable;

/**
 * ClassName:   LoginApi.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 9:54
 **/
public interface ValideCodeApi {
    @POST("mi/base/msg/validatevfcode?")
    Observable<ValideCodeRespone> getValidCode(
            @QueryMap Map<String, String> stringMap,
            @Body ValideCodeBodyData updateAppBodyData
    );
}
