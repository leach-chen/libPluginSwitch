package com.leachchen.mbase.API.Common.UpdateFirmware;

/**
 * ClassName:   BodyData.java
 * Description:
 * Author :     leach.chen
 * Date:        2016/9/27 16:01
 **/
public class UpdateFirmwareBodyData {


    private String appCode;
    private String appSecret;
    private String grantType;
    private String appVersionIn;
    private String appVersionOut;
    private String firmCode;
    private String firmSecret;
    private String firmVersionIn;
    private String firmVersionOut;
    private String hardCode;
    private String hardSecret;
    private String hardVersionIn;
    private String hardVersionOut;
    private String deviceNum;
    private String firmNum;
    private String language;


    public UpdateFirmwareBodyData(String appCode, String appSecret, String grantType
            , String appVersionIn, String appVersionOut, String firmCode, String firmSecret
            , String firmVersionIn, String firmVersionOut, String firmNum
            , String hardCode, String hardSecret
            , String hardVersionIn, String hardVersionOut, String deviceNum, String language)
    {
        this.appCode = appCode;
        this.appSecret = appSecret;
        this.grantType = grantType;
        this.appVersionIn = appVersionIn;
        this.appVersionOut = appVersionOut;
        this.firmCode = firmCode;
        this.firmSecret = firmSecret;
        this.firmVersionIn = firmVersionIn;
        this.firmVersionOut = firmVersionOut;
        this.firmNum = firmNum;
        this.hardCode = hardCode;
        this.hardSecret = hardSecret;
        this.hardVersionIn = hardVersionIn;
        this.hardVersionOut = hardVersionOut;
        if (deviceNum == null) deviceNum = ""; //兼容1.3APP，连1.2固件无法获取deviceNum问题,1.2不用传deviceNum
        this.deviceNum = deviceNum;
        this.language = language;
    }


    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getGrantType() {
        return grantType;
    }

    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    public String getAppVersionIn() {
        return appVersionIn;
    }

    public void setAppVersionIn(String appVersionIn) {
        this.appVersionIn = appVersionIn;
    }

    public String getAppVersionOut() {
        return appVersionOut;
    }

    public void setAppVersionOut(String appVersionOut) {
        this.appVersionOut = appVersionOut;
    }

    public String getFirmCode() {
        return firmCode;
    }

    public void setFirmCode(String firmCode) {
        this.firmCode = firmCode;
    }

    public String getFirmSecret() {
        return firmSecret;
    }

    public void setFirmSecret(String firmSecret) {
        this.firmSecret = firmSecret;
    }

    public String getFirmVersionIn() {
        return firmVersionIn;
    }

    public void setFirmVersionIn(String firmVersionIn) {
        this.firmVersionIn = firmVersionIn;
    }

    public String getFirmVersionOut() {
        return firmVersionOut;
    }

    public void setFirmVersionOut(String firmVersionOut) {
        this.firmVersionOut = firmVersionOut;
    }

    public String getHardCode() {
        return hardCode;
    }

    public void setHardCode(String hardCode) {
        this.hardCode = hardCode;
    }

    public String getHardSecret() {
        return hardSecret;
    }

    public void setHardSecret(String hardSecret) {
        this.hardSecret = hardSecret;
    }

    public String getHardVersionIn() {
        return hardVersionIn;
    }

    public void setHardVersionIn(String hardVersionIn) {
        this.hardVersionIn = hardVersionIn;
    }

    public String getHardVersionOut() {
        return hardVersionOut;
    }

    public void setHardVersionOut(String hardVersionOut) {
        this.hardVersionOut = hardVersionOut;
    }

    public String getDeviceNum() {
        return deviceNum;
    }

    public void setDeviceNum(String deviceNum) {
        this.deviceNum = deviceNum;
    }

    public String getFirmNum() {
        return firmNum;
    }

    public void setFirmNum(String firmNum) {
        this.firmNum = firmNum;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}
