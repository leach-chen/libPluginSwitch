package com.leachchen.mbase.API.Other;



import com.leachchen.commongroup.Utils.Net.Retrofit.ApiException;
import com.leachchen.mbase.API.RequestImpl.BaseRespone;

import rx.functions.Func1;

/**
 * 获取网络数据的处理
 * Created by jame on 2017/7/27.
 */

public class ResultFuc<T extends BaseRespone> implements Func1<T, T> {
    private boolean checkStateCode = true;

    public ResultFuc() {
        this(true);
    }

    public ResultFuc(boolean checkStateCode) {
        this.checkStateCode = checkStateCode;
    }

    @Override
    public T call(T httpResult) {
        String stateCode = httpResult.getStateCode();
        if (httpResult.isSuccessResponse()) {
            //有数据，或者数据为空，都正常返回
            return handSuccessResult(httpResult);
        } else {
            //异常处理-判断错误码
            if (checkStateCode) {
                throw new ApiException(stateCode, httpResult.getStateMsg());
            }
        }
        return handSuccessResult(httpResult);
    }

    /**
     * 处理成功请求
     *
     * @param httpResult
     * @return
     */
    public T handSuccessResult(T httpResult) {
        return httpResult;
    }
}
