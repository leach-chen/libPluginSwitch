package com.leachchen.mbase.MBase

import android.app.Activity
import com.leachchen.commongroup.Utils.Net.Retrofit.ApiException
import com.leachchen.mbase.API.Other.RequestSubscriber

/**
 * ClassName:   MRequestSubscriber.java
 * Description:
 * Author :     leach.chen
 * Date:        2019/1/31 10:34
 **/
abstract class MRequestSubscriber<T>: RequestSubscriber<T> {

    constructor(activity: Activity) : super(activity,activity) {

    }

    constructor(activity: Activity,isShowLoading:Boolean) : super(activity,activity,isShowLoading,"") {

    }

    @Override
    override fun onAccessTokenTimeout() {

    }

    @Override
    override fun onStart() {
        super.onStart()

        //设备wifi直接弹无网对话框
        //        if (DeviceHandle.getInstance().isDeviceWifiConnectDB()) {
        //            mDialogFactory.hideLoadingDialog();
        //            unsubscribe();
        //
        //            //弹出没有网络对话框
        //            onNoConnectNetwork();
        //            return;
        //        }

        //有可能连接了一个无网络
        //        NetWorkHelper.isNetWorkPing(new INetWorkUtil() {
        //            @Override
        //            public void onSuccess() {
        //                //有网络
        //            }
        //
        //            @Override
        //            public void onFail() {
        //
        //                //-100代表无网络,这样写不好，在后台请求，也会弹出提示，不友好
        //                //String msg = ResponeCode.CODE_NO_NETWORK+"@@no network@@true";
        //                //RxBus.get().post(RxDefine.RXBUS_SERVER_CODE, msg);
        //
        //                //无网络，或者超时
        //                if (null != mActivity) {
        //                    mActivity.runOnUiThread(new Runnable() {
        //                        @Override
        //                        public void run() {
        //
        //                            mDialogFactory.hideLoadingDialog();
        //                            unsubscribe();
        //
        //                            //弹出没有网络对话框
        //                            onNoConnectNetwork();
        //
        //                        }
        //                    });
        //                }
        //            }
        //        }, ConstantOther.NETWORK_PING_TIMEOUT);

    }


    @Override
    override fun onError(e: Throwable) {
        super.onError(e)
        if (e !is ApiException) {
            onNoConnectNetwork()
        }
    }
}
